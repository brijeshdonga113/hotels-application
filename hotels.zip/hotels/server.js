/*
 * This is the server file for the Travelclick Internet Booking Engine (Web 4)
 */
"use strict";

//Import the required modules
var express = require('express');
var expressHandlebars = require('express-handlebars');
var FileStreamRotator = require('file-stream-rotator');
var morgan = require('morgan');
var device = require('express-device');
// Configuration
var appConfig = require('./src/server/config/config.js');
//Application routes
var apiPromise = require('./src/server/api-promise');
var authRoute = require('./src/server/routes/auth.js');
var bodyParser = require('body-parser');
//Application Middleware


var cookieParser = require('cookie-parser');
var chainInfo = require('./info.json');
//Initialize Express and Handlebars
var app = express();
app.enable('trust proxy');
app.use(cookieParser());
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
//Configure express app settings
//http://expressjs.com/en/api.html#app.settings.table
app.engine('handlebars', expressHandlebars({extname: '.hbs'}));
app.set('view engine', 'handlebars');
app.set('port', appConfig.port);
app.set('env', 'development');

//-----------------------------------------------------------------------------


//Capture the device
app.use(device.capture());

//-----------------------------------------------------------------------------
// Route Mappings


//!------------------------------- START REMOVE
var appDir = "/src/client/app";
//For every new sub-directory created, you must make an express.static
app.use("/build", express.static(__dirname + "/build"));
app.use("/images", express.static(__dirname + "/src/client/assets/images"));
app.use("/filters", express.static(__dirname + appDir + "/filters"));
app.use("/navbar", express.static(__dirname + appDir + "/navbar"));
app.use("/subnav", express.static(__dirname + appDir + "/subnav"));
app.use("/searchresults", express.static(__dirname + appDir + "/searchresults"));
app.use("/guestandrooms", express.static(__dirname + appDir + "/guestandrooms"));
app.use("/searchFilter", express.static(__dirname + appDir + "/searchFilter"));
app.use("/searchGoogleDest", express.static(__dirname + appDir + "/searchGoogleDest"));
app.use("/api", express.static(__dirname + appDir + "/api"));
app.use("/common", express.static(__dirname + appDir + "/common"));
app.use("/cache", express.static(__dirname + "/node_modules/angular-cache/dist"));
app.use("/jwt", express.static(__dirname + "/node_modules/angular-jwt/dist"));
app.use("/store", express.static(__dirname + "/node_modules/angular-storage/dist"));
app.use("/areasearch", express.static(__dirname));

//Added subfolder for angulartics libraries
app.use("/gaLib", express.static(__dirname + "/node_modules/angulartics/dist"));
app.use("/gaLib/angulartics-abc.min.js", express.static(__dirname + "/node_modules/angulartics-google-analytics/dist/angulartics-google-analytics.min.js"));
//Map console-data
app.use('/assets/hotel', express.static(appConfig.consoleData));
app.use('/assets/chain', express.static(appConfig.areaSearchConsoleData));
// Return the static index.html
app.get('/', function (req, res) {
    res.render('404', {msg: "The requested page could not be found"});
});

//!------------------------------- END REMOVE


//===================================================================
//ROUTES
app.use('/css', express.static(__dirname + "/build"));
app.use('/js', express.static(__dirname + "/build"));
app.use('/thirdparty', express.static(__dirname + "/src/client/app"));
//General mapping of everything under assets
app.use('/akamai', express.static(__dirname + "/src/client/assets/akamai"));
app.use('/hotels.json', express.static(__dirname + "/hotels.json"));

//Mapping for CDN files - JS
app.use("/scripts", express.static(__dirname + "/node_modules/angular"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-google-maps/dist"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-sanitize"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-animate"));
app.use("/scripts", express.static(__dirname + "/node_modules/angularjs-slider/dist"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-ui-bootstrap"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-ui-router/build"));
app.use("/scripts", express.static(__dirname + "/src/client/assets/js"));
app.use("/scripts", express.static(__dirname + "/src/client/assets/icons/js"));
app.use("/scripts", express.static(__dirname + "/src/client/assets/icons/preview"));
app.use("/scripts", express.static(__dirname + "/node_modules/moment/min"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-scroll"));
app.use("/scripts", express.static(__dirname + "/node_modules/svgxuse"));
app.use("/scripts", express.static(__dirname + "/node_modules/angular-touch"));
app.use("/scripts", express.static(__dirname + "/node_modules/jquery/dist"));
app.use("/scripts", express.static(__dirname + "/node_modules/bootstrap/dist/js"));


//Mapping for CDN files - CSS
app.use("/css", express.static(__dirname + "/src/client/assets/css"));
app.use("/icons", express.static(__dirname + "/src/client/assets/icons"));
//Mapping for fonts file
app.use("/fonts", express.static(__dirname + "/src/client/assets/fonts"));
app.use("/fonts", express.static(__dirname + "/src/client/assets/rzslider"));
//
//handle favicon request to return nothing
app.get("/favicon.ico", function (req, res) {
    res.status(200)
        .set({'Content-Type': 'image/x-icon'})
        .end();
});

app.get('/:chainCode', function (req, res) {

        var options = {};
        var flag;
        var str1;
        var redirectURL;
        //convery query string to lower case
        console.log("req is : " + JSON.stringify(req.query));
        options.logEnabled = req.query['logEnabled'];
        for (var key in req.query) {
            req.query[key.toLowerCase()] = req.query[key];
            if (key.toLowerCase() != key) {
                delete req.query[key];
            }
            if ((req.query[key.toLowerCase()] != undefined) && (Array.isArray(req.query[key.toLowerCase()]))) {
                req.query[key.toLowerCase()] = req.query[key.toLowerCase()][0];
            }
        }
        console.log("after req is : " + JSON.stringify(req.query));
        console.log("after req is AAA : " + req.headers.authToken);
        console.log("params : "+ JSON.stringify(req.params));
        console.log("query : "+ JSON.stringify(req.query));

//        apiPromise.getChainInfo(req.params.chainCode, req.query.themeid)
//        .then(function (chainInfo) {
            console.log("chainInfo :: "+chainInfo);
            options.title = chainInfo.chainName;
            options.chainInfo = JSON.stringify(chainInfo);
            options.chainCode = req.params.chainCode;
            options.GaId = appConfig.GaId;
            options.ibeApiUrl = appConfig.ibeApiUrl;
            options.authToken = res.authToken;
            options.beUrl = appConfig.beUrl;
  //          options.modulus = appConfig.modulus;
            options.css = chainInfo.brandInfo.cssLocation;
            options.jsFileHashed = appConfig["main-min.js"];
            options.cssFileHashed = appConfig["main-min.css"];
            options.params = JSON.stringify(req.query);

           if (req.query.editor) {
                options.loadCss = false;
           }else {
                options.loadCss = true;
           }

                res.render('index', options);

        /* })
        .catch(function (err) {
            console.log("error :: "+err + " : " +JSON.stringify(err.error));
            //!Due to JSON with an extra comma, the error json can't be parsed
            //var json = JSON.parse(err.error);
            if ((err.statusCode === 404) && (flag != true)) {
                res.render('404', {msg: err.error});
                flag = true;
            }
        });
*/
});

/**
 * Determines whether a desktop, tablet, or phone is hitting the site.
 * @param req
 * @returns {*}
 */
function getQueryString(req) {
    var qs = req.query;
    var type = req.device.type;
    var deviceType = undefined;

    if (type === 'desktop')
        deviceType = 'Web4_Desktop';
    else if (type == 'tablet')
        deviceType = 'Web4_Tablet'
    else if (type == 'phone')
        deviceType = 'Web4_Mobile'
    else {
        deviceType = 'Web4_Desktop';
    }

    qs.deviceType = deviceType;
    return qs;
}

/**
 * Convert the cookies object in an array of cookies
 *
 * @param cookies
 * @returns {Array}
 */
function convertCookiesToArray(cookies) {
    var formattedCookies = [];
    for (var key in cookies) {
        if (!cookies.hasOwnProperty(key)) {
            continue;
        }
        var obj = {};
        obj[key] = cookies[key];
        formattedCookies.push(obj);
    }

    return formattedCookies;
}

//===================================================================
//START THE SERVER
app.listen(app.get('port'), function () {
    console.log('Node app started in [', app.get('env'), '] mode in the [', appConfig.env, '] environment on port [', app.get('port'), '] @ [', new Date(), ']');
});
