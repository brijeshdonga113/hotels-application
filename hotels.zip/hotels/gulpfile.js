'use strict';

var gulp = require('gulp');
var del = require('del');
var watch = require('gulp-watch');
var browserSync = require('browser-sync');
var sass = require('gulp-sass');
var minifyCss = require('gulp-minify-css');
var autoprefixer = require('gulp-autoprefixer');
var gulpif = require('gulp-if');
var handleErrors = require('./gulputil/handle-errors').handleErrors;
var settings = require('./gulputil/settings').SETTINGS;
var argv = require('yargs').argv;
var livereload = require('gulp-livereload');
var concat = require('gulp-concat');
var sourcemaps = require('gulp-sourcemaps');
var uglify = require('gulp-uglify');
var minify = require('gulp-minify');
var karma = require('karma');
var open = require('gulp-open');
var rev = require('gulp-rev');
var rev = require('gulp-rev');

gulp.task('default', ['clean', 'sass', 'ngconcat']);

gulp.task('unit:coverage', function(done){
    return new karma.Server({
        configFile: __dirname + '/karma.conf.js',
        action: 'run',
        singleRun: true,
        preprocessors: {
            'src/client/app/!(*spec).js': ['coverage'],
            'src/client/app/!(toaster)/!(*spec|*mock|*min|angular-credit-cards|stickyfill).js': ['coverage']
        },
        reporters: ['progress', 'coverage'],
        coverageReporter: {
            type: 'html',
            dir: 'coverage/',
            subdir: '.'
        }
    }, function() {
        done();
    }).on('error', function (err) {
        throw err;
    }).start();
});

gulp.task('coverage', ['unit:coverage'], function(){
    return gulp.src('./coverage/js/index.html')
        .pipe(open());
});
gulp.task('clean', function (cb) {
    return del(['./build'], function (err, paths) {
        cb();
    });
});

const PATHS = {
    src: `${settings.src}/client/assets/scss/main.scss`,
    dest: `${settings.destPath}`
};

if (argv.watch) {
    watch([`${settings.src}/client/assets/scss/**/*.scss`], function () {
        gulp.start('sass');
    });
}

gulp.task('sass', function () {
    gulp.src([PATHS.src], {
        base: `${settings.src}/client/assets/scss/`
    })
        .pipe(sass({
            includePaths: [
                `${settings.src}/client/assets/scss/`,
                './node_modules/'
            ]
        }))
        .on('error', handleErrors)
        .pipe(autoprefixer({browsers: ['last 2 version']}))
        //.pipe(gulpif(argv.production, minifyCss()))
        .pipe(minifyCss())
        .pipe(concat('main-min.css'))
        .pipe(gulp.dest(PATHS.dest))
        .pipe(browserSync.stream())
        .pipe(livereload());
});

if (argv.watch) {
    watch([`${settings.src}/client/assets/scss/**/*.scss`], function () {
        gulp.start('sass');
    });
}

gulp.task('sass', function () {
    gulp.src([PATHS.src], {
        base: `${settings.src}/client/assets/scss/`
    })
        .pipe(sass({
            includePaths: [
                `${settings.src}/client/assets/scss/`,
                './node_modules/'
            ]
        }))
        .on('error', handleErrors)
        .pipe(autoprefixer({browsers: ['last 2 version']}))
        //.pipe(gulpif(argv.production, minifyCss()))
        .pipe(minifyCss())
        .pipe(concat('main-min.css'))
        .pipe(gulp.dest(PATHS.dest))
        .pipe(browserSync.stream())
        .pipe(livereload());
});

if (argv.watch) {
    watch([`${settings.src}/client/assets/scss/**/*.scss`], function () {
        gulp.start('sass');
    });
}

gulp.task('sass', function () {
    gulp.src([PATHS.src], {
        base: `${settings.src}/client/assets/scss/`
    })
        .pipe(sass({
            includePaths: [
                `${settings.src}/client/assets/scss/`,
                './node_modules/'
            ]
        }))
        .on('error', handleErrors)
        .pipe(autoprefixer({browsers: ['last 2 version']}))
        //.pipe(gulpif(argv.production, minifyCss()))
        .pipe(minifyCss())
        .pipe(concat('main-min.css'))
        .pipe(gulp.dest(PATHS.dest))
        .pipe(browserSync.stream())
        .pipe(livereload());
});

if (argv.watch) {
    watch([`${settings.src}/client/assets/scss/**/*.scss`], function () {
        gulp.start('sass');
    });
}

gulp.task('sass', function () {
    gulp.src([PATHS.src], {
        base: `${settings.src}/client/assets/scss/`
    })
        .pipe(sass({
            includePaths: [
                `${settings.src}/client/assets/scss/`,
                './node_modules/'
            ]
        }))
        .on('error', handleErrors)
        .pipe(autoprefixer({browsers: ['last 2 version']}))
        //.pipe(gulpif(argv.production, minifyCss()))
        .pipe(minifyCss())
        .pipe(concat('main-min.css'))
        //.pipe(gulp.dest(PATHS.dest))
        .pipe(rev())
        .pipe(gulp.dest(PATHS.dest))  // write rev'd assets to build dir
        .pipe(rev.manifest('css-manifest.json'))
        .pipe(gulp.dest(PATHS.dest)) // write manifest to build dir
        .pipe(browserSync.stream())
        .pipe(livereload());
});

gulp.task('ngconcat', function () {
    gulp.src(settings.jsPaths)
        .pipe(sourcemaps.init())
        .pipe(concat('main.js'))
        .pipe(uglify())
        .pipe(minify())
        .pipe(rev())
        .pipe(gulp.dest(`${settings.destPath}`))  // write rev'd assets to build dir
        .pipe(rev.manifest('js-manifest.json'))
        .pipe(gulp.dest(`${settings.destPath}`)) // write manifest to build dir
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(`${settings.destPath}`))
        .pipe(livereload());
});

gulp.task('watch', ['default'], function () {
    livereload.listen();
    gulp.watch(settings.jsPaths, ['ngconcat']);
    gulp.watch(settings.sassPaths, ['sass']);
    gulp.watch(settings.htmlPaths, function () {
        gulp.src(settings.htmlPaths)
            .pipe(livereload());
    });
    //TODO: Switch to webpack concat.
});
