// Karma configuration
// Generated on Tue Nov 24 2015 12:50:35 GMT-0500 (EST)

module.exports = function (config) {
    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath: '',

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine'],

        browserNoActivityTimeout: 60000,


        // list of files / patterns to load in the browser
        files: [
            'node_modules/angular/angular.js',
            'node_modules/angular-touch/angular-touch.js',
            'node_modules/angular-sanitize/angular-sanitize.js',
            'node_modules/angular-cache/dist/angular-cache.js',
            'node_modules/angular-google-maps/dist/angular-google-maps.min.js',
            'node_modules/angulartics/dist/angulartics.min.js',
            'node_modules/angulartics-google-analytics/dist/angulartics-google-analytics.min.js',
            'node_modules/angulartics/dist/angulartics-gtm.min.js',
            'node_modules/angular-ui-bootstrap/ui-bootstrap-tpls.min.js',
            'node_modules/angular-ui-router/build/angular-ui-router.js',
            'node_modules/angular-animate/angular-animate.js',
            'node_modules/moment/moment.js',
            'node_modules/lodash/index.js',
            'src/client/assets/js/lodash.min.js',
            'src/client/app/toaster/toaster.js',
            'src/client/app/total/angular-credit-cards.js',
            'node_modules/angular-scroll/angular-scroll.js',
            'node_modules/angular-mocks/angular-mocks.js',
            'node_modules/angular-jwt/dist/angular-jwt.min.js',
            'node_modules/angular-storage/dist/angular-storage.min.js',
            'node_modules/jquery/dist/jquery.js',
            'node_modules/angular-daterangepicker/js/angular-daterangepicker.js',
            'src/client/assets/js/daterangepicker.js',
            'node_modules/angularjs-slider/dist/rzslider.js',
            'src/client/assets/js/v-accordion.js',
            //'build/main.js',
            'src/client/app/*.js',
            'src/client/app/**/*.html',
            'src/client/app/**/!(*spec).js',
            'test/unit/searchresults/searchresults.controller.spec.js',
            'test/unit/services/api.factory.spec.js',
            'test/unit/services/area.factory.spec.js',
            'test/unit/services/area.service.spec.js',
            'test/unit/services/api.interceptor.spec.js',
            'test/unit/services/hotel.data.service.spec.js',
            'test/unit/services/svg.cache.service.spec.js',
            'test/unit/main.controller.spec.js',
			'test/unit/searchGoogleDest/googleSearch.directive.spec.js',
			'test/unit/navbar/navdata.factory.spec.js',
            'test/unit/navbar/navbar.directive.spec.js',
			'test/unit/navbar/navbar.controller.spec.js',
      		'test/unit/filters/currency.filter.spec.js',
      		'test/unit/filters/gmsUser.filters.spec.js',
			'test/unit/searchresults/searchresults.filter.spec.js',
			'test/unit/filters/text.filter.spec.js',
            'test/unit/guestandrooms/guestandrooms.controller.spec.js',
            'test/unit/international/international.controller.spec.js',
            'test/unit/searchFilter/searchFilter.directive.spec.js',
            'test/unit/searchFilter/searchFilter.controller.spec.js',
            'test/unit/gms/gms.controller.spec.js',
            'test/unit/gms/gms.forms.controller.spec.js',
            'test/unit/gms/gms.service.spec.js',
            'test/unit/subnav/specialcodes.directive.spec.js',
            'test/unit/subnav/subnav.controller.spec.js',
            'test/unit/searchresults/searchresults.directive.spec.js'
        ],



        // list of files to exclude
        exclude: [],
        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor

        preprocessors: {
            'src/client/app/!(*spec).js': ['coverage'],
            'src/client/app/!(toaster)/!(*spec|*mock|*min|angular-credit-cards|stickyfill).js': ['coverage'],
            'src/client/app/**/*.html' : ['ng-html2js']
        },

        ngHtml2JsPreprocessor: {
            moduleName: 'directiveTemplates'
        },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        reporters: ['progress'],


        // web server port
        port: 9876,


        // enable / disable colors in the output (reporters and logs)
        colors: true,


        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,


        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,


        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['Chrome'],


        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: false,

        // Concurrency level
        // how many browser should be started simultanous
        concurrency: Infinity
    })
};
