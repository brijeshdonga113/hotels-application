/**
 * Created by yhuang on 5/4/2017.
 */
angular.module('TravelClApp')
    .filter('ellipsisFilter', ellipsisFilter)
    .filter('htmlUnicodeFilter', ['$sce', htmlUnicodeFilter])

function htmlUnicodeFilter($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
};
function ellipsisFilter() {
    return function (text, length) {
        if (text != undefined && text.length > length) {
            return text.substr(0, length) + "...";
        }
        return text;
    }
}