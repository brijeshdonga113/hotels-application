angular.module('TravelClApp').directive('searchResults', searchResults)
    .directive('searchresultsListview', searchresultsListview)
    .directive('searchresultsGridview', searchresultsGridview)
    .directive('searchresultsMapview', searchresultsMapview)
    .directive('customGoogleMap', ['$filter', 'areaService', '$rootScope', 'EVENT', '$timeout', 'areaFactory', 'lodash', customGoogleMap])
    .directive('searchResultsDetails', searchResultsDetails)
    .directive('searchResultsGridViewRow', searchResultsGridViewRow)
    .directive('searchResultsListViewRow', searchResultsListViewRow)
    .directive('stickCloseIcon', ['$document', '$window', stickCloseIcon])
    .directive('customGoogleMapPropertyDetails', customGoogleMapPropertyDetails)
    .directive('svgImport', svgImport);


function stickCloseIcon($document, $window) {
    return {
        restrict: 'A',
        link: function (scope, ele, attrs) {

            var navHeight = document.getElementsByTagName('nav')[0].offsetHeight + 25;
            var navBarLogoHeight = 0;
            if (document.getElementsByClassName('MaxWidth-logo-wrap')[0]) {
                navHeight = document.getElementsByClassName('Header-selectionBar')[0].clientHeight;
                navBarLogoHeight = document.getElementsByClassName('MaxWidth-logo-wrap')[0].clientHeight;
            }
            var navBarHeight = navHeight + navBarLogoHeight;

            var pricingBoxWidth = '320px';

            function setStyle(htmlElement, propertyObject) {
                for (var property in propertyObject) {
                    htmlElement.style[property] = propertyObject[property];
                }
            }

            function addSticky() {
                var container_element = document.getElementById('propertyDetailsCollapse');
                var closeIcon = document.getElementById('close-icon-stick');

                if (container_element && closeIcon) {
                    var doc = document.documentElement;
                    var window_top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
                    var closeIcon_top = window.pageYOffset + container_element.getBoundingClientRect().top - 150;
                    var container_bottom = window.pageYOffset + container_element.getBoundingClientRect().top + container_element.offsetHeight;


                    var pricingBox = container_element.getElementsByClassName('PricingBox');
                    if (pricingBox.length > 0) {
                        var pricingBoxElement = pricingBox[0];
                        var pricingBoxHeight = pricingBoxElement.offsetHeight;
                        var bookButton = pricingBoxElement.getElementsByClassName('propertyDetail-bookNow')[0];

                        if ((window_top + navBarHeight) > closeIcon_top) {
                            setStyle(bookButton, {position: 'fixed', bottom: 0, width: '100%'});
                        } else {
                            setStyle(bookButton, {position: 'inherit'});
                        }

                        if ((container_element.getBoundingClientRect().top + container_element.offsetHeight - pricingBoxHeight) < window.innerHeight) {
                            setStyle(bookButton, {position: 'inherit'});
                        }

                    }

                    if ((window_top + navBarHeight) > closeIcon_top + 150) {
                        closeIcon.classList.add('stick');
                        closeIcon.style.top = navBarHeight + 'px';
                    } else {
                        closeIcon.classList.remove('stick');
                    }
                    if ((window_top + navBarHeight) > container_bottom) {
                        closeIcon.classList.remove('stick');
                    }
                }
            }

            function addPricingBoxSticky() {
                var container_element = document.getElementById('propertyDetailsCollapse');
                var closeIcon = document.getElementById('close-icon-stick-pricing');

                if (container_element && closeIcon) {
                    var doc = document.documentElement;
                    var window_top = (window.pageYOffset || doc.scrollTop) - (doc.clientTop || 0);
                    var closeIcon_top = window.pageYOffset + container_element.getBoundingClientRect().top - 150;
                    var container_bottom = window.pageYOffset + container_element.getBoundingClientRect().top + container_element.offsetHeight;

                    if ((window_top + navBarHeight) > closeIcon_top + 150) {
                        closeIcon.classList.add('stick');
                        closeIcon.style.top = navBarHeight + 'px';
                        closeIcon.style.width = pricingBoxWidth;
                    } else {
                        closeIcon.classList.remove('stick');
                    }
                    if ((window_top + navBarHeight) > container_bottom) {
                        closeIcon.classList.remove('stick');
                    }
                    var pricingBoxEle = container_element.getElementsByClassName('property-pricing-box');
                    if (pricingBoxEle.length > 0) {
                        var pricingBox = pricingBoxEle[0];
                        var priceBoxHeight = window.pageYOffset + pricingBox.offsetHeight + 160;
                        if (priceBoxHeight > container_bottom) {
                            closeIcon.classList.remove('stick');
                        }
                    }
                }

            }

            $document.on('scroll', function () {
                if ($window.innerWidth < 786) {
                    addSticky();
                } else if ($window.innerWidth > 800) {
                    addPricingBoxSticky();
                }
            });

        }
    }
}

function searchResults() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchresults.html',
        controller: searchresultsController
    }

}

function searchresultsListview() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchresultslistview.html',
        //controller: searchresultsController
    }

}

function searchresultsGridview() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchresultsgridview.html',
        //controller: searchresultsController
    }

}

function searchResultsDetails() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchResultsDetails.html'
    }
}

function searchresultsMapview() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchresultsmapview.html',
        //controller: searchresultsController
    }

}

function customGoogleMap($filter, areaService, $rootScope, EVENT, $timeout, areaFactory, lodash) {
    return {
        restrict: 'A',

        link: function (scope, element) {
            //scope.$watch("selectMark.key", function () {
            //    alert("scope.selectMark.key:" + scope.selectMark.key);
            //});

            var gnbBackgroundColor = '#000000';
            var gnbTextColor = '#ffffff';

            var gnbBackgroundElement = document.querySelector('.Header-selection.Header-selection--intl.HeaderButton');
            var gnbTextElement = document.querySelector('.HeaderButton-label');

            if (gnbBackgroundElement && gnbTextElement) {
                gnbBackgroundColor = getComputedStyle(gnbBackgroundElement).backgroundColor;
                gnbTextColor = getComputedStyle(gnbTextElement).color;
            }

            var getClusterInlineSvg = function (color) {
                var encoded = window.btoa('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="-100 -100 200 200"><defs><g id="a" transform="rotate(45)"><path d="M0 47A47 47 0 0 0 47 0L62 0A62 62 0 0 1 0 62Z" fill-opacity="0.7"/><path d="M0 67A67 67 0 0 0 67 0L81 0A81 81 0 0 1 0 81Z" fill-opacity="0.5"/><path d="M0 86A86 86 0 0 0 86 0L100 0A100 100 0 0 1 0 100Z" fill-opacity="0.3"/></g></defs><g fill="' + color + '"><circle r="42"/><use xlink:href="#a"/><g transform="rotate(120)"><use xlink:href="#a"/></g><g transform="rotate(240)"><use xlink:href="#a"/></g></g></svg>');
                return ('data:image/svg+xml;base64,' + encoded);
            };

            var clusterStyles = [
                {
                    width: 40,
                    height: 40,
                    url: getClusterInlineSvg('#FF0000'),
                    textColor: 'black',
                    textSize: 12
                },
                {
                    width: 50,
                    height: 50,
                    url: getClusterInlineSvg('#FF0000'),
                    textColor: 'black',
                    textSize: 12
                },
                {
                    width: 60,
                    height: 60,
                    url: getClusterInlineSvg('#FF0000'),
                    textColor: 'black',
                    textSize: 12
                },
                {
                    width: 70,
                    height: 70,
                    url: getClusterInlineSvg('#FF0000'),
                    textColor: 'black',
                    textSize: 12
                },
                {
                    width: 80,
                    height: 80,
                    url: getClusterInlineSvg('#FF0000'),
                    textColor: 'black',
                    textSize: 12
                }

            ];

            var styleCSS = document.createElement('style');
            styleCSS.type = 'text/css';
            styleCSS.innerHTML = '.clusterHover { background-image: url("' + getClusterInlineSvg('#000000') + '") !important; color: white !important }';
            if (document.getElementsByTagName('head')[0]) {
                document.getElementsByTagName('head')[0].appendChild(styleCSS);
            }

            var map, initialBounds;
            var markers = [];
            var clickPin = null;
            var markerCluster;
            var infoWindows = [];
            var center;
            var firstLand = true;
            scope.allMapList = [];

            var uxConfigurations = areaFactory.getUxConfiguration();
            var zoomLevel = areaService.getZoomLevel() ? areaService.getZoomLevel() : uxConfigurations.zoomLevelConfiguration;

            if (scope.tempHotelList && scope.tempHotelList.length > 0) {
                center = new google.maps.LatLng(scope.tempHotelList[0].position.latitude, scope.tempHotelList[0].position.longitude);
            } else {
                center = {lat: 53.345, lng: -6.2588};
            }
            // map config     //minZoom: 2,
            var mapOptions = {
                center: center,
                zoom: parseInt(zoomLevel),
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: true,
                draggable: true,
                minZoom: 2

            };
            // init the map
            var counter = 1;

            function initMap() {
                if (map === void 0) {
                    map = new google.maps.Map(element[0], mapOptions);

                    map.addListener('bounds_changed', function () {
                        try {
                            if (firstLand) {
                                initialBounds = map.getBounds();

                                if ((scope.tempHotelList.length > 0) && (((map.getZoom()) !== 1))) {
                                    var newLat = scope.tempHotelList[0].position.latitude;
                                    var newLon = scope.tempHotelList[0].position.longitude;
                                    map.setCenter(new google.maps.LatLng(newLat, newLon));
                                    var newBounds = map.getBounds();
                                    filterByBound(scope.tempHotelList, newBounds);
                                    firstLand = false;
                                }
								
								if((map.getZoom()) === 1){
									var strictBounds = new google.maps.LatLngBounds(
										new google.maps.LatLng(85, -180),           // top left corner of map
										new google.maps.LatLng(-85, 180)            // bottom right corner
									);    
									map.fitBounds(strictBounds);
								}					
					
                                scope.$apply();

                            }							

                        } catch (err) {
                            console.log("error" + err);
                        }


                    });

                    google.maps.event.addListener(map, 'center_changed', function () {
                        checkBounds(map);
                    });
                }
            }

            function checkBounds(map) {

                var latNorth = map.getBounds().getNorthEast().lat();
                var latSouth = map.getBounds().getSouthWest().lat();
                var newLat;

                //console.log("check bounds " + latNorth + " " + latSouth);

                if (latNorth < 85 && latSouth > -85)     /* in both side -> it's ok */
                    return;
                else {
                    if (latNorth > 85 && latSouth < -85)   /* out both side -> it's ok */
                        return;
                    else {

                        if (latNorth > 85)
                            newLat = map.getCenter().lat() - (latNorth - 85);
                        /* too north, centering */
                        if (latSouth < -85)
                            newLat = map.getCenter().lat() - (latSouth + 85);
                        /* too south, centering */
                    }


                }

                if (newLat) {
                    //console.log("current center" + map.getCenter());
                    var newCenter = new google.maps.LatLng(newLat, map.getCenter().lng());
                    //console.log("setting new center" + newCenter);
                    map.setCenter(newCenter);
                }

            }

            var iconFillColor = gnbTextColor;
            var iconStrokeColor = gnbBackgroundColor;
            var iconPath = "M-40 -10 L40 -10 L40 10 L7" + " 10 L0 20 L-7 10 L-40 10 Z";
            var icon = {
                path: iconPath,
                fillColor: iconFillColor,
                fillOpacity: 1,
                anchor: new google.maps.Point(0, 20),
                strokeWeight: 1,
                strokeColor: iconStrokeColor
            };

            function getIcon(newColorA, newColorB) {
                iconFillColor = newColorA;
                iconStrokeColor = newColorB;
                icon.fillColor = iconFillColor;
                icon.strokeColor = iconStrokeColor;
            };

            //scale: iconSize

            // place a marker
            function clickBubble(para) {

                scope.selectedDetail.key = angular.copy(para);
                scope.$parent.$parent.togglePropertyDetailsMapView(null, para, true);
                scope.$apply();

            }


            scope.$watch('intlObj', function (val) {
                if (val) {
                    //set the marker
                    DeleteMarkers();
                    //pass new object to filter
                    clickPin = null;
                    scope.selectMark.key = false;
                    scope.hoverMark.key = false;
                    scope.selectMark.hotel = null;
                    scope.hoverMark.hotel = null;
                    for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                        scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                    }

                    $rootScope.tempCurrency = areaService.getCurrencyDetails();
                    angular.forEach(scope.allMapList, function (each) {
                        getIcon(gnbTextColor, gnbBackgroundColor);
                        setMarker(map, new google.maps.LatLng(each.position.latitude, each.position.longitude), each);
                    });
                    angular.element(document).ready(function () {
                        updatePriceWidth();
                    });
                    markerCluster = new MarkerClusterer(map, markers, {styles: clusterStyles});
                    google.maps.event.addListener(markerCluster, 'clusterclick', function(cluster) {
                        $timeout(function() {
                            var newBounds = map.getBounds();
                            filterByBound(scope.tempHotelList, newBounds);
                        }, 0)
                    });
                }
            }, true);

            function setMarker(map, position, each) {

                counter++;
                var labelText;
                var discountPrice;
                var detailLabel = "page_details_ASdetailsLbl";
                var soldOutLabel = "global_soldout_ASsoldoutLbl";
                if (!each.hasOwnProperty("isAvailable")) {
                    labelText = $filter('translationsObj')(detailLabel);//scope.translate.page_details_ASdetailsLbl;
                }
                if (each.hasOwnProperty("isAvailable") && each.isAvailable === false) {
                    labelText = $filter('translationsObj')(soldOutLabel);//scope.translate.global_soldout_ASsoldoutLbl;
                }
                if (each.hasOwnProperty("isAvailable") && each.isAvailable === true) {
                    discountPrice = $filter('currencyConversionAndSymbol')(each.rate, each.currentCurrency.currencySymbol);
                    labelText = discountPrice;
                }

                var viewDetail = $filter('translationsObj')(detailLabel);

                var markerLabel = {
                    text: labelText
                };
                var newIconWidth = labelText.length * 4 + 8;
                var newIconPath = "M-" + newIconWidth + " -14 L" + newIconWidth + " -14 L" + newIconWidth + " 14 L7" + " 14 L0 24 L-7 14 L-" + newIconWidth + " 14 Z";
                icon.path = newIconPath;
                icon.anchor = new google.maps.Point(0, 20);

                var marker = new google.maps.Marker({
                    position: position,
                    map: map,
                    title: each.hotelName,
                    label: markerLabel,
                    labelClass: 'mapMarkerLabel',
                    id: each.hotelName + "-" + each.hotelCode,
                    icon: icon,
                    zIndex: counter,
                    opacity: 1,
                    path: newIconPath
                });
                //icon: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
                marker.label.fontWeight = 700;
                marker.label.color = gnbBackgroundColor;
                marker.label.zIndex = counter;
                markers.push(marker); // add marker to array

                var imgSource;
                if (each.media.propertyMainImages) {
                    imgSource = each.media.propertyMainImages[0].source;

                } else {
                    imgSource = "";
                }

                var hotelName = each.hotelName;
                var starRating;
                var oneStar = '<span class="span-star-rating"> <svg height="12" width="12"> <polygon points="6,0.6 2.4,11.88 11.4,4.68 0.6,4.68 9.6,11.88" /> </svg></span>';
                if (each.starRating == 5) {
                    starRating = oneStar + oneStar + oneStar + oneStar + oneStar;
                } else if (each.starRating == 4) {
                    starRating = oneStar + oneStar + oneStar + oneStar;
                } else if (each.starRating == 3) {
                    starRating = oneStar + oneStar + oneStar;
                } else if (each.starRating == 2) {
                    starRating = oneStar + oneStar;
                } else if (each.starRating == 1) {
                    starRating = oneStar;
                } else if (each.starRating == 'Not Rated') {
                    starRating = '';
                }

                var content = '<div id="iw-container">' +
                    '<div class="iw-content">' +
                    '<img src="' + imgSource + '" alt="" style="width: 179px; height: 159px">' +
                    '<div class="iw-subTitle">' + hotelName + '</div>' +
                    '<span>' + starRating + '<span class="iw-view-detail">'+ viewDetail +'</span>' + '</div>' + '</div>' +
                    '</div>';

                var infoWindow = new google.maps.InfoWindow({
                    content: content,
                    id: each.hotelName + "-" + each.hotelCode,
                    pixelOffset: new google.maps.Size(0, 60)
                });


                infoWindows.push(infoWindow);

                google.maps.event.addListener(infoWindow, 'domready', function () {

                    // Reference to the DIV that wraps the bottom of infowindow
                    var iwOuter = $('.gm-style-iw');
                    iwOuter.parent('div').css({"background": "transparent"});
                    //console.log("length " + document.getElementsByClassName("gm-style-iw").length);

                    /* Since this div is in a position prior to .gm-div style-iw.
                     * We use jQuery and create a iwBackground variable,
                     * and took advantage of the existing reference .gm-style-iw for the previous div with .prev().
                     */
                    var iwBackground = iwOuter.prev();
                    setTimeout(function () {
                        iwOuter.parent('div').css({"width": "1px", "height": "1px"});
                    }, 0)

                    //iwOuter1.parentNode.style.left = "500px";
                    // Removes background shadow DIV
                    iwBackground.children(':nth-child(2)').css({'display': 'none'});

                    // Removes white background DIV
                    iwBackground.children(':nth-child(4)').css({'display': 'none'});

                    // Moves the infowindow 115px to the right.
                    //iwOuter.parent().parent().css({left: '115px'});

                    // Moves the shadow of the arrow 76px to the left margin.
                    iwBackground.children(':nth-child(1)').attr('style', function (i, s) {
                        return s + 'left: 112px !important;'
                    });

                    // Moves the arrow 76px to the left margin.
                    iwBackground.children(':nth-child(3)').attr('style', function (i, s) {
                        return s + 'left: 112px !important;'
                    });

                    // Changes the desired tail shadow color.
                    iwBackground.children(':nth-child(3)').find('div').children().css({
                        'box-shadow': '#d5d5d5 0px 1px 6px',
                        'z-index': '1'
                    });

                    /*Added CSS class to tooltip pointer div, we will use this class in console for visual styling*/
                    iwBackground.children(':nth-child(3)').children('div').addClass("tooltip-arrow-part");
                    //iwBackground.children(':nth-child(3)').find('div').children().css({'box-shadow': 'rgba(0, 0, 0, 0.6) 0px 1px 6px', 'z-index' : '1'});


                    // Reference to the div that groups the close button elements.
                    var iwCloseBtn = iwOuter.next();

                    // Apply the desired effect to the close button
                    iwCloseBtn.css({
                        opacity: '1',
                        right: '-185px',
                        top: '18px',

                    });

                    //border: '1px solid #d5d5d5',
                    //    'border-radius': '13px',
                    //    'box-shadow': '0 0 5px #3990B9'

                    // If the content of infowindow not exceed the set maximum height, then the gradient is removed.
                    //if ($('.iw-content').height() < 180) {
                    //    $('.iw-bottom-gradient').css({display: 'none'});
                    //}

                    // The API automatically applies 0.7 opacity to the button after the mouseout event. This function reverses this event to the desired value.
                    iwCloseBtn.mouseout(function () {
                        $(this).css({opacity: '1'});
                    });

                    google.maps.event.addDomListener(iwCloseBtn[0], 'click', function () {

                        infoWindow.close();
                    });
                });


                google.maps.event.addListener(marker, 'click', function () {

                    if (!clickPin) {
                        if (scope.resize === 3) {  //desktop
                            counter++;
                            marker.zIndex = counter;
                            icon.path = marker.path;
                            icon.anchor = new google.maps.Point(0, 40);
                            marker.setIcon(icon);

                            infoWindow.open(map, marker);
                            //alert("open")

                            document.getElementById("iw-container").addEventListener('click', function () {
                                clickBubble(marker.id);

                            });


                        } else {  //tablet and mobile
                            counter++;
                            marker.zIndex = counter;
                            icon.path = marker.path;
                            getIcon(gnbBackgroundColor, gnbTextColor);
                            marker.setIcon(icon);
                            marker.label.color = gnbTextColor;
                        }
                        clickPin = marker.id;
                        scope.selectMark.key = true;
                        scope.selectMark.hotel = angular.copy(each);
                        var hotelCode = scope.selectMark.hotel.hotelCode;
                        for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                            if (scope.mapDisplayHotelList.mapDisplayHotelList[i].hotelCode == hotelCode) {
                                scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = true;
                            } else {
                                scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                            }
                        }
                        document.getElementById(hotelCode).scrollIntoView();
                    } else {
                        if (scope.resize === 3) {
                            //angular.forEach(infoWindows, function (eachInfoWindow) {
                            //    eachInfoWindow.close();
                            //})
                            for (var k = 0; k < infoWindows.length; k++) {
                                infoWindows[k].close();
                            }

                            for (var j = 0; j < markers.length; j++) {
                                if (markers[j].id == clickPin) {
                                    getIcon(gnbTextColor, gnbBackgroundColor);
                                    icon.path = markers[j].path;
                                    icon.anchor = new google.maps.Point(0, 20);
                                    markers[j].setIcon(icon);
                                    markers[j].label.color = gnbBackgroundColor;
                                }
                            }

                            clickPin = marker.id;


                            //setTimeout(function(){
                            counter++;
                            marker.zIndex = counter;
                            icon.path = marker.path;
                            icon.anchor = new google.maps.Point(0, 40);
                            marker.setIcon(icon);
                            infoWindow.open(map, marker);
                            //},0)

                        } else {   //tablets and mobile
                            for (var j = 0; j < markers.length; j++) {
                                if (markers[j].id == clickPin) {
                                    icon.path = markers[j].path;
                                    getIcon(gnbTextColor, gnbBackgroundColor);
                                    markers[j].setIcon(icon);
                                    markers[j].label.color = gnbBackgroundColor;
                                }
                            }

                            clickPin = marker.id;
                            counter++;
                            marker.zIndex = counter;
                            icon.path = marker.path;
                            getIcon(gnbBackgroundColor, gnbTextColor);
                            marker.setIcon(icon);
                            marker.label.color = gnbTextColor;
                        }
                        scope.selectMark.key = true;
                        scope.selectMark.hotel = angular.copy(each);
                        var hotelCode = scope.selectMark.hotel.hotelCode;
                        for (var t = 0; t < scope.mapDisplayHotelList.mapDisplayHotelList.length; t++) {
                            if (scope.mapDisplayHotelList.mapDisplayHotelList[t].hotelCode == hotelCode) {
                                scope.mapDisplayHotelList.mapDisplayHotelList[t].selected = true;
                            } else {
                                scope.mapDisplayHotelList.mapDisplayHotelList[t].selected = false;
                            }
                        }
                        document.getElementById(hotelCode).scrollIntoView();

                    }

                    scope.$apply();
                });

                google.maps.event.addListener(marker, 'mouseover', function () {

                    if (clickPin) {

                    } else {

                        counter++;
                        marker.zIndex = counter;
                        icon.path = marker.path;
                        getIcon(gnbBackgroundColor, gnbTextColor);
                        marker.setIcon(icon);
                        marker.label.color = gnbTextColor;
                        scope.hoverMark.key = true;
                        scope.hoverMark.hotel = angular.copy(each);
                        var hotelCode = scope.hoverMark.hotel.hotelCode;
                        for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                            if (scope.mapDisplayHotelList.mapDisplayHotelList[i].hotelCode == hotelCode) {
                                scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = true;
                            } else {
                                scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                            }
                        }


                        scope.$apply();

                    }

                });

                google.maps.event.addListener(marker, 'mouseout', function () {

                    if (clickPin) {
                        //alert("mouseout:" + scope.selectMark.key + ";  clickPin:" + clickPin);

                    } else {
                        scope.hoverMark.key = false;
                        scope.hoverMark.hotel = null;

                        for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                            scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                        }
                        icon.path = marker.path;
                        getIcon(gnbTextColor, gnbBackgroundColor);
                        marker.setIcon(icon);
                        marker.label.color = gnbBackgroundColor;
                        scope.$apply();

                    }

                    //marker.setIcon('https://maps.google.com/mapfiles/ms/icons/red-dot.png');
                });

                google.maps.event.addListener(map, 'click', function () {

                    infoWindow.close();
                    clickPin = null;
                    icon.anchor = new google.maps.Point(0, 20);
                    marker.setIcon(icon);

                    for (var n = 0; n < markers.length; n++) {
                        icon.path = markers[n].path;
                        getIcon(gnbTextColor, gnbBackgroundColor);
                        markers[n].setIcon(icon);
                        markers[n].label.color = gnbBackgroundColor;
                    }
                    scope.selectMark.key = false;
                    scope.hoverMark.key = false;
                    scope.selectMark.hotel = null;
                    scope.hoverMark.hotel = null;
                    for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                        scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                    }
                    scope.$apply();
                    //alert("click map: " + scope.selectMark.key);

                });

                google.maps.event.addListener(infoWindow, 'closeclick', function () {
                    infoWindow.close();
                    clickPin = null;
                    icon.path = marker.path;
                    icon.anchor = new google.maps.Point(0, 20);
                    getIcon(gnbTextColor, gnbBackgroundColor);
                    marker.setIcon(icon);
                    marker.label.color = gnbBackgroundColor;

                    scope.selectMark.key = false;
                    scope.hoverMark.key = false;
                    scope.selectMark.hotel = null;
                    scope.hoverMark.hotel = null;
                    for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                        scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                    }

                    scope.$apply();

                });


            }

            // show the map and place some markers
            initMap();

            google.maps.event.addListener(map, 'dragend', function () {

                try {
                    clickPin = null;
                    for (var r = 0; r < markers.length; r++) {
                        icon.path = markers[r].path;
                        icon.anchor = new google.maps.Point(0, 20);
                        getIcon(gnbTextColor, gnbBackgroundColor);

                        markers[r].setIcon(icon);
                        markers[r].label.color = gnbBackgroundColor;
                    }

                    for (var s = 0; s < infoWindows.length; s++) {
                        infoWindows[s].close();
                    }
                    initialBounds = map.getBounds();

                    if (scope.tempHotelList.length > 0) {
                        filterByBound(scope.tempHotelList, initialBounds, true);
                    }

                    //scope.selectMark.key = false;
                    //scope.hoverMark.key = false;
                    //scope.selectMark.hotel = null;
                    //scope.hoverMark.hotel = null;
                    //for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                    //    scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                    //}
                    //scope.$apply();

                } catch (err) {
                    console.log("error" + err);
                }


            });

            google.maps.event.addListener(map, 'zoom_changed', function () {
                try {
                    clickPin = null;

                    for (var r = 0; r < markers.length; r++) {
                        icon.path = markers[r].path;
                        icon.anchor = new google.maps.Point(0, 20);
                        getIcon(gnbTextColor, gnbBackgroundColor);
                        markers[r].setIcon(icon);
                        markers[r].label.color = gnbBackgroundColor;
                    }

                    for (var s = 0; s < infoWindows.length; s++) {
                        infoWindows[s].close();
                    }

                    initialBounds = map.getBounds();

                    if (scope.tempHotelList.length > 0) {
                        filterByBound(scope.tempHotelList, initialBounds, true);
                    }


                    scope.$apply();

                } catch (err) {
                    console.log("error" + err);
                }

            });


            function DeleteMarkers() {
                //Loop through all the markers and remove
                for (var i = 0; i < markers.length; i++) {
                    markers[i].setMap(null);
                }
                markers = [];
                if(markerCluster != undefined) {
                    markerCluster.clearMarkers();
                }
            }

            function filterByBound(hotelList, bounds, scrollToTop) {
                initialBounds = angular.copy(bounds);
                scope.mapDisplayHotelList.mapDisplayHotelList = [];
                var intendedProperty = false;
                //scope.propertyOnMap = 0;
                var tempArrayWithBound = [];
                var tempArrayWithoutBound = [];
                var hList = angular.copy(hotelList);
                var bds = JSON.stringify(bounds);

                //console.log("bds:"+JSON.stringify(bounds));
                var newBound = map.getBounds();
                for (var j = 0; j < hList.length; j++) {
                    var theL = hList[j].position.latitude;
                    var theO = hList[j].position.longitude;
                    var myLatlng = new google.maps.LatLng(parseFloat(theL), parseFloat(theO));
                    if (newBound.contains(myLatlng)) {
                        tempArrayWithBound.push(hList[j]);
                        //scope.mapDisplayHotelList.mapDisplayHotelList.push(hList[j]);
                    } else {
                        tempArrayWithoutBound.push(hList[j]);
                    }
                }

                if(areaService.getHoverHotelId() != undefined && areaService.getHoverHotelId() != null) {
                    var intendedHotelId = angular.copy(areaService.getHoverHotelId());
                    areaService.setHoverHotelId(undefined);

                    var tempHotelListArray = [];
                    var index = lodash.findIndex(tempArrayWithBound, function(hotel) {
                        return hotel.hotelCode == intendedHotelId;
                    });

                    if(index != -1) {
                        tempHotelListArray = angular.copy(lodash.without(tempArrayWithBound, tempArrayWithBound[index]));
                        tempHotelListArray.unshift(tempArrayWithBound[index]);
                        tempArrayWithBound = angular.copy(tempHotelListArray);
                        intendedProperty = true;
                    }
                }

                $rootScope.propertyOnMap = {count:tempArrayWithBound.length};
                scope.mapDisplayHotelList.mapDisplayHotelList = angular.copy(tempArrayWithBound.concat(tempArrayWithoutBound));
                //scope.allMapList = angular.copy(scope.mapDisplayHotelList.mapDisplayHotelList);
                scope.allMapList = angular.copy(hList);

                scope.selectMark.key = false;
                scope.hoverMark.key = false;
                scope.selectMark.hotel = null;
                scope.hoverMark.hotel = null;
                for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                    scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                }
                if(tempArrayWithBound.length > 0 && (scrollToTop || intendedProperty)) {
                    angular.element(document.getElementById('mapview-list-id')).scrollTopAnimated(0, 500);
                }
                scope.$apply();

            }

            scope.$on(EVENT.CLOSE_PROPERTY_DETAIL, function () {

                for (var i = 0; i < markers.length; i++) {
                    icon.path = markers[i].path;
                    icon.anchor = new google.maps.Point(0, 20);
                    getIcon(gnbTextColor, gnbBackgroundColor);
                    markers[i].setIcon(icon);
                    markers[i].label.color = gnbBackgroundColor;
                }

                for (var k = 0; k < infoWindows.length; k++) {
                    infoWindows[k].close();
                }

                clickPin = null;
                scope.selectMark.key = false;
                scope.hoverMark.key = false;
                scope.selectMark.hotel = null;
                scope.hoverMark.hotel = null;
                for (var i = 0; i < scope.mapDisplayHotelList.mapDisplayHotelList.length; i++) {
                    scope.mapDisplayHotelList.mapDisplayHotelList[i].selected = false;
                }
            });


            scope.$watch('tempHotelList', function () {
                $rootScope.propertyOnMap = {count:0};
                if (scope.tempHotelList.length > 0) {
                    if (map.getBounds()) {

                        setTimeout(function () {
                            var newLat = scope.tempHotelList[0].position.latitude;
                            var newLon = scope.tempHotelList[0].position.longitude;
                            map.setCenter(new google.maps.LatLng(newLat, newLon));
                            var newBounds = map.getBounds();
                            filterByBound(scope.tempHotelList, newBounds);

                            scope.$apply();

                        }, 0)
                    }

                } else {
                    scope.mapDisplayHotelList.mapDisplayHotelList = [];
                    scope.allMapList = [];
                    DeleteMarkers();
                }


            }, true);

            if (scope.tempHotelList.length > 0) {
                if (map && initialBounds) {
                    var newLat = scope.tempHotelList[0].position.latitude;
                    var newLon = scope.tempHotelList[0].position.longitude;
                    map.setCenter(new google.maps.LatLng(newLat, newLon));
                    setTimeout(function () {
                        var newBounds = map.getBounds();
                        filterByBound(scope.tempHotelList, newBounds);
                        scope.$apply()
                    }, 0)
                }

            }

            scope.$watch('allMapList', function () {

                DeleteMarkers();
                angular.forEach(scope.allMapList, function (each) {
                    setMarker(map, new google.maps.LatLng(each.position.latitude, each.position.longitude), each);
                })

                angular.element(document).ready(function () {
                    updatePriceWidth();
                });

                markerCluster = new MarkerClusterer(map, markers, {styles: clusterStyles});
                google.maps.event.addListener(markerCluster, 'clusterclick', function(cluster) {
                    $timeout(function() {
                        var newBounds = map.getBounds();
                        filterByBound(scope.tempHotelList, newBounds);
                    }, 0)
                });

            }, true);

            function updatePriceWidth() {
                var maxPrice = '';
                for (var ind = 0; ind < scope.allMapList.length; ind++) {
                    var strPriceUp, strPriceDown, strFrom, lenPriceDown, lenPriceUp, lenFrom, lenUp;
                    if (scope.allMapList[ind].discount && scope.rateShow && !scope.allMapList[ind].defaultRateInfo.isConfidential) {
                        strPriceUp = $filter('currencyConversionAndSymbol')(scope.allMapList[ind].rate, scope.allMapList[ind].currentCurrency.currencySymbol);
                    } else {
                        strPriceUp = '';
                    }
                    strFrom =  scope.translate.global_from_ASfromLbl;
                    lenPriceUp = strPriceUp.length;
                    lenFrom = strFrom.length;
                    lenUp = 9*lenFrom + 7*lenPriceUp;

                    strPriceDown = $filter('currencyConversionAndSymbol')(scope.allMapList[ind].rate + scope.allMapList[ind].discount, scope.allMapList[ind].currentCurrency.currencySymbol);
                    lenPriceDown = strPriceDown.length;

                    //console.log("strPriceUp:" + strPriceUp + ": strPriceDown:" + strPriceDown);
                    if (maxPrice < lenPriceDown* 9) {
                        maxPrice = lenPriceDown* 9;
                    }

                    if (maxPrice < lenUp) {
                        maxPrice = lenUp;
                    }
                }

                var priceWidth = maxPrice.toString() + 'px';

                var priceDiv = document.getElementsByClassName("btn-dynamic-price");
                if (priceDiv) {
                    //console.log("priceDiv:"+priceDiv);
                    for (var index = 0; index < priceDiv.length; index++) {
                        priceDiv[index].style.width = priceWidth;
                    }
                }

            }

            scope.$watch('[selectIndex,selectHotel]', function () {
                if (scope.selectHotel) {
                    var selectedLat = scope.selectHotel.position.latitude;
                    var selectedLon = scope.selectHotel.position.longitude;
                    var selectedId = scope.selectHotel.hotelName + "-" + scope.selectHotel.hotelCode;

                    for (var p = 0; p < infoWindows.length; p++) {
                        infoWindows[p].close();
                    }

                    scope.selectMark.key = false;
                    scope.selectMark.hotel = null;

                    for (var q = 0; q < markers.length; q++) {
                        if (markers[q].id == selectedId) {

                            $timeout(function () {
                                var clusters = markerCluster.clusters_;
                                var clusterId;
                                var inCluster = false;
                                if(clusters != undefined && clusters.length > 0) {
                                    for(var ci = 0; ci < clusters.length; ci++) {
                                        var clusterMarkers = clusters[ci].markers_;
                                        if(clusterMarkers != undefined && clusterMarkers.length > 0) {
                                            for(var mi = 0; mi < clusterMarkers.length; mi++) {
                                                if(clusterMarkers[mi].id == selectedId) {
                                                    clusterId = ci;
                                                    inCluster = true;
                                                }
                                            }
                                        }
                                    }
                                    if(clusterId != undefined && inCluster) {
                                        clusters[clusterId].clusterIcon_.div_.className = 'clusterHover';
                                    }
                                }
                            }, 0);

                            //marker.setIcon('https://maps.google.com/mapfiles/ms/icons/green-dot.png');
                            getIcon(gnbBackgroundColor, gnbTextColor);
                            icon.path = markers[q].path;
                            icon.anchor = new google.maps.Point(0, 20);
                            markers[q].setIcon(icon);
                            markers[q].label.color = gnbTextColor;
                            var newBounds = map.getBounds();
                            if (!newBounds.contains(markers[q].getPosition())) {
                                map.setCenter(new google.maps.LatLng(selectedLat, selectedLon));
                            }
                        }
                    }


                } else {
                    for (var k = 0; k < markers.length; k++) {
                        icon.path = markers[k].path;
                        getIcon(gnbTextColor, gnbBackgroundColor);
                        markers[k].setIcon(icon);
                        markers[k].label.color = gnbBackgroundColor;
                    }
                }
            }, true);

            scope.$on('HOVER_OUT_CLUSTER', function() {
                $timeout(function() {
                    var clusters = markerCluster.clusters_;
                    if(clusters != undefined && clusters.length > 0) {
                        for(var ci = 0; ci < clusters.length; ci++) {
                            if(clusters[ci].clusterIcon_.div_.className != '') {
                                clusters[ci].clusterIcon_.div_.className = '';
                            }
                        }
                    }
                }, 0);
            });

            scope.$on('REFRESH_MAP', function() {
                $timeout(function() {
                    var newBounds = map.getBounds();
                    filterByBound(scope.tempHotelList, newBounds);
                }, 0);
            });

        }
    }
}


function searchResultsGridViewRow() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchResultsGridViewRow.html',
        link: function (scope, el, attrs) {
            scope.gridRow = attrs.specificRow;
        }
    }
}

function searchResultsListViewRow() {
    return {
        restrict: 'E',
        templateUrl: './searchresults/searchResultsListViewRow.html',
        link: function (scope, el, attrs) {
            scope.gridRow = attrs.specificRow;
        }
    }
}

function customGoogleMapPropertyDetails() {
    return {
        restrict: 'A',
        scope: {
            propertyMap: '='
        },
        link: function (scope, element) {
            var hotelDescInfo = scope.propertyMap;
            scope.positionLatitude = Number(hotelDescInfo.position.latitude);
            scope.positionLongitude = Number(hotelDescInfo.position.longitude);
            scope.hotelName = hotelDescInfo.hotelName;

            var map = new google.maps.Map(element[0], {
                center: new google.maps.LatLng(scope.positionLatitude, scope.positionLongitude),
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            });

            var infoWindow = new google.maps.InfoWindow();

            function addMarker(options, html) {
                var marker = new google.maps.Marker(options);
                if (html) {
                    google.maps.event.addListener(marker, "click", function () {
                        infoWindow.setContent(html);
                        infoWindow.open(options.map, this);
                    });
                }
                return marker;
            }

            var hotelLocationMarker = addMarker({
                position: new google.maps.LatLng(scope.positionLatitude, scope.positionLongitude),
                map: map
            }, scope.hotelName);
        }
    }
}

function svgImport() {
    return {
        restrict: 'A',
        scope: {
            url: '@',
        },
        controller: ['$scope', 'svgCacheService', function ($scope, svgCacheService) {
            $scope.loadSvg = svgCacheService.getSvgFile;
        }],
        link: function (scope, element, attrs) {
            var imgURL = scope.url;
            if (imgURL) {
                var xhr;
                var imgID = element.attr('id');
                var imgClass = element.attr('class');

                element.css('visibility', 'hidden');

                var dimensions = {
                    w: element.attr('width'),
                    h: element.attr('height')
                };

                scope.loadSvg(imgURL, function (data) {
                    var x = document.createElement('x');
                    var svg;
                    x.innerHTML = data;
                    svg = x.getElementsByTagName('svg')[0];
                    replaceIMGWithSVG(element, svg, imgID, imgClass, imgURL, dimensions);
                });

                function replaceIMGWithSVG($el, svg, imgID, imgClass, imgURL, dimensions) {
                    if (typeof imgID !== undefined) {
                        angular.element(svg).attr('id', imgID);
                    }

                    if (typeof imgClass !== undefined) {
                        var cls = (angular.element(svg).attr('class') !== undefined) ? angular.element(svg).attr('class') : '';
                        angular.element(svg).attr('class', imgClass + ' ' + cls + ' replaced-svg');
                    }

                    if (typeof imgURL !== undefined) {
                        angular.element(svg).attr('data-url', imgURL);
                    }

                    var ow = parseFloat(angular.element(svg).attr('width'));
                    var oh = parseFloat(angular.element(svg).attr('height'));

                    if (dimensions.w && dimensions.h) {
                        angular.element(svg).attr('width', dimensions.w);
                        angular.element(svg).attr('height', dimensions.h);
                    } else if (dimensions.w) {
                        angular.element(svg).attr('width', dimensions.w);
                        angular.element(svg).attr('height', (oh / ow) * dimensions.w);
                    } else if (dimensions.h) {
                        angular.element(svg).attr('height', dimensions.h);
                        angular.element(svg).attr('width', (ow / oh) * dimensions.h);
                    }
                    $el.replaceWith(svg);
                }

            }

        }
    }
}
