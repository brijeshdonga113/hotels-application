function searchresultsController($scope, $rootScope, $window, apiFactory, $document, $timeout, areaFactory, EVENT, hotelDataService, $sce, lodash, areaService, toaster, $filter) {

    var isAvailCallDone = false;  // TO MAKE SURE THAT AVAIL CALL REPLACE INITIAL HOTEL LIST FIRST TIME AND THEN PUSH NEW RESPONSE TO EXISTING LIST
    var isLoadMore = false; // SET TRUE WHEN LOAD MORE HOTEL BUTTON CLICKED
    var originalHotelList = []; // TO STORE ORIGINAL HOTEL LIST
    var intFilteredHotelList = []; // FILTERED HOTEL LIST BEFORE AVAIL CALL
    var chainCode = $window.chainCode;
    var hotelLoadProcess = true;
    $scope.displayHotelList = [];
    $scope.tempHotelList = [];
    $scope.testClick = true;
    $scope.moreOptions = false;
    $scope.maxiDesLength = 300;

    $scope.propertyDetailsView = 'photos';

    $scope.showMapViewPropertyDetails = false;
    $scope.hideMapView = false;
    $scope.rateShow = areaFactory.getUxConfiguration().enableStrikeThroughPricing;
    $scope.enableImageTags = areaFactory.getUxConfiguration().enablePropertyImageTags;
    $scope.ratePlanDisplayPreferences = areaFactory.getUxConfiguration().ratePlanPreviewDisplayPreferance;

    $scope.mapview = {};
    $scope.mapview.mapcontainer = "mapview-mapcontainer";
    $scope.mapview.listcontainer = "mapview-listcontainer";

    $scope.showLoadMore = false;
    $scope.selectMark = {};
    $scope.selectMark.key = false;
    $scope.selectMark.hotel = null;
    $scope.hoverMark = {};
    $scope.hoverMark.key = false;
    $scope.hoverMark.hotel = null;
    $scope.showCarousel = false;
    $rootScope.propertyOnMap = {count:0};

    $scope.selectedDetail = {"key": null};
    $scope.mapDisplayHotelList = {};
    $scope.mapDisplayHotelList.mapDisplayHotelList = [];

    if (areaFactory.getUxConfiguration().enableCarouselAutoScroll === true) {
        $scope.myInterval = 2500;
    } else {
        $scope.myInterval = 0;
    }

    $scope.noWrapSlides = false;

    var oldGridNumber = null;
    $scope.showDetails = false;
    $scope.prevOpenedPropertyId = null;
    $scope.togglePropertyDetails = function (gridNumber, property) {

        $scope.showCarousel = false;
        if (property != undefined && property.defaultRateInfo != undefined && property.defaultRateInfo.ratePlanId != undefined) {
            property.selectedRatePlan = property.defaultRateInfo.ratePlanId;
        }
        if (property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
            $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
        }
        if (oldGridNumber == gridNumber) {
            if ($scope.prevOpenedPropertyId != property.hotelCode) {

            } else {
                toggleDetail(null);
            }
        } else {
            toggleDetail(gridNumber);
        }
        scrollPropertyDetailsUp(property);
        $scope.selectedProperty = property;
        if ($scope.selectedProperty.ratePlanList) {
            if ($scope.selectedProperty.ratePlanList.length == 0) {
                $scope.showDefaultBook = true;
            } else {
                $scope.showDefaultBook = false;
            }
        } else {
            $scope.showDefaultBook = true;
        }
        if (!$scope.selectedProperty.hasOwnProperty('isAvailable')) {
            $scope.showDefaultBook = true;
        } else {
            $scope.showDefaultBook = false;
        }
        $scope.propertyDetailsView = 'photos';

        setTimeout(function () {
            if ($scope.selectedProperty.media.propertyDetailImages == null) {
                $scope.propertyDetailsView = 'map';
            }
        }, 0);
        if ($scope.selectedProperty.media.propertyDetailImages != null && $scope.selectedProperty.media.propertyDetailImages != undefined) {
            for (var i = 0; i < $scope.selectedProperty.media.propertyDetailImages.length; i++) {
                if ($scope.selectedProperty.media.propertyDetailImages[i].sortOrder == 0) {
                    $scope.selectedProperty.media.propertyDetailImages[i].active = true;
                } else {
                    $scope.selectedProperty.media.propertyDetailImages[i].active = false;
                }
            }
        }
        if (areaFactory.getUxConfiguration().enableCarouselAutoScroll === true) {
            $scope.myInterval = 2500;
        } else {
            $scope.myInterval = 0;
        }
        $scope.limit = 1;
        $scope.moreOptions = false;
        setTimeout(function () {
            $scope.showCarousel = true;
        }, 0);
        oldGridNumber = $scope.myGridNumber;
        $scope.prevOpenedPropertyId = property.hotelCode;
    }

    $scope.closePropertyDetails = function () {
        oldGridNumber = null;
        $scope.showCarousel = false;
        $scope.showMapViewPropertyDetails = false;
        $scope.hideMapView = false;
        $scope.prevOpenedPropertyId = null;
        $scope.showDetails = false;
        $scope.myGridNumber = null;
        $scope.selectMark.key = false;
        $scope.selectMark.hotel = null;
        $scope.hoverMark.key = false;
        $scope.hoverMark.hotel = null;
        $scope.propertyDetailsView = 'photos';
        $rootScope.$broadcast(EVENT.CLOSE_PROPERTY_DETAIL);
        var elements = document.getElementsByClassName('property-pricing-box');
        lodash.forEach(elements, function (ele) {
            ele.classList.remove('stick');
        });
    }

    $scope.book = function (property) {

        var gtmDataLayerVariables = {};
        gtmDataLayerVariables.hotelName = property.hotelName;
        gtmDataLayerVariables.hotelID = property.hotelCode;
        gtmDataLayerVariables.fromRate = property.rate;

        //Integration with Booking Engine
        var res = areaService.getMainReservation();
        var currentLang = areaService.getLanguage();
        var currentCurrency = areaService.getCurrency();
          var beUrl = $window.beUrl;
        var redirectUrl;
        var qs = '';
        var guestArray;
        var timeSpan;
        var codes;
        var i;
        // create an object to collect params for BE redirect
        var options = {};
        if (res.hasOwnProperty('searchCriteria')) {
            // grab guest counts
            if (res.searchCriteria.hasOwnProperty('guestCounts')) {
                guestArray = res.searchCriteria.guestCounts;
                if (guestArray.length > 0) {
                    for (i = 0; i < guestArray.length; i++) {
                        if (guestArray[i].ageQualifyingCode) {
                            if (guestArray[i].ageQualifyingCode == '10') {
                                options.adults = guestArray[i].count;
                            }
                            if (guestArray[i].ageQualifyingCode == '8') {
                                options.children = guestArray[i].count;
                            }
                            if (guestArray[i].ageQualifyingCode == '7') {
                                options.children2 = guestArray[i].count;
                            }
                        }
                    }
                }
            }
            // grab the dates
            if (res.searchCriteria.hasOwnProperty('timeSpan')) {
                timeSpan = res.searchCriteria.timeSpan;
                if (timeSpan.end) {
                    options.dateOut = formatDate(timeSpan.end);
                }
                if (timeSpan.start) {
                    options.dateIn = formatDate(timeSpan.start);
                }
            }
            // grab the rooms
            if (res.searchCriteria.hasOwnProperty('numberOfUnits')) {
                options.rooms = res.searchCriteria.numberOfUnits;
            }
            // grab codes
            if (res.posSource.hasOwnProperty('requestorIds')) {
                codes = res.posSource.requestorIds;
                if (codes.length > 0) {
                    for (i = 0; i < codes.length; i++) {
                        if (codes[i].codeType == 'DiscountAccessCode') {
                            options.discount = codes[i].id;
                        }
                        if (codes[i].codeType == 'group') {
                            options.groupId = codes[i].id;
                        }
                        if (codes[i].codeType == 'corporate') {
                            options.identifier = codes[i].id;
                        }
                        if (codes[i].codeType == 'travelagent') {
                            options.iata = codes[i].id;
                        }
                    }
                }
            }
        }
        if (currentLang) {
            options.languageId = currentLang.languageCode;
        }
        if (currentCurrency) {
            options.currency = currentCurrency.currencyCode;
        }


        // check the default selected rate plan if user doesnt select anything.
        if (!$scope.selectedRatePlan) {
            if (property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
                $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
            }
        } else {
            //check if the selected property has the rateplan code which is in the scope.
            if ($scope.selectedRatePlan.packageCode && property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
                //loop through rateplanlist packages and check if the selected package in scope is present in the list.
                var packageFlag = false;
                var packagesList = property.ratePlanList[2];
                for (var i = 0; i < packagesList.length; i++) {
                    if (packagesList[i].packageCode == $scope.selectedRatePlan.packageCode) {
                        packageFlag = true;
                    }
                }
                if (!packageFlag) {
                    $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
                }
            }
            if ($scope.selectedRatePlan.ratePlanCode && property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
                //loop through rateplanlist rateplans and check if the selected rateplan in scope is present in the list.
                var ratePlanFlag = false;
                var ratePlanList = property.ratePlanList[1];
                for (var i = 0; i < ratePlanList.length; i++) {
                    if (ratePlanList[i].ratePlanCode == $scope.selectedRatePlan.ratePlanCode) {
                        ratePlanFlag = true;
                    }
                }
                if (!ratePlanFlag) {
                    $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
                }
            }
            //Group Code scenario
            if ($scope.selectedRatePlan.ratePlanCode && property.defaultRateInfo != undefined && property.defaultRateInfo.rateType.toLowerCase() == 'group') {
                $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
            }

        }
        if ($scope.selectedRatePlan) {
            if (property.defaultRateInfo != undefined && property.defaultRateInfo.rateType.toLowerCase() == 'group') {
                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.ratePlanCode;
                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.name;
                gtmDataLayerVariables.ratePlanType = 'GROUP';
                options.groupId = $scope.selectedRatePlan.ratePlanCode;
            } else if ($scope.selectedRatePlan.ratePlanCode) {
                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.ratePlanCode;
                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.name;
                gtmDataLayerVariables.ratePlanType = 'REGULAR';
                //Check if the default rate plan code in scope is present in the selected property
                var propertyRatePlans = property.ratePlans;
                if (propertyRatePlans.length > 0) {
                    for (var i = 0; i < propertyRatePlans.length; i++) {
                        if (propertyRatePlans[i].ratePlanCode == $scope.selectedRatePlan.ratePlanCode) {
                            options.ratePlanId = $scope.selectedRatePlan.ratePlanCode;
                            break;
                        }
                    }

                    //Set the selected rate plan in scope
                    if (!options.ratePlanId) {
                        if (property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
                            $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
                            if ($scope.selectedRatePlan.packageCode) {
                                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.packageCode;
                                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.packageName;
                                gtmDataLayerVariables.ratePlanType = 'PACKAGE';
                                options.packageId = $scope.selectedRatePlan.packageCode;
                            } else if ($scope.selectedRatePlan.ratePlanCode) {
                                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.ratePlanCode;
                                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.name;
                                gtmDataLayerVariables.ratePlanType = 'REGULAR';
                                options.ratePlanId = $scope.selectedRatePlan.ratePlanCode;
                            }
                        }
                    }


                }

            } else if ($scope.selectedRatePlan.packageCode) {
                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.packageCode;
                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.packageName;
                gtmDataLayerVariables.ratePlanType = 'PACKAGE';
                //Check if the default rate plan code in scope is present in the selected property
                var propertyPackages = property.packages;
                if (propertyPackages.length > 0) {
                    for (var i = 0; i < propertyPackages.length; i++) {
                        if (propertyPackages[i].packageCode == $scope.selectedRatePlan.packageCode) {
                            options.packageId = $scope.selectedRatePlan.packageCode;
                            break;
                        }
                    }

                    //Set the selected rate plan in scope
                    if (!options.packageId) {
                        if (property != undefined && property.ratePlanList != undefined && property.ratePlanList.length > 0) {
                            $scope.selectedRatePlan = angular.copy(property.ratePlanList[0]);
                            if ($scope.selectedRatePlan.packageCode) {
                                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.packageCode;
                                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.packageName;
                                gtmDataLayerVariables.ratePlanType = 'PACKAGE';
                                options.packageId = $scope.selectedRatePlan.packageCode;
                            } else if ($scope.selectedRatePlan.ratePlanCode) {
                                gtmDataLayerVariables.ratePlanID = $scope.selectedRatePlan.ratePlanCode;
                                gtmDataLayerVariables.ratePlanName = $scope.selectedRatePlan.name;
                                gtmDataLayerVariables.ratePlanType = 'REGULAR';
                                options.ratePlanId = $scope.selectedRatePlan.ratePlanCode;
                            }

                        }
                    }
                }

            }
        }
        gtmDataLayerVariables.destination = angular.copy(areaService.getDestinationData());
        gtmDataLayerVariables.filters = angular.copy(areaService.getMainReservation().searchCriteria);
        if (areaFactory.getUxConfiguration().destinationSearchType.toLowerCase() === 'proximity') {
            gtmDataLayerVariables.filters.destinationSearch = angular.copy(areaService.getDestinationData());
        }

        var languageValue = (areaService.getLanguage() === undefined) ? areaFactory.getDefaultCurrency().languageCode : areaService.getLanguage().languageCode;
        gtmDataLayerVariables.language = angular.copy(languageValue);

        var currencyValue = (areaService.getCurrency() === undefined) ? areaFactory.getCurrentCurrency().currencyCode : areaService.getCurrency().currencyCode;
        gtmDataLayerVariables.currency = angular.copy(currencyValue);

        areaService.setGtmDataLayerPropertyVariables(gtmDataLayerVariables);
        options.portal = chainCode;

        //create the redirect url
        for (var key in options) {
            if (options.hasOwnProperty(key)) {
                qs += '&' + key + '=' + options[key]
            }
        }

        qs = qs.substring(1);
        redirectUrl = beUrl + property.hotelCode + '?' + qs;
        $window.location = redirectUrl;
    }
    function formatDate(inputDate) {
        var dateArray = inputDate.split('-');
        return dateArray[1] + '/' + dateArray[2] + '/' + dateArray[0];

    }

    function scrollPropertyDetailsUp(property) {
        $timeout(function () {
            var navBarHeight = document.getElementsByTagName('nav')[0].offsetHeight;
            var roomHeight = 0;
            if ($scope.displayTypes.displayGridView == true) {
                if (document.getElementsByClassName('gridview-gridcard cardGrid is-selected')[0]) {
                    roomHeight = document.getElementsByClassName('gridview-gridcard cardGrid is-selected')[0].getBoundingClientRect().top + document.getElementsByClassName('gridview-gridcard cardGrid is-selected')[0].offsetHeight + 12;
                }
            } else if ($scope.displayTypes.displayListView == true) {
                if (document.getElementsByClassName('listview-each cardList is-selected')[0]) {
                    roomHeight = document.getElementsByClassName('listview-each cardList is-selected')[0].getBoundingClientRect().top + document.getElementsByClassName('listview-each cardList is-selected')[0].offsetHeight + 12;
                }
            }

            if (document.getElementsByClassName('MaxWidth-logo-wrap')[0]) {
                navBarHeight = navBarHeight + document.getElementsByClassName('MaxWidth-logo-wrap')[0].offsetHeight;
            }

            var thisTopY = window.pageYOffset + roomHeight;

            $document.scrollTopAnimated(thisTopY - navBarHeight, 500);

        }, 500);
    }


    function toggleDetail(gridNumber) {
        if (gridNumber) {
            $scope.showDetails = true;
        } else {
            $scope.showDetails = false;
        }
        $scope.myGridNumber = gridNumber;
    }

    $scope.$watch('displayTypes', function () {
        //Do not remove the below four lines
        oldGridNumber = null;
        $scope.prevOpenedPropertyId = null;
        $scope.showDetails = false;
        $scope.myGridNumber = null;
        $scope.showMapViewPropertyDetails = false;
        $scope.hideMapView = false;


        if ($scope.displayTypes.displayListView === true) {
            $scope.listView = "list-list";
            $scope.mapView = "map-none";
            $scope.gridView = "list-grid";
            $scope.displayTypes.displayGridView = false;
            $scope.displayTypes.displayMapView = false;
            if ($scope.resultloadMore == "loadMore-md") {
                $scope.resultloadMore = "loadMore-md-list";
            }

        } else if ($scope.displayTypes.displayGridView === true) {
            $scope.listView = "list-none";
            $scope.gridView = "grid-grid";
            $scope.mapView = "map-none";
            if ($scope.resultloadMore == "loadMore-md-list") {
                $scope.resultloadMore = "loadMore-md";
            }
            $scope.displayTypes.displayListView = false;
            $scope.displayTypes.displayMapView = false;
        } else if ($scope.displayTypes.displaymapView === true) {
            $scope.listView = "list-none";
            $scope.gridView = "grid-none";
            $scope.mapView = "map-map";
            $scope.displayTypes.displayGridView = false;
            $scope.displayTypes.displayListView = false;
        }

    }, true);

    $scope.$watch('selectedDetail', function () {
        //console.log("selectedDetail:" + $scope.selectedDetail.key);
    }, true);

    $scope.$watch('mapDisplayHotelList', function () {
        //console.log("mapDisplayHotelList:" + $scope.mapDisplayHotelList);
    }, true);


    $scope.$watch(function(){
        return $document.innerHeight();
    },function onHeightChange(newValue, oldValue){
        if($scope.showLoadMore )
            checkScroller();
    });


    $scope.$watch('selectMark', function () {
        //alert("selectMark in controller:" + $scope.selectMark.key);

    }, true);

    $scope.addProperties = function () {

        // $scope.filterBySelection();

        //var listLength = $scope.hotelList.length;
        //alert("listLength:" + listLength)
        //
        //if ($scope.tempHotelList.length < listLength) {
        //    for (var k = 0; k < 24; k++) {
        //        if ($scope.tempHotelList.length < listLength) {
        //            var tempLength = $scope.tempHotelList.length;
        //            $scope.tempHotelList.push($scope.hotelList[tempLength]);
        //        }
        //    }
        //    areaFactory.setDisplayHotelList($scope.tempHotelList);
        //    restructure(v);
        //}
        //
        //if ($scope.tempHotelList.length < listLength) {
        //    $scope.showLoadMore = true;
        //}

        //console.log("$scope.tempHotelList:" + JSON.stringify($scope.tempHotelList));
    };

    $scope.loadMoreHotels = function (fromScrollLoad) {
        hotelLoadProcess = true;
        if ($scope.availCall) {
            if($scope.showLoadMore)
            {
                isLoadMore = true;
                if(fromScrollLoad) {
                    areaService.setIsLoadMoreAvail(true);
                }
                hotelDataService.loadAvailHotels(true);
            }
        }
        else {
            ($rootScope.bgHideSpinner) ? ($rootScope.showSpinner = true) : ($rootScope.bgHideSpinner = true);
            //$rootScope.$broadcast(EVENT.HOTELS_DATA_READY);
            removeScrollForLoadMore();
            $scope.showLoadMore = false;
            updateHoteListView($scope.tempHotelList.concat(intFilteredHotelList.slice(0, areaService.getMaxAvailResponseLimit())));
            intFilteredHotelList.splice(0, areaService.getMaxAvailResponseLimit());  // REMOVE HOTELS FROM LIST SINCE IT'S ALREADY MOVE TO VIEW
            hotelLoadProcess = false;
            try {
                $scope.$apply();
            }catch (e){}
            $rootScope.showSpinner = false;
            if (intFilteredHotelList.length > 0) // IF ANY MORE DATA EXIST
            {
                $scope.showLoadMore = true;
                addScrollForLoadMore();
            }
        }
    }

    $scope.$on(EVENT.APPLY_UI_FILTER, function () {

        toaster.clear();
        if ($scope.availCall) {

            updateHoteListView($scope.filterBySelection(originalHotelList));
        }
        else {
            intFilteredHotelList = $scope.filterBySelection(originalHotelList);
            $scope.showLoadMore = false;
            removeScrollForLoadMore();
            updateHoteListView(intFilteredHotelList.slice(0, areaService.getMaxAvailResponseLimit()));
            intFilteredHotelList.splice(0, areaService.getMaxAvailResponseLimit());  // REMOVE HOTELS FROM LIST SINCE IT'S ALREADY MOVE TO VIEW
            if (intFilteredHotelList.length > 0) // IF ANY MORE DATA EXIST
            {
                $scope.showLoadMore = true;
                addScrollForLoadMore();
               // checkScroller();
            }
        }

    });

    function updateHotelListBeforeAvail() {
    }

    $scope.$on(EVENT.HOTELS_DATA_READY, function () {
        hotelLoadProcess = false;
//        removeScrollForLoadMore();
        $scope.showLoadMore = false;
        $scope.closePropertyDetails();
        //$scope.hotelList = hotelDataService.getHotelList();
        $scope.hotelList = hotelDataService.getIntHotelList();
        //Do not comment below function.
        $scope.formatRatePlans($scope.hotelList);
        //originalHotelList = angular.copy($scope.hotelList);
        originalHotelList = angular.copy($scope.hotelList);
        $scope.availCall = false;

        intFilteredHotelList = $scope.filterBySelection(originalHotelList);

        //$scope.showLoadMore = false;
        //removeScrollForLoadMore();
        updateHoteListView(intFilteredHotelList.slice(0, areaService.getMaxAvailResponseLimit()));
        intFilteredHotelList.splice(0, areaService.getMaxAvailResponseLimit());  // REMOVE HOTELS FROM LIST SINCE IT'S ALREADY MOVE TO VIEW
        if (intFilteredHotelList.length > 0) // IF ANY MORE DATA EXIST
        {
            $scope.showLoadMore = true;
            addScrollForLoadMore();
        }
    });

    /* Load List Of hotels First Time */
    hotelDataService.loadAllHotelData();
    hotelDataService.checkApiCountAndAvailCall();

    function checkScroller(){

        if (hotelLoadProcess || !$scope.showLoadMore || $scope.displayTypes.displaymapView)
            return false;

        if(angular.element($document).height() - 50 <= angular.element($window).height()) {
            hotelLoadProcess = true;
            $scope.loadMoreHotels(true);
        }
    }

    function checkForLoadMore(){
        if (hotelLoadProcess || !$scope.showLoadMore || $scope.displayTypes.displaymapView)
            return false;

        if ((angular.element($window).scrollTop() >= (angular.element($document).height() - angular.element($window).height() - 60))){
            hotelLoadProcess = true;
            $scope.loadMoreHotels(true);
        }
    }

    function addScrollForLoadMore(){
        angular.element($window).on('scroll', checkForLoadMore);
    //    checkForLoadMore();
    }

    function removeScrollForLoadMore(){
        angular.element($window).off("scroll", checkForLoadMore);
    }

//    hotelDataService.loadAllHotelData();

    $scope.$on(EVENT.AVAIL_HOTELS_DATA_READY, function (evt, data) {
        hotelLoadProcess = false;
        if (data == "avail") {
            if (!$scope.availCall && areaFactory.getUxConfiguration().defaultSortOrder > 2  && areaFactory.getUxConfiguration().enableDisplaySortOrderFilter) {
                $scope.filters.sortOrder.defaultSortOrder = angular.copy(areaFactory.getUxConfiguration().defaultSortOrder);
            }
            $scope.showLoadMore = false;
            $scope.availCall = true;
            $scope.closePropertyDetails();
            if (!isAvailCallDone || !isLoadMore) {
                $scope.displayHotelList = [];
                $scope.tempHotelList = [];
                originalHotelList = [];
            }
            isLoadMore = false;
            $scope.hotelList = hotelDataService.getHotelList();

            $scope.formatRatePlans($scope.hotelList);

            if (hotelDataService.getMoreDataEchoToken() != null) {
                $scope.showLoadMore = true;
                addScrollForLoadMore();
            }
            else {
                removeScrollForLoadMore();
            }
            originalHotelList = originalHotelList.concat(angular.copy($scope.hotelList));
        } else {
            $scope.formatRatePlans(originalHotelList);
        }

        $scope.numberOfDays = Math.abs(moment.utc(areaService.getCalendarData().endDate).diff(moment.utc(areaService.getCalendarData().startDate), 'days'));
        isAvailCallDone = true;
        if ($scope.filters.sortOrder.selections.length < 4) {
            $scope.filters.sortOrder.selections.push(
                {
                    "title": "Price(Low to High)",
                    "value": false,
                    "abbrev": $rootScope.translate.global_lowtohigh_ASlowtohighLbl,
                    "sortId": 3,
                    "display": $rootScope.translate.global_lowtohigh_ASlowtohighLbl
                },
                {
                    "title": "Price(High to Low)",
                    "value": false,
                    "abbrev": $rootScope.translate.global_hightolow_AShightolowLbl,
                    "sortId": 4,
                    "display": $rootScope.translate.global_hightolow_AShightolowLbl
                });
        }

        updateHoteListView($scope.filterBySelection(originalHotelList));
        $scope.filters.ifShowFilterOptions = ($scope.uxConfig.enableHotelNameFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("hotels"))
            || ($scope.uxConfig.enableRatePlanFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("ratePlans")) ||
            ($scope.uxConfig.enablePackageTypeFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("packageCategories"));
        if ($scope.changeAbb == true) {
            $scope.changeAbbrev();
        }

        $scope.dupFilters = angular.copy($scope.filters);
        if (areaService.getNoResults() == true) {
            toaster.clear();
            toaster.pop({
                type: "error",
                title: "",
                body: $rootScope.translate["global_noresultsmatchyourrequest_ASnorequest.Lbl"],
                timeout: 3000
            });
            $scope.$emit(EVENT.CLEAR_DESTINATION_FIELD);
            areaService.setNoResults(false);
        }
    //    if($scope.showLoadMore )
   //         checkScroller();
    });

    /** NO HOTEL AVAILABLE FOR AVAIL CALL **/

    $scope.$on(EVENT.AVAIL_HOTELS_DATA_NOT_EXIST, function () {
        hotelLoadProcess = false;
        if (!isLoadMore) {
            $scope.closePropertyDetails();
            $scope.displayHotelList = [];
            $scope.tempHotelList = [];
            $scope.hotelList = [];
            originalHotelList = [];
            isAvailCallDone = true;
            //$scope.addProperties();
        }
        isLoadMore = false;
        isAvailCallDone = true;
        if ($scope.filters.sortOrder.selections.length < 4) {
            $scope.filters.sortOrder.selections.push(
                {
                    "title": "Price(Low to High)",
                    "value": false,
                    "abbrev": $rootScope.translate.global_lowtohigh_ASlowtohighLbl,
                    "sortId": 3,
                    "display": $rootScope.translate.global_lowtohigh_ASlowtohighLbl
                },
                {
                    "title": "Price(High to Low)",
                    "value": false,
                    "abbrev": $rootScope.translate.global_hightolow_AShightolowLbl,
                    "sortId": 4,
                    "display": $rootScope.translate.global_hightolow_AShightolowLbl
                });
        }
        if (!$scope.availCall && areaFactory.getUxConfiguration().defaultSortOrder > 2  && areaFactory.getUxConfiguration().enableDisplaySortOrderFilter) {
            $scope.filters.sortOrder.defaultSortOrder = angular.copy(areaFactory.getUxConfiguration().defaultSortOrder);
        }
        $scope.availCall = true;

        $scope.filters.ifShowFilterOptions = ($scope.uxConfig.enableHotelNameFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("hotels"))
            || ($scope.uxConfig.enableRatePlanFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("ratePlans")) ||
            ($scope.uxConfig.enablePackageTypeFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("packageCategories"));
        if ($scope.changeAbb == true) {
            $scope.changeAbbrev();
        }

        $scope.dupFilters = angular.copy($scope.filters);
        $scope.showLoadMore = false;
        removeScrollForLoadMore();
    });


    $scope.$on(EVENT.LANG_CHANGE, function () {
        var intlObj = {};
        intlObj.currentCurrency = areaService.getCurrency();
        intlObj.currentLanguage = areaService.getLanguage();
        $scope.intlObj = intlObj;
        $scope.currentCurrencyObj = areaService.getCurrency();
        try {
        //    $scope.$apply();
        }
        catch(e){}
    });

    function updateHoteListView(hotelList) {
        if ($scope.hotelList.length > 0 && hotelList.length == 0) {
            toaster.clear();
            toaster.pop({
                type: "error",
                title: "",
                body: $rootScope.translate.page_nonepropavl_ASnonepropavlLbl
            });
        }

        $scope.tempHotelList = angular.copy(hotelList);
        areaFactory.setDisplayHotelList($scope.tempHotelList);
        restructure(v);
    }

    var restructure = function (v) {
        var m = v;
        tempRestructure(m);
    };

    var tempRestructure = function (p) {
        var groups = [];
        var tempHotelList = angular.copy($scope.tempHotelList);
        var chunkSize = p;
        for (var i = 0; i < tempHotelList.length; i += chunkSize) {
            groups.push(tempHotelList.slice(i, i + chunkSize));
        }
        //$scope.displayHotelList = [];
        $scope.displayHotelList = angular.copy(groups);

    };

    var w = angular.element($window);
    var v;
    $scope.$watch(
        function () {
            $scope.screenwidth = $window.innerWidth;
            return $window.innerWidth;
        },
        function (value) {
            $scope.closePropertyDetails();
            if (value < 768) {
                v = 1;
                $scope.resultloadMore = "loadMore-sm";
                $scope.maxiDesLength = 150;
            }
            else if (value < 992 && value >= 768) {
                v = 2;
                if ($scope.displayListView == true) {
                    $scope.resultloadMore = "loadMore-md-list";
                } else {
                    $scope.resultloadMore = "loadMore-md";
                }
                $scope.maxiDesLength = 200;

            }
            else if (value >= 992) {
                v = 3;
                $scope.resultloadMore = "loadMore-lg";
                $scope.maxiDesLength = 300;

            }
            $scope.resize = v;
            restructure(v);

        },
        true
    );

    w.bind('resize', function () {
        $scope.$apply();
    });

    $scope.selectIndex = null;
    $scope.selectHotel = null;

    //$scope.$watch('[selectIndex,selectHotel]', function () {
    //    //alert("selectIndex:"+$scope.selectIndex);
    //    //alert("selectHotel:"+$scope.selectHotel);
    //}, true);


    $scope.clickSelect = function (index, selectHotel) {

        if ($scope.selectMark.key == true) {

        } else {
            $scope.selectIndex = angular.copy(index);
            $scope.selectHotel = angular.copy(selectHotel);
            //$scope.$apply();
        }

    };

    $scope.leaveSelect = function (id) {
        $scope.selectIndex = null;
        $scope.selectHotel = null;
        areaService.setHoverHotelId(id);
        $scope.$broadcast('HOVER_OUT_CLUSTER');
    };

    $scope.showPropertyDetails = function (myGridNumber, id, prevOpenedPropertyId, gridRow) {
        if ($scope.displayTypes.displayGridView == true) {
            return (myGridNumber == gridRow);
        } else if ($scope.displayTypes.displayListView == true) {
            return (id == prevOpenedPropertyId) && $scope.showDetails;
        } else if ($scope.displayTypes.displaymapView === true) {
            return $scope.showMapViewPropertyDetails;
        }
    }

    var keyForVideo = $window.keyForVideo;
    var accountForVideo = $window.accountForVideo;

    $scope.trustSrc = function (srcFiles, srcFile) {
        if ($scope.myInterval != 0) {
            $scope.myInterval = 0;
        }
        var finalSrc;
        if (areaFactory.getUxConfiguration().enableVideoAutoPlay) {
            if (srcFile.sortOrder != undefined && srcFile.sortOrder != 0) {
                finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=false#pause'
            } else if (srcFile.sortOrder == 0) {
                finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=true#pause'
            }
            if (srcFiles[0].active != true) {
                if (srcFile.active == false) {
                    finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=false'
                }
                else if (srcFile.active == true) {
                    finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=true'
                }
            }

        } else {
            finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=false'
            if (srcFile.active == false) {
                finalSrc = srcFile.video + '?key=' + keyForVideo + '&account=' + accountForVideo + '&autoplay=false#pause'
            }
        }

        return $sce.trustAsResourceUrl(finalSrc);
    }

    $scope.showMoreOptions = function () {
        $scope.moreOptions = !$scope.moreOptions;
        if ($scope.moreOptions == false) {
            $scope.limit = 1;
        } else {
            $scope.limit = 200;
        }
    }

    $scope.formatRatePlans = function (hotelList) {
        lodash.forEach(hotelList, function (hotel) {
            hotel.ratePlanList = [];
            hotel.amenityList = [];
            if (hotel.defaultRateInfo != undefined && hotel.defaultRateInfo.ratePlanId != undefined && hotel.defaultRateInfo.rateType != undefined) {
                var defaultRatePlanType = hotel.defaultRateInfo.rateType.toLowerCase();
                var defaultRatePlanId = hotel.defaultRateInfo.ratePlanId;
                hotel.selectedRatePlan = hotel.defaultRateInfo.ratePlanId;
                if (defaultRatePlanType == 'regular' || defaultRatePlanType == 'group') {
                    hotel.defaultRateInfo.isConfidential = false;
                    var index = lodash.findIndex(hotel.ratePlans, function (ratePlan) {
                        return ratePlan.ratePlanCode == defaultRatePlanId;
                    });
                    var defaultRatePlan = hotel.ratePlans[index];
                    var regularRatePlans = lodash.without(hotel.ratePlans, hotel.ratePlans[index]);
                    regularRatePlans.sort(function (a, b) {
                        if (a.sortOrder > b.sortOrder) {
                            return 1;
                        }
                        if (a.sortOrder < b.sortOrder) {
                            return -1;
                        }
                        return 0;
                    });
                    var packageRatePlans = hotel.packages;
                    if (packageRatePlans.length != 0) {
                        packageRatePlans.sort(function (a, b) {
                            if (a.sortOrder > b.sortOrder) {
                                return 1;
                            }
                            if (a.sortOrder < b.sortOrder) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                } else {
                    var index = lodash.findIndex(hotel.packages, function (package) {
                        return package.packageCode == defaultRatePlanId;
                    });
                    var defaultRatePlan = hotel.packages[index];
                    hotel.defaultRateInfo.isConfidential = defaultRatePlan.confidential ? true : false;
                    var packageRatePlans = lodash.without(hotel.packages, hotel.packages[index]);
                    packageRatePlans.sort(function (a, b) {
                        if (a.sortOrder > b.sortOrder) {
                            return 1;
                        }
                        if (a.sortOrder < b.sortOrder) {
                            return -1;
                        }
                        return 0;
                    });
                    var regularRatePlans = hotel.ratePlans;
                    if (regularRatePlans.length != 0) {
                        regularRatePlans.sort(function (a, b) {
                            if (a.sortOrder > b.sortOrder) {
                                return 1;
                            }
                            if (a.sortOrder < b.sortOrder) {
                                return -1;
                            }
                            return 0;
                        });
                    }
                }

                hotel.ratePlanList.push(defaultRatePlan);
                hotel.ratePlanList.push(regularRatePlans);
                hotel.ratePlanList.push(packageRatePlans);
            }
            if (hotel.amenity != null && hotel.amenity != undefined && hotel.amenity.length > 0) {
                var premiumAmenities = [];
                var normalAmenities = [];
                lodash.forEach(hotel.amenity, function (amenity) {
                    if (amenity.premium) {
                        premiumAmenities.push(amenity);
                    } else {
                        normalAmenities.push(amenity);
                    }
                });

                if (premiumAmenities.length != 0) {
                    premiumAmenities.sort(function (a, b) {
                        if (a.sort > b.sort) {
                            return 1;
                        }
                        if (a.sort < b.sort) {
                            return -1;
                        }
                        return 0;
                    });
                }

                if (normalAmenities.length != 0) {
                    normalAmenities.sort(function (a, b) {
                        if (a.name > b.name) {
                            return 1;
                        }
                        if (a.name < b.name) {
                            return -1;
                        }
                        return 0;
                    });
                }

                hotel.amenityList = premiumAmenities.concat(normalAmenities);
            }
        });
    }

    $scope.changeRatePlan = function (ratePlan, isDefault) {
        if (isDefault) {
            $scope.selectedRatePlan = angular.copy($scope.selectedProperty.ratePlanList[0]);
        } else {
            $scope.selectedRatePlan = angular.copy(ratePlan);
        }
    }

    $scope.showRatePolicies = function (ratePlanInfo) {
        $scope.ratePlanDetails = ratePlanInfo;
        if ($scope.ratePlanDetails.packageName) {
            $scope.ratePlanDetails.ratePlanName = angular.copy($scope.ratePlanDetails.packageName);
            $scope.ratePlanDetails.ratePlanDescription = angular.copy($scope.ratePlanDetails.packageDesc);
        } else {
            $scope.ratePlanDetails.ratePlanName = angular.copy($scope.ratePlanDetails.name);
            $scope.ratePlanDetails.ratePlanDescription = angular.copy($scope.ratePlanDetails.rateplanDesc);
        }
        $scope.showRatePlanDetail = true;
        $scope.scrollTopRPPopup = $window.pageYOffset + 'px';
    }

    $scope.hideRatePolicies = function () {
        $scope.showRatePlanDetail = false;
    }

    $scope.gotoBookingEngine = function (property) {

        //This is part of BE-Area Search integration.

//        var dayStringFormat = 'MM/DD/YYYY';
//        var guestsData = areaService.getGuestData();
//        var calendarData = areaService.getCalendarData();
//        var urlOptions = '?adults=' + guestsData.adult + '&children=' + guestsData.children + '&rooms=' + guestsData.rooms + '&dateIn=' + moment(calendarData.startDate).format(dayStringFormat) + '&dateOut=' + moment(calendarData.endDate).format(dayStringFormat);
//        if($scope.selectedRatePlan.ratePlanCode) {
//            var ratePlan = '&ratePlanId=' + $scope.selectedRatePlan.ratePlanCode;
//        } else {
//            var ratePlan = '&prodId=' + $scope.selectedRatePlan.packageCode;
//        }
//        $window.open($window.beUrl + property.hotelCode + urlOptions + ratePlan, "_self");
    }


    $scope.togglePropertyDetailsMapView = function (property, para, fromBubble) {
        if (property == null && para != undefined && fromBubble == true) {
            var index = lodash.findIndex($scope.hotelList, function (hotel) {
                return para == hotel.hotelName + '-' + hotel.hotelCode;
            });
            property = angular.copy($scope.hotelList[index]);
        }
        $scope.togglePropertyDetails(null, property);
        $scope.showMapViewPropertyDetails = true;
        $timeout(function () {
            $scope.hideMapView = true;
        }, 100);

    }

    $scope.toggleMapPhotos = function (view) {
        $scope.propertyDetailsView = view;
    }

    $scope.filterBySelection = function (hotelist) {
        $scope.tempPropertyList = angular.copy(hotelist);
        var filterResult = [];
        var priceRange = {};
        var hotelRate = [];
        var hotelRateAll = [];
        var amenities = [];
        //var package = {};
        //var ratePlan = {};
        //var hotelName = {};
        var originResult = angular.copy(hotelist);
        //var originResult = angular.copy($scope.hotelList);
        var currencyMapAry = areaFactory.getCurrencyMapAry();
        //console.log("BB  $scope.filters.priceRange:"+JSON.stringify($scope.filters.priceRange));

        if (isAvailCallDone) {  // after avail call, only sort by price is done by UI
            if ($scope.uxConfig.hasOwnProperty("enablePriceFilter") && $scope.uxConfig.enablePriceFilter == true) {
                priceRange.min = $scope.filters.priceRange.minValue;
                priceRange.max = $scope.filters.priceRange.maxValue;

                var curCurrency = areaService.getCurrency();
                var priceMin = priceRange.min * currencyMapAry[curCurrency.currencyCode].chainCurrecnyExchangeRate;
                var priceMax = priceRange.max * currencyMapAry[curCurrency.currencyCode].chainCurrecnyExchangeRate;
            }

            var currencyDetail = areaService.getCurrencyDetails();
            var currentSymbol = currencyDetail.currencySymbol;
            angular.forEach(originResult, function (eachHotel) {
                var priceMatch = true;
                var newPrice = $filter('currencyConversionAndSymbolB')(eachHotel.rate, eachHotel.currentCurrency.currencySymbol);
                //console.log("eachHotel.rate:" + eachHotel.rate);
                //console.log("eachHotel.currentCurrency.currencySymbol:" + eachHotel.currentCurrency.currencySymbol);
                //console.log("newPrice:" + newPrice);

                if ($scope.uxConfig.hasOwnProperty("enablePriceFilter") && $scope.uxConfig.enablePriceFilter == true) {
                    if (eachHotel.hasOwnProperty("isAvailable") && eachHotel.isAvailable == true) {

                        if (!eachHotel.hasOwnProperty("rate")) {  // has isAvailable no rate
                            priceMatch = false;

                        } else {  // has rate
                            if ($scope.filters.priceRange.ifMax === true) {// price range max = ceil +

                                if (newPrice < priceRange.min) {
                                    priceMatch = false;
                                }
                            } else {// price max < ceil

                                if (newPrice < priceRange.min || newPrice > priceRange.max) {   // price range max less than ceil                                    priceMatch = false;
                                    priceMatch = false;
                                }
                            }

                        }
                    } else {  // unavailable

                        if ($scope.uxConfig.hasOwnProperty("displayPref") && $scope.uxConfig.displayPref == false) {
                            //allow display unavailable
                            priceMatch = false;
                        }
                    }
                }
                //console.log("priceMatch:" + priceMatch);
                if (priceMatch == true) {
                    filterResult.push(eachHotel);
                }

            });


            if (!$scope.isSortOrderChange  && ($scope.uxConfig.defaultSortOrder === 3 || $scope.uxConfig.defaultSortOrder === 4)) {
                $scope.filters.sortOrder.defaultSortOrder = $scope.uxConfig.defaultSortOrder;

                for (var le = 0; le < $scope.filters.sortOrder.selections.length; le++) {
                    $scope.filters.sortOrder.selections[le].value = false;
                }
                $scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].value = true;

                var filterAvailStr = {
                    "searchResultSortOrder": 0,
                    "starRatings": [],
                    "hotelIds": [],
                    "amenityIds": [],
                    "ratePlanCategory": [],
                    "ratePlanCode": [],
                    priceRange: {
                        maxRate: $scope.filters.priceRange.maxValue,
                        minRate: $scope.filters.priceRange.minValue
                    }
                };

                $scope.allAbbrev = {};

                if ($scope.filters.sortOrder.hasOwnProperty("defaultSortOrder") && $scope.filters.sortOrder.hasOwnProperty("selections")) {
                    $scope.allAbbrev["sortOrder"] = [];
                    if ($scope.cancelFilters == true || $scope.cancelFilters == undefined) {
                        // clear sort order
                    } else {
                        $scope.allAbbrev["sortOrder"].push($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].abbrev);
                    }
                    filterAvailStr.searchResultSortOrder = $scope.filters.sortOrder.defaultSortOrder;

                }

                if ($scope.filters.priceRange.hasOwnProperty("abbrev")) {
                    $scope.allAbbrev["priceRange"] = [];
                    $scope.showRzSlider = false;
                    if ($scope.cancelFilters == true || ($scope.filters.priceRange.minValue == $scope.filters.slider_translate.options.floor &&
                        $scope.filters.priceRange.maxValue == $scope.filters.slider_translate.options.ceil)) {
                        $scope.allAbbrev["priceRange"] = [];
                        $scope.filters.slider_translate.minValue = angular.copy($scope.filters.priceRange.minValue);
                        $scope.filters.slider_translate.maxValue = angular.copy($scope.filters.priceRange.maxValue);
                        // clear priceRange
                    } else {
                        $scope.allAbbrev["priceRange"].push($scope.filters.priceRange.abbrev);
                    }
                }

                if ($scope.filters.hotelRates) {
                    $scope.allAbbrev["hotelRates"] = [];
                    var repArr = [];
                    for (var i = 0; i < $scope.filters.hotelRates.length; i++) {
                        if ($scope.filters.hotelRates[i].value == true) {
                            if (i > -1 && i < 5) {
                                for (var q = 1; q < i + 2; q++) {
                                    repArr.push(q);

                                }
                                $scope.allAbbrev["hotelRates"].push({
                                    "title": $scope.filters.hotelRates[i].title,
                                    "repArr": repArr
                                });

                            }


                            if (i == 5) {  //not rated
                                $scope.allAbbrev["hotelRates"].push({
                                    "title": $scope.filters.hotelRates[i].title,
                                    "repArr": $scope.filters.hotelRates[i].abbrev
                                });

                            }

                            filterAvailStr.starRatings.push(parseInt($scope.filters.hotelRates[i].title));
                            repArr = [];
                        }
                    }

                }



                if ($scope.filters.anoAmen && $scope.filters.anoAmen.length > 0) {
                    $scope.allAbbrev["anoAmen"] = [];
                    for (var j = 0; j < $scope.filters.anoAmen.length; j++) {
                        if ($scope.filters.anoAmen[j].selection == true) {
                            for (var p = 0; p < $scope.filters.anoAmen[j].id.length; p++) {
                                filterAvailStr.amenityIds.push($scope.filters.anoAmen[j].id[p]);
                            }

                            $scope.allAbbrev["anoAmen"].push({
                                "id": $scope.filters.anoAmen[j].id,
                                "abbrev": $scope.filters.anoAmen[j].abbrev
                            });
                        }
                    }

                }

                if ($scope.filters.filterOptions && $scope.filters.filterOptions.length > 0) {
                    $scope.allAbbrev["filterOptions"] = [];
                    $scope.allAbbrev["filterOptionsIfShow"] = false;
                    for (var i = 0; i < $scope.filters.filterOptions.length; i++) {
                        $scope.allAbbrev["filterOptions"].push({});
                        $scope.allAbbrev.filterOptions[i].multiSelectAbbrev = [];
                        $scope.allAbbrev.filterOptions[i].title = $scope.filters.filterOptions[i].title;
                        $scope.allAbbrev.filterOptions[i].abbrev = $scope.filters.filterOptions[i].abbrev;

                        if ($scope.filters.filterOptions[i].title == "PACKAGES" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                            lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                                filterAvailStr.ratePlanCategory.push(val.id);
                                $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                            });
                        }
                        else if ($scope.filters.filterOptions[i].title == "RATE PLANS" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                            lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                                lodash.forEach(val.id, function(idVal) {
                                    filterAvailStr.ratePlanCode.push(idVal);
                                });
                                $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                            });
                        }
                        else if ($scope.filters.filterOptions[i].title == "HOTEL NAMES" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                            lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                                filterAvailStr.hotelIds.push(val.id);
                                $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                            });
                        }

                        if ($scope.allAbbrev.filterOptions[i].title == "PACKAGES") {

                            if ($scope.uxConfig.enablePackageTypeFilter == true && $scope.availCall == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                                $scope.allAbbrev.filterOptions[i].ifShow = true;
                            } else {
                                $scope.allAbbrev.filterOptions[i].ifShow = false;
                            }

                        } else if ($scope.allAbbrev.filterOptions[i].title == "RATE PLANS") {

                            if ($scope.uxConfig.enableRatePlanFilter == true && $scope.availCall == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                                $scope.allAbbrev.filterOptions[i].ifShow = true;
                            } else {
                                $scope.allAbbrev.filterOptions[i].ifShow = false;
                            }

                        } else if ($scope.allAbbrev.filterOptions[i].title == "HOTEL NAMES") {

                            if ($scope.uxConfig.enableHotelNameFilter == true && $scope.availCall == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                                $scope.allAbbrev.filterOptions[i].ifShow = true;
                            } else {
                                $scope.allAbbrev.filterOptions[i].ifShow = false;
                            }

                        }

                        $scope.allAbbrev.filterOptionsIfShow = $scope.allAbbrev.filterOptionsIfShow || $scope.allAbbrev.filterOptions[i].ifShow;
                    }

                }

                //$scope.filterBySelection("changeAbbrev");

                areaService.setFilter($scope.filters);
                areaService.setAvailFilters(filterAvailStr);
            }
            $scope.isSortOrderChange = true;
            var tempUnAvailAry = [];
            if ($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].sortId === 3) {

                function compareD(a, b) {
                    if (a.hotelToChainRate < b.hotelToChainRate)
                        return -1;
                    if (a.hotelToChainRate > b.hotelToChainRate)
                        return 1;
                    return 0;
                }

                filterResult.sort(compareD);

                //var lengthB = filterResult.length;
                for (var lenB = 0; lenB < filterResult.length; lenB++) {
                    if (filterResult[lenB].isAvailable == false) {

                        tempUnAvailAry.push(filterResult.splice(lenB, 1)[0]);
                        //tempUnAvailAry.push(replace[0]);
                        //console.log("lenB >> "+lenB + " :  " +JSON.stringify(tempUnAvailAry[0]));
                        lenB--;
                    }
                }
                filterResult = filterResult.concat(angular.copy(tempUnAvailAry));
                tempUnAvailAry = [];

            } else if ($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].sortId === 4) {
                function compareE(a, b) {
                    if (a.hotelToChainRate < b.hotelToChainRate)
                        return 1;
                    if (a.hotelToChainRate > b.hotelToChainRate)
                        return -1;
                    return 0;
                }

                filterResult.sort(compareE);

                //var lengthc = filterResult.length;
                for (var lenc = 0; lenc < filterResult.length; lenc++) {
                    if (filterResult[lenc].isAvailable == false) {

                        tempUnAvailAry.push(filterResult.splice(lenc, 1)[0]);
                        // tempUnAvailAry.push(replace[0]);
                        lenc--;
                    }
                }
                filterResult = filterResult.concat(angular.copy(tempUnAvailAry));
                tempUnAvailAry = [];

            }

            //filterResult = angular.copy(originResult);

        }
        else { // before avail call, filter by amenity and star rating and then sort by 3 types
            // filter by star
            if ($scope.uxConfig.hasOwnProperty("enableStarRatingFilter") && $scope.uxConfig.enableStarRatingFilter == true) {

                for (var i = 0; i < 6; i++) {
                    if($scope.filters.hotelRates[i])
                    {
                        if ($scope.filters.hotelRates[i].hasOwnProperty("value") && $scope.filters.hotelRates[i].value == true) {
                            //only checked value will be passed in
                            if ($scope.filters.hotelRates[i].title == '5') {
                                hotelRate.push(5);
                                hotelRate.push(6);
                                hotelRate.push(7);
                                hotelRate.push(8);
                                hotelRate.push(9);
                            } else {
                                hotelRate.push(parseInt($scope.filters.hotelRates[i].title));  //pass int of selected star rates
                            }
                        }
                        if ($scope.filters.hotelRates[i].hasOwnProperty("displayRate") && $scope.filters.hotelRates[i].displayRate == true) {
                            //all displayed value will be passed in
                            if ($scope.filters.hotelRates[i].title == '5') {
                                hotelRateAll.push(5);
                                hotelRateAll.push(6);
                                hotelRateAll.push(7);
                                hotelRateAll.push(8);
                                hotelRateAll.push(9);
                            } else {
                                hotelRateAll.push(parseInt($scope.filters.hotelRates[i].title));  //pass int of all displayed star rates
                            }
                        }
                    }
                }
            }

            // filter by amenities
            if ($scope.uxConfig.hasOwnProperty("enableAmenityFilter") && $scope.uxConfig.enableAmenityFilter == true) {
                // for (var j = 0; j < $scope.filters.newAmen.length; j++) {
                //     if ($scope.filters.newAmen[j].hasOwnProperty("selection") && $scope.filters.newAmen[j].selection == true) {
                //         for (var len = 0; len < $scope.filters.newAmen[j].id.length; len++) {
                //             amenities.push($scope.filters.newAmen[j].id[len]);
                //         }
                //     }
                // }
                for (var k = 0; k < $scope.filters.anoAmen.length; k++) {
                    if ($scope.filters.anoAmen[k].hasOwnProperty("selection") && $scope.filters.anoAmen[k].selection == true) {
                        for (var pen = 0; pen < $scope.filters.anoAmen[k].id.length; pen++) {
                            amenities.push($scope.filters.anoAmen[k].id[pen]);
                        }
                    }
                }
            }


            // get filter result
            angular.forEach(originResult, function (eachHotel) {

                var amenity = [];
                var amenityMatch = true;
                var hotelRateMatch = true;

                if ($scope.uxConfig.hasOwnProperty("enableStarRatingFilter") && $scope.uxConfig.enableStarRatingFilter == true) {
                    if (hotelRate.length > 0) {  //checked some ratings

                        if (eachHotel.hasOwnProperty("starRating") && eachHotel.starRating == "Not Rated") {
                            if (hotelRate.indexOf(0) < 0) {
                                hotelRateMatch = false;
                            }
                        } else if (eachHotel.hasOwnProperty("starRating") && eachHotel.starRating != "Not Rated") {
                            if (hotelRate.indexOf(parseInt(eachHotel.starRating)) < 0) {
                                hotelRateMatch = false;
                            }
                        } else {
                            hotelRateMatch = false;
                        }

                    } else {
                        if (hotelRateAll.length > 0) {   // none star rating is selected == select all displayed rating

                            if (eachHotel.hasOwnProperty("starRating") && eachHotel.starRating == "Not Rated") {
                                if (hotelRateAll.indexOf(0) < 0) {
                                    hotelRateMatch = false;
                                }
                            } else if (eachHotel.hasOwnProperty("starRating") && eachHotel.starRating != "Not Rated") {
                                if (hotelRateAll.indexOf(parseInt(eachHotel.starRating)) < 0) {
                                    hotelRateMatch = false;
                                }
                            } else {
                                hotelRateMatch = false;
                            }

                        }
                    }

                }


                if ($scope.uxConfig.hasOwnProperty("enableAmenityFilter") && $scope.uxConfig.enableAmenityFilter == true) {
                    amenityMatch = false;
                    if (eachHotel.hasOwnProperty("amenity") && eachHotel.amenity.length > 0) {
                        for (var l = 0; l < eachHotel.amenity.length; l++) {
                            var name = eachHotel.amenity[l].id;
                            amenity.push(name);
                        }
                    } // get all amenities' id

                    if (amenities.length === 0) {
                        amenityMatch = true;
                    } else {
                        for (var m = 0; m < amenities.length; m++) {
                            if (amenity.indexOf(amenities[m]) > -1) {
                                amenityMatch = true;
                            }

                        }   // if one id of selected amenities is in hotel amenity
                    }  // from 'and' to 'or' check on 06/09/2017

                }
                if (amenityMatch == true && hotelRateMatch == true) {
                    filterResult.push(eachHotel);
                } else {
                }


            });

            // sort by 3 types
            if ($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].sortId === 0) {
                //alert("compareA");
                function compareA(a, b) {
                    if (a.hotelName < b.hotelName)
                        return -1;
                    if (a.hotelName > b.hotelName)
                        return 1;
                    return 0;
                }

                filterResult.sort(compareA);
            } else if ($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].sortId === 1) {
                //alert("compareB");

                function compareB(a, b) {
                    if (a.hotelName < b.hotelName)
                        return 1;
                    if (a.hotelName > b.hotelName)
                        return -1;
                    return 0;
                }

                filterResult.sort(compareB);
            } else if ($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].sortId === 2) {

                function compareC(a, b) {
                    if (a.starRating < b.starRating)
                        return 1;
                    if (a.starRating > b.starRating)
                        return -1;
                    return 0;
                }

                filterResult.sort(compareC);
                var tempNotRateAry = [];
                //var length = filterResult.length;
                for (var len = 0; len < filterResult.length; len++) {
                    if (filterResult[len].starRating == "Not Rated") {
                        tempNotRateAry.push(filterResult.splice(len, 1)[0]);
                        //filterResult.push(replace[0]);
                        len--;
                    }
                }
                filterResult = filterResult.concat(angular.copy(tempNotRateAry));
                tempNotRateAry = [];
            }
        }

        areaService.setFilterAbbr($scope.allAbbrev);
        return filterResult;

    }

    $scope.shuffleMapList = function() {
        $scope.$broadcast('REFRESH_MAP');
    }

}

searchresultsController.$inject = ["$scope", "$rootScope", "$window", "apiFactory", "$document", "$timeout", "areaFactory", "EVENT", "hotelDataService", "$sce", "lodash", "areaService", "toaster", "$filter"];
