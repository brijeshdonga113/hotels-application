/**
 * Created by sramani on 3/16/2017.
 */
angular.module("TravelClApp").directive("toggleArrow",toggleArrow)

function toggleArrow() {
    return {
        restrict: 'E',
        templateUrl: './common/toggleArrow.html'
    }
}