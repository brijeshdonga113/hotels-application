angular.module('TravelClApp')
    .factory('navDataFactory', ['areaService', 'areaFactory', '$rootScope', navDataFactory]);

function navDataFactory(areaService, areaFactory, $rootScope){

    return {
        "stepsById": {
            "guestsrooms": {
                "id": "guestsrooms",
                "label": "Guests & Rooms",
                "guests":0,
                "rooms":0
            },
            "dates": {
                "id": "dates",
                "label": "Dates of Stay"
            }
        },

        "steps": [
            "guestsrooms",
            "dates"
         ],
        navToggle:{
            datesSelected: true
        }
    };

};
