angular.module('TravelClApp')
    .directive('navBar', navBar)

function navBar() {
    return {
        restrict: 'E',
        templateUrl: './navbar/navbar.html',
        controller: NavbarController
    }
};
