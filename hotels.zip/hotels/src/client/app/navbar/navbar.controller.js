function NavbarController($filter, $log, $rootScope, $scope, $state, areaFactory, navDataFactory, areaService, EVENT, $window, apiFactory,  $timeout, $document, toaster, hotelDataService, googleLocationService) {

    var filteredDestination = {};
    var isDateError = false;
    var uxConfig = areaFactory.getUxConfiguration();
    var chainCode = $window.chainCode;
    var destinationSearchObj = {} ;
    $scope.location = "";
    $scope.chainInfo = areaFactory.getChainInfo();
    $scope.occupancyInfo = $scope.chainInfo.occupancyInfo;
    $scope.dateDisplay = $rootScope.translate.global_selectdates_ASselectdatesLbl;
    $scope.googleSearchEnable = true;
    $rootScope.fullWidthLogoEnabled = false;
    $scope.visibleMonths =  uxConfig.calendarConfig.visibleMonths;
    $scope.hideCloseDestination = false;

    var hideCountry = !areaFactory.getUxConfiguration().showCountryDestination;
    var hideRegion = !areaFactory.getUxConfiguration().showRegionDestination;
    var hideState = !areaFactory.getUxConfiguration().showStateDestination;
    var hideCity = !areaFactory.getUxConfiguration().showCityDestination;
    var hideNeighborhood = !areaFactory.getUxConfiguration().showNeighborhoodDestination;

   /// var isDestinationOutSideClick = false;

    if(uxConfig.calendarConfig && (uxConfig.calendarConfig.visibleMonths === 1)) {
        var styleCSS = document.createElement('style');
        styleCSS.type = 'text/css';
        styleCSS.innerHTML = '.calendar.right {display: none !important}';
        if (document.getElementsByTagName('head')[0]) {
            document.getElementsByTagName('head')[0].appendChild(styleCSS);
        }
    }



    $scope.dates = areaService.getCalendarData();
    if($scope.dates.startDate && $scope.dates.endDate)
    {
        $scope.dateDisplay = moment($scope.dates.startDate).format('MMM DD') +" - "+ ((moment($scope.dates.startDate).format('MMM')==moment($scope.dates.endDate).format('MMM'))?moment($scope.dates.endDate).format('DD'):moment($scope.dates.endDate).format('MMM DD'));
    }

    $scope.guestData = areaService.getGuestData();

    var tempDestination = areaService.getDestinationData();
    if(tempDestination)
    {
        if(tempDestination.destinationSearch)
        {
            var country = tempDestination.destinationSearch.country;
            var region = tempDestination.destinationSearch.region;
            var state = tempDestination.destinationSearch.state;
            var city = tempDestination.destinationSearch.city;
            var neighborhood = tempDestination.destinationSearch.neighborhood;
            var destinationText = "";

            if(!hideCountry && country) {
                destinationText = destinationText + country;
            } else {
                destinationText += "";
            }

            if(!hideRegion && region) {
                if(destinationText.length > 0) {
                    destinationText += ", " + region;
                } else {
                    destinationText += region;
                }
            } else {
                destinationText += "";
            }

            if(!hideState && state) {
                if(destinationText.length > 0) {
                    destinationText += ", " + state;
                } else {
                    destinationText += state;
                }
            } else {
                destinationText += "";
            }

            if(!hideCity && city) {
                if(destinationText.length > 0) {
                    destinationText += ", " + city;
                } else {
                    destinationText += city;
                }
            } else {
                destinationText += "";
            }

            if(!hideNeighborhood && neighborhood) {
                if(destinationText.length > 0) {
                    destinationText += ", " + neighborhood;
                } else {
                    destinationText += neighborhood;
                }
            } else {
                destinationText += "";
            }

            $scope.location = destinationText.replace(/::/g,",");
        }
        else if(tempDestination.geoPosition)
        {
            $scope.location = tempDestination.geoName;
        }
    }

    navDataFactory.stepsById.guestsrooms.guests = parseInt($scope.guestData.adult) + parseInt($scope.guestData.children) + parseInt($scope.guestData.infant);//$scope.guestData.adult;
    navDataFactory.stepsById.guestsrooms.rooms = $scope.guestData.rooms;

    var curDate = new Date();
    $scope.todayDate = moment();

    function updateCalendarConfig()
    {
        moment.locale('en');
            moment.locale('en', {
                monthsShort : [$rootScope.translate.global_jan_ASjanLbl,
                    $rootScope.translate.global_feb_ASfebLbl,
                    $rootScope.translate.global_mar_ASmarLbl,
                    $rootScope.translate.global_apr_ASaprLbl,
                    $rootScope.translate.global_may_ASmayLbl,
                    $rootScope.translate.global_jun_ASjunLbl,
                    $rootScope.translate.global_jul_ASjulLbl,
                    $rootScope.translate.global_aug_ASaugLbl,
                    $rootScope.translate.global_sep_ASsepLbl,
                    $rootScope.translate.global_oct_ASoctLbl,
                    $rootScope.translate.global_nov_ASnovLbl,
                    $rootScope.translate.global_dec_ASdecLbl]
            });
            if($scope.dates.startDate && $scope.dates.startDate.locale)
            {
                $scope.dates.startDate.locale('en', {
                    monthsShort : [$rootScope.translate.global_jan_ASjanLbl,
                        $rootScope.translate.global_feb_ASfebLbl,
                        $rootScope.translate.global_mar_ASmarLbl,
                        $rootScope.translate.global_apr_ASaprLbl,
                        $rootScope.translate.global_may_ASmayLbl,
                        $rootScope.translate.global_jun_ASjunLbl,
                        $rootScope.translate.global_jul_ASjulLbl,
                        $rootScope.translate.global_aug_ASaugLbl,
                        $rootScope.translate.global_sep_ASsepLbl,
                        $rootScope.translate.global_oct_ASoctLbl,
                        $rootScope.translate.global_nov_ASnovLbl,
                        $rootScope.translate.global_dec_ASdecLbl]
                });
            }

            if($scope.dates.endDate && $scope.dates.endDate.locale)
            {
                $scope.dates.endDate.locale('en', {
                    monthsShort : [$rootScope.translate.global_jan_ASjanLbl,
                        $rootScope.translate.global_feb_ASfebLbl,
                        $rootScope.translate.global_mar_ASmarLbl,
                        $rootScope.translate.global_apr_ASaprLbl,
                        $rootScope.translate.global_may_ASmayLbl,
                        $rootScope.translate.global_jun_ASjunLbl,
                        $rootScope.translate.global_jul_ASjulLbl,
                        $rootScope.translate.global_aug_ASaugLbl,
                        $rootScope.translate.global_sep_ASsepLbl,
                        $rootScope.translate.global_oct_ASoctLbl,
                        $rootScope.translate.global_nov_ASnovLbl,
                        $rootScope.translate.global_dec_ASdecLbl]
                });
            }

        $scope.options = {
                locale: {
                    firstDay : uxConfig.calendarConfig.weekFormat?uxConfig.calendarConfig.weekFormat:0,
                    format: "MMM DD",
                    customRangeLabel: 'Custom range',
                    daysOfWeek:[$rootScope.translate.global_su_ASsuLbl,
                        $rootScope.translate.global_mo_ASmoLbl,
                        $rootScope.translate.global_tu_AStuLbl,
                        $rootScope.translate.global_we_ASweLbl,
                        $rootScope.translate.global_th_ASthLbl,
                        $rootScope.translate.global_fr_ASfrLbl,
                        $rootScope.translate.global_sa_ASsaLbl],

                    monthNames:[$rootScope.translate.global_jan_ASjanLbl,
                        $rootScope.translate.global_feb_ASfebLbl,
                        $rootScope.translate.global_mar_ASmarLbl,
                        $rootScope.translate.global_apr_ASaprLbl,
                        $rootScope.translate.global_may_ASmayLbl,
                        $rootScope.translate.global_jun_ASjunLbl,
                        $rootScope.translate.global_jul_ASjulLbl,
                        $rootScope.translate.global_aug_ASaugLbl,
                        $rootScope.translate.global_sep_ASsepLbl,
                        $rootScope.translate.global_oct_ASoctLbl,
                        $rootScope.translate.global_nov_ASnovLbl,
                        $rootScope.translate.global_dec_ASdecLbl]
                },
                parentEl:'#datepickerContainer',
                autoUpdateInput: false,
                autoApply: true,
                eventHandlers:
                {
                    'show.daterangepicker': function(ev, picker) {
                        $rootScope.toggle.guestMenu = false;
                        $rootScope.toggle.intlMenu = false;
                        $rootScope.toggle.datesMenu = true;
                        $rootScope.toggle.searchMenu = false;
                        $scope.hideCloseDestination = false;
                        $rootScope.toggle.showFilter = false;
                    },
                    'hide.daterangepicker': function(ev, picker) {
                        $rootScope.toggle.datesMenu = false;
                    }
                },
                "dateLimit": {
                    "days": 30
                },
                "maxDate":moment().add('months', uxConfig.calendarConfig.monthsToLookAhead?uxConfig.calendarConfig.monthsToLookAhead:18).date(0),
                "linkedCalendars": (uxConfig.calendarConfig && (uxConfig.calendarConfig.visibleMonths === 1)) ? false : true
            };

        $scope.dates = angular.copy($scope.dates);
    }

    updateCalendarConfig();

    $scope.$on(EVENT.LANG_CHANGE,function(){
        updateCalendarConfig();
    });

    $scope.$watch("dates",function(){
        if($scope.dates.startDate && $scope.dates.startDate.format && $scope.dates.endDate && $scope.dates.endDate.format)
        {
            if(isDateError)
            {
                toaster.clear();
                isDateError = false;
            }
            areaService.setCalendarData($scope.dates);
            $scope.dateDisplay = moment($scope.dates.startDate).format('MMM DD') +" - "+ ((moment($scope.dates.startDate).format('MMM')==moment($scope.dates.endDate).format('MMM'))?moment($scope.dates.endDate).format('DD'):moment($scope.dates.endDate).format('MMM DD'));
        }
    });

    $scope.clickDateField = function ($event) {
        $event.preventDefault();
        document.getElementById("datesOfStayId").blur();
    }

    var brandInfo = areaFactory.getBrandInfo();
    $scope.logoClickURL = brandInfo.homepageURL;
    //To check if branding URL is of correct format.
    if($scope.logoClickURL && !/^(https?):\/\//i.test($scope.logoClickURL) && 'http://'.indexOf($scope.logoClickURL) === -1) {
        $scope.logoClickURL = 'http://' + $scope.logoClickURL;
    }

    $scope.propertyHostName = areaFactory.getChainInfo().chainName;

    // wide and small Logo display according to the device
    //$scope.logo = brandInfo;
   /* if(brandInfo != null)
    {
        if(($scope.logo.type != null) && ($scope.logo.type != "")) {
            if($scope.logo.type === "wide-logo-banner") {
                $rootScope.fullWidthLogoEnabled = true;
                (($scope.logo.source == null) || ($scope.logo.source == "")) ? $scope.wideLogoPath = "null" : $scope.wideLogoPath = $scope.logo.source;
            } else if($scope.logo.type === "small-logo-banner") {
                $rootScope.fullWidthLogoEnabled = false;
                (($scope.logo.source == null) || ($scope.logo.source == "")) ? $scope.smallLogoPath = "null" : $scope.smallLogoPath = $scope.logo.source;
            }
        } else {
            $rootScope.fullWidthLogoEnabled = false;
            $scope.smallLogoPath = "null";
        }
    }*/
    if(brandInfo != null)
    {
        if((brandInfo.smallLogo != null) && (brandInfo.smallLogo != "")) {
            $rootScope.fullWidthLogoEnabled = false;
            $scope.smallLogoPath = brandInfo.smallLogo;
            //if($scope.logo.type === "wide-logo-banner") {
              //  $rootScope.fullWidthLogoEnabled = true;
            //    (($scope.logo.source == null) || ($scope.logo.source == "")) ? $scope.wideLogoPath = "null" : $scope.wideLogoPath = $scope.logo.source;
            //} else if($scope.logo.type === "small-logo-banner") {
             //   $rootScope.fullWidthLogoEnabled = false;
             //   (($scope.logo.source == null) || ($scope.logo.source == "")) ? $scope.smallLogoPath = "null" : $scope.smallLogoPath = $scope.logo.source;
           // }
        }

        if((brandInfo.wideLogo != null) && (brandInfo.wideLogo != "")) {
            $rootScope.fullWidthLogoEnabled = true;
            $scope.wideLogoPath = brandInfo.wideLogo;

        }

    }


    $scope.go = function(logoClickURL) {
        areaService.setOpenNewWindowFlag(true);
        window.open(logoClickURL,"_blank");
    }
    $rootScope.callManageUrlCalender = true;
    //get init HotelDecriptiveInfo2 from script tag
    //$rootScope.translate = hotelFactory.getTranslation();
    // navData is the navbar Data Model temporarily initialized by navDataFactory (a backend mock)
    $rootScope.navData = navDataFactory.stepsById;
    //console.log($rootScope.navData.accommodations.placeholder);
    //get the logo/banner width configuration value.

    //on window resize.
    $scope.resizeCall = function () {
        /* footer.controller.js code moved here from footer */
        $rootScope.windowHeight = ($window.innerHeight - 146);
        $rootScope.windowHeight = $rootScope.windowHeight + "px";
        if(document.getElementById("Site-pageWrapperId"))
            document.getElementById("Site-pageWrapperId").style.minHeight = $rootScope.windowHeight;

        /* navbar.controller.js code */
        var window_width = $window.innerWidth;
        /*if(($scope.hotelLogo != undefined) && ($scope.hotelLogo.wideLogo != null)) {
            if($scope.hotelLogo.wideLogo != "") {
                $timeout(function() {
                    if((window_width < 1201) && ($rootScope.fullWidthLogoEnabled == true)) {
                        $rootScope.fullWidthLogoEnabled = false;
                    } else if((window_width > 1200) && ($rootScope.fullWidthLogoEnabled == false)) {
                        $rootScope.fullWidthLogoEnabled = true;
                    }
                }, 0);
            }
        }*/
        if($scope.wideLogoPath) {
            if($scope.wideLogoPath != "") {
                $timeout(function() {
                    if((window_width < 1201) && ($rootScope.fullWidthLogoEnabled == true)) {
                        $rootScope.fullWidthLogoEnabled = false;
                    } else if((window_width > 1200) && ($rootScope.fullWidthLogoEnabled == false)) {
                        $rootScope.fullWidthLogoEnabled = true;
                    }
                }, 0);
            }
        }
    }
    $window.onresize = function () {
        $scope.resizeCall();
    }
    $scope.resizeCall();

    //$scope.navData = navDataFactory.stepsById;
    $scope.navToggle = navDataFactory.navToggle;
    $scope.goToView = function (state, isSelected) {
        $rootScope.propertyDetailsGSplash = 'display-none';
    };

    $rootScope.toggle = {
        intlMenu: false,
        collapse: true
    };

    $rootScope.openDrawer = function () {
     //   $rootScope.toggle.accommodationDraw = true
    };
    $rootScope.closeDrawer = function () {
      //  $rootScope.toggle.accommodationDraw = false
    };

    $scope.removeAccommodation = function (room, position) {
    }

    /*REMOVE RATEPLAN*/
    /*REMOVE PACKAGE*/

    $scope.clickInternationBar = function(){
        $rootScope.toggle.intlMenu = !$rootScope.toggle.intlMenu;
        $rootScope.toggle.collapse = true
        $rootScope.propertyDetailsGSplash = 'display-none';
        $rootScope.toggle.guestMenu = false;
        $rootScope.toggle.searchMenu = false;
        $scope.hideCloseDestination = false;
        $rootScope.toggle.showFilter = false;

    }

    $scope.clickGuestAndRooms = function(event){
        $rootScope.toggle.guestMenu = !$rootScope.toggle.guestMenu;
        $rootScope.toggle.intlMenu = false;
        $rootScope.toggle.searchMenu = false;
        $scope.hideCloseDestination = false;
        $rootScope.toggle.showFilter = false;
        $rootScope.$broadcast(EVENT.GUEST_ROOM_DROPDOWN_OPEN);

        if($rootScope.showAddCode == true) {
            $rootScope.showAddCode = false;
        }

        if($rootScope.toggle != undefined && $rootScope.toggle.showFilter == true) {
            $rootScope.toggle.showFilter = false;
        }

        event.stopPropagation();
        //      angular.element("#datesOfStayId").clickCancel();
    }

    $scope.$on(EVENT.UPDATE_GUEST_AND_ROOMS,function(){
        $scope.guestData = areaService.getGuestData();
        navDataFactory.stepsById.guestsrooms.guests = parseInt($scope.guestData.adult) + parseInt($scope.guestData.children) + parseInt($scope.guestData.infant);//$scope.guestData.adult;
        navDataFactory.stepsById.guestsrooms.rooms = $scope.guestData.rooms;
        areaService.setGuestData($scope.guestData);
    });

    //START- set the flag is the user is in Mobile view
    $scope.screenWidth = $window.screen.availWidth;
    if($scope.screenWidth <= 420){
        $scope.isMobile = true;
    }else{
        $scope.isMobile = false;
    }
    $window.addEventListener("resize", displayCloseDestination);
    function displayCloseDestination() {
        $scope.screenWidth = $window.screen.availWidth;
        if($scope.screenWidth <= 420){
            $scope.isMobile = true;
        }else{
            $scope.isMobile = false;
        }
    }
    //console.log("$scope.isMobile   :::" + $scope.isMobile)
    //END- set the flag is the user is in Mobile view

    $scope.clickSearchBox= function ($event) {
        $event.stopImmediatePropagation();
        toaster.clear();
        $rootScope.toggle.guestMenu = false;
        $rootScope.toggle.intlMenu = false;
        $rootScope.toggle.searchMenu = true;
        $rootScope.toggle.showFilter = false;
        //Hide the CLOSE button when user is in mobile view
        if($rootScope.toggle.searchMenu && $scope.isMobile){
            $scope.hideCloseDestination = true;
        }else{
            $scope.hideCloseDestination = false;
        }
        if($scope.location == "")
        {
            var intervalObj = setInterval(function() {
                if((document.getElementById("parent-search-accordion").scrollHeight >= document.getElementById("parent-search-accordion").clientHeight ) && (document.getElementById("parent-search-accordion").scrollHeight != 0)) {
                    document.getElementById("parent-search-accordion").scrollTop = 0;
                    document.getElementById("search-filter-accordian").scrollTop = 0;
                    clearInterval(intervalObj);
                }
            });
        }

    }

    $scope.clickSearchDestButton = function()
    {
        $rootScope.toggle.searchMenu = false;
        $scope.hideCloseDestination = false;
        if($scope.dates.startDate && $scope.dates.endDate)
        {
            $rootScope.toggle.collapse = true;
            $rootScope.toggle.intlMenu = false;
            $rootScope.toggle.guestMenu = false;
            $rootScope.toggle.datesMenu = false;

            if($scope.location.trim() == "")
            {
                areaService.setDestinationData({});
            }
            areaService.removeRatePlanId();
            areaService.setAvailSearchStatus(true);
            areaService.setMoreDataEchoToken(0);
            hotelDataService.loadAvailHotels();
        }
        else {
            isDateError = true;
            toaster.clear();
            toaster.pop({
                type: "error",
                title: "",
                body: $rootScope.translate.global_pleaseselectdos_ASpleaseselectdosLbl
            });

        }
        $rootScope.toggle.showFilter = false;


    }

    //START - ManageURL functionality
    var params = $window.params;
    params = params.split("\\");
    if(params != "{}"){
        $scope.destinationSearch = false;
        $rootScope.isError = false;
        $scope.params = JSON.parse(params);
        var MainReservation = areaService.getMainReservation();
        var todaysDate;

        if($scope.params.mapzoom && !isNaN($scope.params.mapzoom)) {
            var zoomLevel = parseInt($scope.params.mapzoom);
            if(zoomLevel < 1) {
                areaService.setZoomLevel(1);
            } else if(zoomLevel > 20) {
                areaService.setZoomLevel(20);
            } else {
                areaService.setZoomLevel(zoomLevel);
            }
        }

        if($scope.params.discount || $scope.params.identifier || $scope.params.groupid)
        {
            MainReservation.posSource.requestorIds = [];
            MainReservation.codeType = [];
            MainReservation.allCodes = {};
        }
        //$scope.guestData = {};
        if($scope.params.adults){
            $scope.guestData.adult = parseInt($scope.params.adults);
        }/*else{
            $scope.guestData.adult = $scope.occupancyInfo.defaultAdult;
        }*/
        if($scope.params.children && $scope.occupancyInfo.allowChildren){
            $scope.guestData.children = parseInt($scope.params.children);
        }/*else{
            $scope.guestData.children = $scope.occupancyInfo.defaultChild;
        }*/
        if($scope.params.children2 && $scope.occupancyInfo.allowInfants){
            $scope.guestData.infant = parseInt($scope.params.children2);
        }/*else{
            $scope.guestData.infant = $scope.occupancyInfo.defaultInfants;
        }*/
        if($scope.params.rooms){
            //set room count to default value if Room count is greater than Adults
            if($scope.params.rooms > $scope.guestData.adult){
              //  $scope.guestData.rooms = $scope.occupancyInfo.defaultRooms;
            }else{
                $scope.guestData.rooms = parseInt($scope.params.rooms);
            }
        }/*else{
            $scope.guestData.rooms = $scope.occupancyInfo.defaultRooms;
        }*/
        if($scope.params.datein){
            var validity, dateIn, yearFormat, startDate;
            if($scope.params.datein.indexOf("/") > -1){
                 dateIn = $scope.params.datein.split('/');
                 yearFormat = (dateIn[2]).length;
            }
            if($scope.params.datein.indexOf(",") > -1){
                 dateIn = $scope.params.datein.split(',');
                 yearFormat = (dateIn[2]).length;
            }
            if(yearFormat == 2){
                 validity = moment($scope.params.datein, 'MM/DD/YY').format('MM/DD/YYYY');
            }
            if(yearFormat == 4){
                 validity = moment($scope.params.datein, 'MM/DD/YYYY').format('MM/DD/YYYY');
            }

            if(validity != "Invalid date" && validity != undefined){
                startDate = validity;
            }
        }
        if($scope.params.dateout && startDate){
            var dateOutValidity, dateOut, dateOutYearFormat, endDate;
            if($scope.params.dateout.indexOf("/") > -1){
                dateOut = $scope.params.dateout.split('/');
                 dateOutYearFormat = (dateOut[2]).length;
            }
            if($scope.params.dateout.indexOf(",") > -1){
                dateOut = $scope.params.dateout.split(',');
                 dateOutYearFormat = (dateOut[2]).length;
            }
            if(dateOutYearFormat == 2){
                dateOutValidity = moment($scope.params.dateout, 'MM/DD/YY').format('MM/DD/YYYY');
            }
            if(dateOutYearFormat == 4){
                dateOutValidity = moment($scope.params.dateout, 'MM/DD/YYYY').format('MM/DD/YYYY');
            }
            if(dateOutValidity != "Invalid date" && dateOutValidity != undefined){
                endDate = dateOutValidity;
            }
        }else if(($scope.params.nights || $scope.params.length) && startDate){
            var nrAddDays = parseInt($scope.params.nights || $scope.params.length);
            endDate = (moment(startDate).add('days',nrAddDays).format('MM/DD/YYYY'));
        }
        //set the date dates scope if date in and date out are present.
        if(startDate && endDate){
            $scope.dates.startDate = startDate;
            $scope.dates.endDate = endDate;
        }
        if($scope.params.destination){
            if(!$scope.googleSearchEnable){
                if(JSON.stringify(destinationSearchObj) !== '{}'){
                    $scope.location = $scope.params.destination;
                }else{
                    $scope.location = '';
                }
                var destinationSearch = {};
                destinationSearch.destinationSearch = destinationSearchObj;
                areaService.setDestinationData(destinationSearch);
            }else{
                $scope.destination = $scope.params.destination;
                $scope.location = $scope.params.destination;
                $rootScope.isError = true;
                $rootScope.apiCountValue++;
                googleLocationService.getLocationByPrediction($scope.destination).then(function(data){
                    areaService.setCalendarData($scope.dates);
                    $scope.location = data.geoName;
                    //$rootScope.$broadcast(EVENT.UPDATE_GOOGLE_SEARCH_DESTINATION,data);
                    areaService.setDestinationData(data);
                    $rootScope.apiCountValue--;
                    hotelDataService.checkApiCountAndAvailCall();
                },function(error){
                    areaService.setNoResults(true);
                    $rootScope.apiCountValue--;
                    hotelDataService.checkApiCountAndAvailCall();
                });
            }

        }
        //START - Get Codes from Params
        // checking for group as it always be the latest from Avail.
        if(!$scope.params.groupid){
            if($scope.params.discount){
                var discountCode = $scope.params.discount;
                var codeType = 'Discount';
                areaService.setCodeType(codeType);
                areaService.addToAllCodes(codeType, discountCode);
            }
        }
        if(!$scope.params.groupid){
            if($scope.params.identifier){
                var promoCode = $scope.params.identifier;
                var codeType = 'Corporate';
                areaService.setCodeType(codeType);
                areaService.addToAllCodes(codeType, promoCode);
            }
        }


        if($scope.params.groupid){
            var groupCode = $scope.params.groupid;
            areaService.addGroupCode(groupCode);
        }
        //END - Get Codes from Params
        //Get language from params
        if($scope.params.languageid){
            var selectedLangObj;
            var langId = $scope.params.languageid;
            var languages = areaFactory.getLanguages();
            if(!isNaN(parseInt(langId))){
                for (var i = 0; i < languages.length; i++) {
                    if (languages[i].languageId === parseInt(langId)) {
                        selectedLangObj = languages[i];
                    }
                }
            }else{
                for (var i = 0; i < languages.length; i++) {
                    if (languages[i].languageCode.toLowerCase() === langId.toLowerCase()) {
                        selectedLangObj = languages[i];
                    }
                }
            }
            if(selectedLangObj){
                areaFactory.getTranslations(chainCode,selectedLangObj.languageCode).then(function(respose){
                    $rootScope.$broadcast(EVENT.LANG_CHANGE);
                    if(areaService.isHotelDataReady())
                    {
                        if(areaService.getAvailSearchStatus()){
                            $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_READY, "intl");
                        }else{
                            $rootScope.$broadcast(EVENT.HOTELS_DATA_READY);
                        }
                    }
                    /* try{
                     //   $scope.$apply();
                     }
                     catch(e){}*/
                }
                ,function(error){});
                areaService.setLanguage(selectedLangObj);
                $rootScope.description = selectedLangObj.description;
            }
        }
        //Get currency from params
        if($scope.params.currency){
            var selectedCurrObj;
            var currId = $scope.params.currency;
            var currencies = areaFactory.getCurrencies();
            for (var i = 0; i < currencies.length; i++) {
                if (currencies[i].currencyCode.toLowerCase() === currId.toLowerCase()) {
                    selectedCurrObj = currencies[i];
                }
            }
            if(selectedCurrObj){
                areaService.setCurrency(selectedCurrObj);
                areaService.setCurrencyDetails(selectedCurrObj);
                $rootScope.currentCurrency = selectedCurrObj.currencyCode;
            }
        }
        // Get ratePlanId from Params
        if($scope.params.rateplanid){
            areaService.setRatePlanId($scope.params.rateplanid);
        }

        navDataFactory.stepsById.guestsrooms.guests = parseInt($scope.guestData.adult) + parseInt($scope.guestData.children) + parseInt($scope.guestData.infant);
        navDataFactory.stepsById.guestsrooms.rooms = $scope.guestData.rooms;
        areaService.setGuestData($scope.guestData);
        if($scope.dates.startDate && $scope.dates.endDate){
           $scope.dateDisplay = moment($scope.dates.startDate).format('MMM DD') +" - "+ ((moment($scope.dates.startDate).format('MMM')==moment($scope.dates.endDate).format('MMM'))?moment($scope.dates.endDate).format('DD'):moment($scope.dates.endDate).format('MMM DD'));
            areaService.setCalendarData($scope.dates);
        }
        //Error scenarios
        if($scope.guestData.adult < $scope.guestData.rooms){
            $rootScope.isError = true;
            toaster.error({
                title: "",
                body: $rootScope.translate.global_specifiedrooms_ASspecifiedroomsLbl + $scope.guestData.rooms + " " + $rootScope.translate.global_specifiedadults_ASspecifiedadultsLbl + $scope.guestData.adult
            });
        }

    }
    //END - ManageURL functionality
    $scope.focusOnSearchBox = function($event) {
            $rootScope.toggle.guestMenu = false;
            $rootScope.toggle.intlMenu = false;
            $rootScope.toggle.searchMenu = true;
            $rootScope.toggle.showFilter = false;

            if ($scope.location == "") {
                var intervalObj = setInterval(function () {
                    if ((document.getElementById("search-filter-accordian").scrollHeight >= document.getElementById("search-filter-accordian").clientHeight ) && (document.getElementById("search-filter-accordian").scrollHeight != 0)) {
                        document.getElementById("parent-search-accordion").scrollTop = 0;
                        document.getElementById("search-filter-accordian").scrollTop = 0;
                        clearInterval(intervalObj);
                    }
                });


            }
            $document.on('click touchend', $scope.checkForDocumentClick);
    }

    function isTouchDevice(){
        try{
            document.createEvent("TouchEvent");
            return true;
        }catch(e){
            return false;
        }
    }

    $scope.checkForDocumentClick = function(e) {
           if(e && e.target) {
               if (e.target.name != "destinationField") {
                   if ($rootScope.toggle.searchMenu == true) {
                       e.stopPropagation();
                       e.stopImmediatePropagation();
                       $('#navbar-search-hiericycal').blur();
                       areaService.setDestinationData({destinationSearch: filteredDestination ? filteredDestination.data : {}});
                       $scope.hideCloseDestination = false;
                       $document.off('click touchend', $scope.checkForDocumentClick);
                       $rootScope.toggle.searchMenu = false;
                       try {
                           $scope.$apply();
                       } catch (e) {
                       }
                   }
               }
           }
    }

   /* $scope.blurOnSearchBox = function() {
        if( $rootScope.toggle.searchMenu == true){
            areaService.setDestinationData({destinationSearch:filteredDestination?filteredDestination.data:{}});
            $rootScope.toggle.searchMenu = false;
            $scope.hideCloseDestination = false;
        //    $document.off('click',checkForDocumentClick);
            $scope.$apply();
        }
    }*/

    if(isTouchDevice() && !$scope.googleSearchEnable)
    {
        isMobile = true;
        $rootScope.$watch("toggle.searchMenu",function(){
            if( $rootScope.toggle.searchMenu == true){
                document.body.classList.add("noscroll");
                //document.body.style.overflowY = "hidden"
            }else {
                document.body.classList.remove("noscroll");
                //document.body.style.overflowY = "scroll"
            }

        });

    }

    //START- Handle destination Dropdown functionality
    $scope.removeClickEvent = function(event){
        event.stopPropagation();
    };
    //END- Handle destination Dropdown functionality

    $scope.$on(EVENT.UPDATE_SEARCH_DESTINATION,function(event, data){
      //  console.log("Event from Search Acc  :: "+data.destination);
        $scope.location = data.destinationText.replace(/::/g,",");
        areaService.setDestinationData({destinationSearch:data.destination});
        //$scope.location = data.destination;
    });

    $scope.$on(EVENT.CLEAR_CALENDAR_DATA,function(event, data){
        $scope.dates = {};
        areaService.deleteCalendarData();
    });
    $scope.$on(EVENT.UPDATE_GOOGLE_SEARCH_DESTINATION,function(event, data)
    {
        $scope.location = data.geoName;
        areaService.setDestinationData(data);
    });

    $scope.$on(EVENT.SEARCH_SELECTION_DONE,function(){
        $document.off('click touchend',$scope.checkForDocumentClick);
        $rootScope.toggle.searchMenu = false;
        $scope.hideCloseDestination = false;
    });


    $scope.updatedestination = function(dest)
    {
        filteredDestination = dest;
    }
    $scope.destChange = function(){
        $rootScope.$broadcast(EVENT.DESTINATION_CHANGE, {location:$scope.location});
    }

    if($scope.googleSearchEnable) {
        $scope.$on(EVENT.CLEAR_DESTINATION_FIELD, function() {
            $scope.location = "";
        });
    }

    $scope.clearSelection = function(){
        if(!$scope.googleSearchEnable)
        {
            $('#navbar-search-hiericycal').blur();
        }
        $rootScope.$broadcast(EVENT.SEARCH_SELECTION_DONE);
        $rootScope.$broadcast(EVENT.CLEAR_SELECTION);
    }

    $scope.toggleGuestsAndRoomsMenu = function() {
        if($rootScope.toggle != undefined && $rootScope.toggle.guestMenu == true) {
            $rootScope.toggle.guestMenu = false;
        }
    }

    var subNavTextElement = document.querySelector('.HeaderButton .Header-Calendar .HeaderButton-Select-Value');
    if (subNavTextElement) {
        var inputPlaceholderColor = '#ccc';
        inputPlaceholderColor = getComputedStyle(subNavTextElement).color;
        var styleCSS = document.createElement('style');
        styleCSS.type = 'text/css';
        styleCSS.innerHTML = 'input.HeaderButton-Select-Value::placeholder, input.Header-Location-Search-Field::placeholder{ color:' + inputPlaceholderColor +'!important;}';
        if (document.getElementsByTagName('head')[0]) {
            document.getElementsByTagName('head')[0].appendChild(styleCSS);
        }
    }


}

NavbarController.$inject = ['$filter', '$log', '$rootScope', '$scope', '$state','areaFactory', 'navDataFactory', 'areaService', 'EVENT', '$window', 'apiFactory', '$timeout', '$document', 'toaster', 'hotelDataService', "googleLocationService"];
