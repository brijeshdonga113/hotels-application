angular.module("TravelClApp").directive("googleSearch",["$rootScope","EVENT", "$timeout", "googleLocationService", "hotelDataService", "areaService", "$document", googleSearch])

function googleSearch($rootScope, EVENT, $timeout, googleLocationService, hotelDataService, areaService, $document) {
    return {
        require: 'ngModel',
        restrict: 'A',
        scope:{
            googleEnable:"=",
            elemId:"@",
            clearelemid: "@"
        },

        link:function(scope, element,attr, modelCtrl)
        {
            if(scope.googleEnable) {

                $rootScope.isGoogleLocationProgress = false;
                var locationPre;
               // var geocoder = new google.maps.Geocoder;
                var autocomplete = new google.maps.places.Autocomplete(document.getElementById(scope.elemId), {placeIdOnly: true, types:["geocode"]});
               // var service = new google.maps.places.AutocompleteService();

                $timeout(moveAutoSuggestList,500);

                function moveAutoSuggestList(){
                    if(document.getElementsByClassName("pac-container")[0])
                    {
                        document.getElementById("Header-destination-wrapper").appendChild(document.getElementsByClassName("pac-container")[0]);
                    }
                    else
                        $timeout(moveAutoSuggestList,500);
                }

                function getLocationPrediction(){
                    if(modelCtrl.$dirty && $rootScope.isGoogleLocationProgress)
                    {
                        if(element.val() != "")
                        {

                            googleLocationService.getLocationByPrediction(element.val()).then(function(data){
                               // destinationReady = true;
                                $rootScope.isGoogleLocationProgress = false;
                                $rootScope.$broadcast(EVENT.UPDATE_GOOGLE_SEARCH_DESTINATION,data);
                                if($rootScope.isAvailCallRequire && $rootScope.isAvailCallRequire == true)
                                {
                                    areaService.removeRatePlanId();
                                    hotelDataService.loadAvailHotels();
                                }

                            },function(error){
                               // destinationReady = true;
                                areaService.setNoResults(true);
                                $rootScope.isGoogleLocationProgress = false;
                                if($rootScope.isAvailCallRequire && $rootScope.isAvailCallRequire == true)
                                {
                                    areaService.removeRatePlanId();
                                    hotelDataService.loadAvailHotels();
                                }
                            });

                        }
                        else {
                            //destinationReady = true;

                            $rootScope.$broadcast(EVENT.UPDATE_GOOGLE_SEARCH_DESTINATION, {
                                geoPosition: {
                                }, geoName: ""
                            });
                            $rootScope.isGoogleLocationProgress = false;
                            if($rootScope.isAvailCallRequire && $rootScope.isAvailCallRequire == true)
                            {
                                areaService.removeRatePlanId();
                                hotelDataService.loadAvailHotels();
                            }
                        }

                    }else
                    {
                       // destinationReady = true;
                        $rootScope.isGoogleLocationProgress = false;
                        if($rootScope.isAvailCallRequire && $rootScope.isAvailCallRequire == true)
                        {
                            areaService.removeRatePlanId();
                            hotelDataService.loadAvailHotels();
                        }
                    }
                    modelCtrl.$setPristine();
                }


                document.getElementById(scope.elemId).addEventListener('focus', function(e) {
                    $rootScope.isGoogleLocationProgress = true;
                 //   destinationReady = true;
                });

                document.getElementById(scope.elemId).addEventListener('keydown', function(e) {
                    $rootScope.isGoogleLocationProgress = true;
                    //   destinationReady = false;
                });

                document.getElementById(scope.elemId).addEventListener('blur', function(e){
                    $document.on('click', checkForClearClick);
                    function checkForClearClick(e) {
                        if(e.target) {
                            if(e.target.name != "clearSearch") {
                                $timeout(getLocationPrediction,0);
                            }
                        }
                    }

                });

                //var geocoder = new google.maps.Geocoder;
                //var autocomplete = new google.maps.places.Autocomplete(document.getElementById(scope.elemId), {placeIdOnly: true});


                //autocomplete.setTypes(['address']);
                autocomplete.addListener('place_changed', function () {

                   // destinationReady = true;
                    var place = autocomplete.getPlace();
                   // findLocationPosition(place);
                    if(place.place_id) {
                        $rootScope.isGoogleLocationProgress = false;
                        googleLocationService.getLocationByPlace(place).then(function (data) {
                            $rootScope.$broadcast(EVENT.UPDATE_GOOGLE_SEARCH_DESTINATION, data);

                        }, function (error) {
                            areaService.setNoResults(true);
                        });
                        modelCtrl.$setPristine();
                    }
                });
            }


        }
    }
}