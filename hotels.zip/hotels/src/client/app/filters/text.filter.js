angular.module('TravelClApp')
    .filter('ellipsisFilter', ellipsisFilter)
    .filter('htmlUnicodeFilter', ['$sce', htmlUnicodeFilter])
    .filter('nightsFilter',['$rootScope', nightsFilter])
    .filter('unescapeFilter', unescapeFilter);


function ellipsisFilter() {
    return function (text, length) {
        if (text != undefined && text.length > length) {
            return text.substr(0, length) + "...";
        }
        return text;
    }
};

function htmlUnicodeFilter($sce) {
    return function (val) {
        return $sce.trustAsHtml(val);
    };
};

function nightsFilter($rootScope) {
    return function (number) {
        if (number > 1){
            return number + '  ' + $rootScope.translate.global_nights_ASnightsLbl;
        } else {
            return number + ' ' + $rootScope.translate.global_night_ASnightLbl;
        }
    }
};

function unescapeFilter() {
    var e = null; //only init as-needed, and keep around
    var cache = {};

    function htmlFilter(input) {
        if (cache[input]) {
            return cache[input];
        }
        if (e === null)
            e = document.createElement('textarea');

        e.innerHTML = input;
        var result = e.firstChild.nodeValue;

        cache[input] = result;
        return result;
    }

    return function (input) {
        return htmlFilter(input);
    }
};