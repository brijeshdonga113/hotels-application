angular.module('TravelClApp')
    .filter('currencyConversionAndSymbol', ['$rootScope', 'areaService', '$filter', 'areaFactory', currencyConversionAndSymbol])
    .filter('currencyConversionAndSymbolNew', ['$rootScope', 'areaService', '$filter', 'areaFactory', currencyConversionAndSymbolNew])
    .filter('currencyConversionAndSymbolB', ['$rootScope', 'areaService', '$filter', 'areaFactory', currencyConversionAndSymbolB])
    .filter('currencyConversionNoSymbol', ['areaService', 'areaFactory', currencyConversionNoSymbol])
    .filter('translationsObj', ['$rootScope', 'areaService', '$filter', 'areaFactory', translationsObj])


function currencyConversionAndSymbol($rootScope, areaService, $filter, areaFactory) {
    return function (amount, propCurrency, temp) {
        var propCurrencyExchangeRate;
        var defaultCurrencyValue;
        var convertedAmount;
        var currencyMapAry = areaFactory.getCurrencyMapAry();
        if (propCurrency) {
            for (var i = 0; i < areaFactory.getCurrencies().length; i++) {
                if (areaFactory.getCurrencies()[i].currencyCode == propCurrency) {
                    // propCurrencyExchangeRate = areaFactory.getCurrencies()[i].exchangeRate;
                    propCurrencyExchangeRate = areaFactory.getCurrencies()[i].chainCurrecnyExchangeRate;

                }
            }

            //defaultCurrencyValue = amount / propCurrencyExchangeRate;
            defaultCurrencyValue = amount * propCurrencyExchangeRate;
        }

        var currencyDetails = temp || areaService.getCurrencyDetails();
        // console.log("currencyDetails: " + currencyDetails);
        if (defaultCurrencyValue) {
            ////   console.log("propCurrency:" + propCurrency + " ; currencyDetails.currencyCode : " + currencyDetails.currencyCode);
            if (propCurrency === currencyDetails.currencyCode) {
                convertedAmount = defaultCurrencyValue / propCurrencyExchangeRate;
            } else {
                convertedAmount = defaultCurrencyValue * currencyDetails.exchangeRate;

            }
            ////  console.log("propCurrencyExchangeRateBB:" + propCurrencyExchangeRate);
        } else {
            convertedAmount = amount * currencyDetails.exchangeRate;

        }
        // console.log("convertedAmount: " + convertedAmount);

        var finalAmount;
        if (areaFactory.getUxConfiguration().enabledDisplayRatePricing) {
            convertedAmount = parseFloat(convertedAmount).toFixed(2);
        } else {
            convertedAmount = parseFloat(convertedAmount).toFixed(0)
        }
        if (currencyDetails.currencyDisplayFormat != undefined && currencyDetails.currencyDisplayFormat.precision == 0) {
            convertedAmount = Math.round(convertedAmount);
        }
        //console.log("newAmount:"+newAmount);
        var symbol = currencyDetails.currencySymbol;
        ////convertedAmount = $filter('number')(convertedAmount,2);
        //return symbol + convertedAmount;
        finalAmount = $filter('currency')(convertedAmount, symbol);
        finalAmount = finalAmount.replace(/,/g, ';');
        //console.log("finalAmount:"+finalAmount);

        if (currencyDetails.currencyDisplayFormat != undefined) {
            finalAmount = finalAmount.replace(/\./g, currencyDetails.currencyDisplayFormat.decimalSeparator);
            finalAmount = finalAmount.replace(/;/g, currencyDetails.currencyDisplayFormat.unitSeparator);
        }


        //convertedAmount = $filter('number')(convertedAmount,2);
        if (currencyDetails.currencyDisplayFormat != undefined && ( currencyDetails.currencyDisplayFormat.precision == 0 || !areaFactory.getUxConfiguration().enabledDisplayRatePricing )) {
            if (currencyDetails.currencyDisplayFormat.decimalSeparator != "") {
                finalAmount = finalAmount.substring(0, finalAmount.length - 3)
            } else {
                finalAmount = finalAmount.substring(0, finalAmount.length - 2);
            }

        }

        return finalAmount;
    }
}


function currencyConversionAndSymbolNew($rootScope, areaService, $filter, areaFactory) {
    return function (amount, propCurrency, temp) {
        var propCurrencyExchangeRate;
        var defaultCurrencyValue;
        var convertedAmount;

        if (propCurrency) {
            for (var i = 0; i < areaFactory.getCurrencies().length; i++) {
                //console.log("propCurrency:" + propCurrency);
                if (areaFactory.getCurrencies()[i].currencyCode == propCurrency) {
                    propCurrencyExchangeRate = areaFactory.getCurrencies()[i].exchangeRate;
                    //propCurrencyExchangeRate = areaFactory.getCurrencies()[i].chainCurrecnyExchangeRate;

                }
            }
            defaultCurrencyValue = amount / propCurrencyExchangeRate;
            //defaultCurrencyValue = amount * propCurrencyExchangeRate;

            //console.log("defaultCurrencyValue:" + defaultCurrencyValue);
        }

        var currencyDetails = temp || areaService.getCurrencyDetails();
        //console.log("currencyDetails:" + JSON.stringify(currencyDetails));
        if (defaultCurrencyValue) {
            //console.log("defaultCurrencyValueA");
            if (propCurrency === currencyDetails.currencyCode) {
                //console.log("defaultCurrencyValueB:" + defaultCurrencyValue + "propCurrencyExchangeRate:" + propCurrencyExchangeRate)
                convertedAmount = defaultCurrencyValue / propCurrencyExchangeRate;
            } else {
                //console.log("defaultCurrencyValueC:" + defaultCurrencyValue + "currencyDetails.exchangeRate:" + currencyDetails.exchangeRate)
                convertedAmount = defaultCurrencyValue * currencyDetails.exchangeRate;
            }
        } else {
            //console.log("amount:" + amount + "currencyDetails.exchangeRate:" + currencyDetails.exchangeRate);

            convertedAmount = amount * currencyDetails.exchangeRate;
        }

        var finalAmount;
        //console.log("areaFactory.getUxConfiguration().enabledDisplayRatePricing:" + areaFactory.getUxConfiguration().enabledDisplayRatePricing)
        if (areaFactory.getUxConfiguration().enabledDisplayRatePricing) {
            convertedAmount = parseFloat(convertedAmount).toFixed(2);
        } else {
            convertedAmount = parseFloat(convertedAmount).toFixed(0)
        }
        if (currencyDetails.currencyDisplayFormat != undefined && currencyDetails.currencyDisplayFormat.precision == 0) {
            convertedAmount = Math.round(convertedAmount);
        }
        var symbol = currencyDetails.currencySymbol;
        //console.log("symbol:" + symbol);
        ////convertedAmount = $filter('number')(convertedAmount,2);
        //return symbol + convertedAmount;
        //finalAmount = $filter('currency')(convertedAmount, symbol)

        //finalAmount = finalAmount.replace(/,/g, ';');
        finalAmount = convertedAmount;
        //console.log("finalAmountAA:" + finalAmount);
        //if (currencyDetails.currencyDisplayFormat != undefined) {
        //    finalAmount = finalAmount.replace(/\./g, currencyDetails.currencyDisplayFormat.decimalSeparator);
        //    finalAmount = finalAmount.replace(/;/g, currencyDetails.currencyDisplayFormat.unitSeparator);
        //}
        //console.log("finalAmountBB:" + finalAmount);


        //convertedAmount = $filter('number')(convertedAmount,2);
        //if (currencyDetails.currencyDisplayFormat != undefined && ( currencyDetails.currencyDisplayFormat.precision == 0 || !areaFactory.getUxConfiguration().enabledDisplayRatePricing )) {
        //    if (currencyDetails.currencyDisplayFormat.decimalSeparator != "") {
        //        finalAmount = finalAmount.substring(0, finalAmount.length - 3)
        //    } else {
        //        finalAmount = finalAmount.substring(0, finalAmount.length - 2);
        //    }
        //
        //}
        //console.log("finalAmountCC:" + finalAmount);

        return finalAmount;
    }
}

function currencyConversionAndSymbolB($rootScope, areaService, $filter, areaFactory) {
    return function (amount, propCurrency, temp) {
        var propCurrencyExchangeRate;
        var defaultCurrencyValue;
        var convertedAmount;
        var currencyMapAry = areaFactory.getCurrencyMapAry();
        if (propCurrency) {
            for (var i = 0; i < areaFactory.getCurrencies().length; i++) {
                if (areaFactory.getCurrencies()[i].currencyCode == propCurrency) {
                    // propCurrencyExchangeRate = areaFactory.getCurrencies()[i].exchangeRate;
                    propCurrencyExchangeRate = areaFactory.getCurrencies()[i].chainCurrecnyExchangeRate;

                }
            }

            //defaultCurrencyValue = amount / propCurrencyExchangeRate;
            defaultCurrencyValue = amount * propCurrencyExchangeRate;
        }

        var currencyDetails = temp || areaService.getCurrencyDetails();
        // console.log("currencyDetails: " + currencyDetails);
        if (defaultCurrencyValue) {
            ////   console.log("propCurrency:" + propCurrency + " ; currencyDetails.currencyCode : " + currencyDetails.currencyCode);
            if (propCurrency === currencyDetails.currencyCode) {
                convertedAmount = defaultCurrencyValue / propCurrencyExchangeRate;
            } else {
                convertedAmount = defaultCurrencyValue * currencyDetails.exchangeRate;

            }
            ////  console.log("propCurrencyExchangeRateBB:" + propCurrencyExchangeRate);
        } else {
            convertedAmount = amount * currencyDetails.exchangeRate;

        }
        // console.log("convertedAmount: " + convertedAmount);

        var finalAmount;
        if (areaFactory.getUxConfiguration().enabledDisplayRatePricing) {
            convertedAmount = parseFloat(convertedAmount).toFixed(2);
        } else {
            convertedAmount = parseFloat(convertedAmount).toFixed(0)
        }
        if (currencyDetails.currencyDisplayFormat != undefined && currencyDetails.currencyDisplayFormat.precision == 0) {
            convertedAmount = Math.round(convertedAmount);
        }
        //var symbol = currencyDetails.currencySymbol;
        ////convertedAmount = $filter('number')(convertedAmount,2);
        //return symbol + convertedAmount;
        //finalAmount = $filter('currency')(convertedAmount, symbol)
        //finalAmount = finalAmount.replace(/,/g, ';');

        //if (currencyDetails.currencyDisplayFormat != undefined) {
        //    finalAmount = finalAmount.replace(/\./g, currencyDetails.currencyDisplayFormat.decimalSeparator);
        //    finalAmount = finalAmount.replace(/;/g, currencyDetails.currencyDisplayFormat.unitSeparator);
        //}
        finalAmount = convertedAmount;
        //finalAmount = convertedAmount;
        //console.log("AA finalAmount:" + finalAmount);
        //convertedAmount = $filter('number')(convertedAmount,2);
        //if (currencyDetails.currencyDisplayFormat != undefined && ( currencyDetails.currencyDisplayFormat.precision == 0 || !areaFactory.getUxConfiguration().enabledDisplayRatePricing )) {
        //    if (currencyDetails.currencyDisplayFormat.decimalSeparator != "") {
        //        console.log("finalAmount.length:" + finalAmount.length);
        //        finalAmount = finalAmount.substring(0, finalAmount.length - 3)
        //        console.log("CC finalAmount:" + finalAmount);
        //
        //    } else {
        //        finalAmount = finalAmount.substring(0, finalAmount.length - 2);
        //        console.log("DD finalAmount:" + finalAmount);
        //
        //    }
        //
        //}
        //console.log("BB finalAmount:" + finalAmount);

        return finalAmount;
    }
}

function currencyConversionNoSymbol(areaService, areaFactory) {
    return function (amount, chainCurrecnyExchangeRate) {

        var convertedAmount;
        var currentCurrency = areaService.getCurrency();

        convertedAmount = amount * chainCurrecnyExchangeRate * currentCurrency.exchangeRate;

        var finalAmount;

        convertedAmount = parseFloat(convertedAmount).toFixed(0);

        if (currentCurrency.currencyDisplayFormat != undefined && currentCurrency.currencyDisplayFormat.precision == 0) {
            convertedAmount = Math.round(convertedAmount);
        }
        finalAmount = convertedAmount;
        if (currentCurrency.currencyDisplayFormat != undefined) {
            finalAmount = finalAmount.replace(/\./g, currentCurrency.currencyDisplayFormat.decimalSeparator);
            finalAmount = finalAmount.replace(/;/g, currentCurrency.currencyDisplayFormat.unitSeparator);
        }

        //convertedAmount = $filter('number')(convertedAmount,2);
        if (currentCurrency.currencyDisplayFormat != undefined && ( currentCurrency.currencyDisplayFormat.precision == 0 || !areaFactory.getUxConfiguration().enabledDisplayRatePricing )) {
            if (currentCurrency.currencyDisplayFormat.decimalSeparator != "") {
                finalAmount = finalAmount.substring(0, finalAmount.length - 3)
            } else {
                finalAmount = finalAmount.substring(0, finalAmount.length - 2);
            }

        }
        return finalAmount;
    }
}


function translationsObj($rootScope, areaService, $filter, areaFactory) {
    return function (param) {
        var translations;
        var latestTranslation;
        translations = $rootScope.translate;
        latestTranslation = translations[param];
        return latestTranslation;
    }
}