/**
 * Created by sramani on 2/22/2017.
 */
angular.module("TravelClApp").directive("searchFilter",searchFilter)

function searchFilter() {
    return {
        restrict: 'E',
        scope: {
          translate: '=',
          googleenable: "=",
          location: '@',
          updatedestination:"&"
        //  bluronsearchbox: "&"
        },
        templateUrl: './searchFilter/searchFilter.html',
        controller: SearchFilterController
    }
}

angular.module("TravelClApp").directive('destinationExpandCollapse', destinationExpandCollapse);

function destinationExpandCollapse() {
    return {
          restrict: 'A',
          link: function(scope, element, attrs){
              element.click( function() {
                  element.parent().find(".collapsedlayer").first().toggleClass('hide');
                  element.toggleClass('active');
       		    });
          }
    }
};
