/**
 * Created by sramani on 2/21/2017.
 */


angular.module('TravelClApp')
    .controller('SearchFilterController', ['$rootScope', '$log', '$scope', 'EVENT', 'navDataFactory','areaFactory' ,'$filter', '$window','areaService', 'lodash', SearchFilterController]);

function SearchFilterController($rootScope, $log, $scope,EVENT, navDataFactory, areaFactory, $filter, $window, areaService, lodash) {

    var isRegion = true;
    var isState = true;
    var isCity = true;
    var isNeighborhood = true;
    var destDropdownEnabled = false;

    var hideCountry = !areaFactory.getUxConfiguration().showCountryDestination;
    var hideRegion = !areaFactory.getUxConfiguration().showRegionDestination;
    var hideState = !areaFactory.getUxConfiguration().showStateDestination;
    var hideCity = !areaFactory.getUxConfiguration().showCityDestination;
    var hideNeighborhood = !areaFactory.getUxConfiguration().showNeighborhoodDestination;


    var destinationData;
    var tempCountryAry = [];
    var layer1;
    var countryCode = null;

    if(destDropdownEnabled)
        initDropdown();

    function initDropdown() {
        destinationData = areaFactory.getDestination();
        layer1 = getChildOption(destinationData);

        for (var contIndex = 0; contIndex < layer1.options.length; contIndex++) {
            countryCode = null;
            var layer1Data = layer1.options[contIndex];
            var layer2 = getChildOption(layer1Data);
            var data = {};
            data[layer1.key] = layer1Data.name;
            data['countryCode'] = countryCode;
            data['hotelId'] = layer1Data.hotelId;
            tempCountryAry.push({
                type: layer1.key,
                title: layer1Data.name,
                data: data,
                options: [],
                isDone: (layer2 && layer2.options && layer2.options.length > 0) ? false : true,
                match: true
            });
            if (!layer2)
                continue;
            for (var contIndex1 = 0; contIndex1 < layer2.options.length; contIndex1++) {
                var layer2Data = layer2.options[contIndex1];
                var layer3 = getChildOption(layer2Data);
                data = {};
                data[layer1.key] = layer1Data.name;
                data[layer2.key] = layer2Data.name;
                data['hotelId'] = layer2Data.hotelId;
                data['countryCode'] = countryCode;
                tempCountryAry[contIndex].options.push({
                    type: layer2.key,
                    title: layer2Data.name,
                    data: data,
                    options: [],
                    isDone: (layer3 && layer3.options && layer3.options.length > 0) ? false : true,
                    match: true
                });
                if (!layer3)
                    continue;
                for (var contIndex2 = 0; contIndex2 < layer3.options.length; contIndex2++) {
                    var layer3Data = layer3.options[contIndex2];
                    var layer4 = getChildOption(layer3Data);
                    data = {};
                    data[layer1.key] = layer1Data.name;
                    data[layer2.key] = layer2Data.name;
                    data[layer3.key] = layer3Data.name;
                    data['hotelId'] = layer3Data.hotelId;
                    data['countryCode'] = countryCode;
                    tempCountryAry[contIndex].options[contIndex1].options.push({
                        type: layer3.key,
                        title: layer3Data.name,
                        data: data,
                        options: [],
                        isDone: (layer4 && layer4.options && layer4.options.length > 0) ? false : true,
                        match: true
                    });
                    if (!layer4)
                        continue;
                    for (var contIndex3 = 0; contIndex3 < layer4.options.length; contIndex3++) {
                        var layer4Data = layer4.options[contIndex3];
                        var layer5 = getChildOption(layer4Data);
                        data = {};
                        data[layer1.key] = layer1Data.name;
                        data[layer2.key] = layer2Data.name;
                        data[layer3.key] = layer3Data.name;
                        data[layer4.key] = layer4Data.name;
                        data['hotelId'] = layer4Data.hotelId;
                        data['countryCode'] = countryCode;
                        tempCountryAry[contIndex].options[contIndex1].options[contIndex2].options.push({
                            type: layer4.key,
                            title: layer4Data.name,
                            data: data,
                            options: [],
                            isDone: (layer5 && layer5.options && layer5.options.length > 0) ? false : true,
                            match: true
                        });
                        if (!layer5)
                            continue;
                        for (var contIndex4 = 0; contIndex4 < layer5.options.length; contIndex4++) {
                            var layer5Data = layer5.options[contIndex4];
                            data = {};
                            data[layer1.key] = layer1Data.name;
                            data[layer2.key] = layer2Data.name;
                            data[layer3.key] = layer3Data.name;
                            data[layer4.key] = layer4Data.name;
                            data[layer5.key] = layer5Data.name;
                            data['hotelId'] = layer5Data.hotelId;
                            data['countryCode'] = countryCode;
                            tempCountryAry[contIndex].options[contIndex1].options[contIndex2].options[contIndex3].options.push({
                                type: layer5.key,
                                title: layer5Data.name,
                                data: data,
                                isDone: true,
                                match: true
                            });
                        }
                    }
                }
            }
        }
        $scope.countryAry = angular.copy(tempCountryAry);
        $scope.destTempAry = angular.copy(tempCountryAry);

      /*  $scope.$watch('location',function(){
            searchDest();
        });*/

        //var params = window.params;
        //params = params.split("\\");
        //if(params != "{}"){
        //    $scope.params = JSON.parse(params);
        //    if($scope.params.destination){
        //        $scope.location = $scope.params.destination;
        //        if(destDropdownEnabled) {
        //            searchDest();
        //            $scope.bluronsearchbox();
        //        }
        //    }
        //}
    }

    function getChildOption(obj)
    {
        if(obj.countryCode)
            countryCode = obj.countryCode;
        if(obj.country)
        {
            return {options:obj.country, key:'country'};
        }
        else if(obj.region)
        {
            if(isRegion)
                return {options:obj.region, key:'region'};
            else
            {
                return lookForNextLayer(obj.region);
            }
        }
        else if(obj.state)
        {
            if(isState)
                return {options:obj.state, key:'state'};
            else
                return lookForNextLayer(obj.state);
        }
        else if(obj.city )
        {
            if(isCity)
                return {options:obj.city, key:'city'};
            else
                return lookForNextLayer(obj.city);
        }
        else if(obj.neighborhood)
        {
            if(isNeighborhood)
                return {options:obj.neighborhood, key:'neighborhood'};
        }

        return null;
    }

    function lookForNextLayer(dataAry)
    {
        var tempResHolder;
        var tempKeyHolder;
        var tempResAry = [];
        angular.forEach(dataAry,function(data){
            var tempResHolder = getChildOption(data);
            if(tempResHolder)
            {
                tempKeyHolder = tempResHolder.key;
                tempResAry = tempResAry.concat(tempResHolder.options)
            }
        });

        return tempResAry.length>0?{options:tempResAry, key:tempKeyHolder}:null;
    }

    function searchDest(){
        if($scope.location != "")
        {
            var destinationOpt = {} ;
            var tempArray = $scope.location.split(',');
            if(tempArray[0])
            {
                var temp1 = $filter('filter')($scope.countryAry, {title:tempArray[0].trim()});
                if(temp1.length == 1)
                    destinationOpt = temp1[0];
            }

            if(tempArray[1] && temp1.length == 1)
            {
                var temp2 = $filter('filter')(temp1[0].options, {title:tempArray[1].trim()});

                if(temp2.length == 1)
                    destinationOpt = temp2[0];
                else if(temp2.length == 0)
                    destinationOpt = {};

            }

            if(tempArray[2] && temp2.length== 1)
            {
                var temp3 = $filter('filter')(temp2[0].options,{title:tempArray[2].trim()});
                if(temp3.length == 1)
                    destinationOpt = temp3[0];
                else if(temp3.length == 0)
                    destinationOpt = {};
            }

            if(tempArray[3] && temp3.length== 1)
            {
                var temp4 = $filter('filter')(temp3[0].options, {title:tempArray[3].trim()});
                if(temp4.length == 1)
                    destinationOpt = temp4[0];
                else if(temp4.length == 0)
                    destinationOpt = {};
            }

            if(tempArray[4] && temp4.length== 1)
            {
                var temp5 = $filter('filter')(temp4[0].options, {title:tempArray[4].trim()});
                if(temp5.length == 1)
                    destinationOpt = temp5[0];
                else if(temp5.length == 0)
                    destinationOpt = {};
            }

            $scope.updatedestination({obj:destinationOpt});

        }
        else {
            $scope.updatedestination({obj:{}});
        }
    }


    /*$scope.$on('search-filter-accordian:onReady', function () {
        $rootScope.$watch("toggle.searchMenu",function()
        {
            $scope.accordion.collapseAll();
        });
    });

    $scope.collapseCallback = function (index, id, accScope) {
       // console.log('collapsed pane:'+accScope);
    };*/

    $scope.filterCountry = function(location, index) {
      var tempArray = location.split(',');
      return tempArray[index]?tempArray[index].trim():"";
    }



    $scope.expandClick = function(destObj)
    {
        var isDone = false;

        var country = destObj.data.country;
        var region = destObj.data.region;
        var state = destObj.data.state;
        var city = destObj.data.city;
        var neighborhood = destObj.data.neighborhood;
        var destinationText = "";

        if(!hideCountry && country) {
            destinationText = destinationText + country;
        } else {
            destinationText += "";
        }

        if(!hideRegion && region) {
            if(destinationText.length > 0) {
                destinationText += ", " + region;
            } else {
                destinationText += region;
            }
        } else {
            destinationText += "";
        }

        if(!hideState && state) {
            if(destinationText.length > 0) {
                destinationText += ", " + state;
            } else {
                destinationText += state;
            }
        } else {
            destinationText += "";
        }

        if(!hideCity && city) {
            if(destinationText.length > 0) {
                destinationText += ", " + city;
            } else {
                destinationText += city;
            }
        } else {
            destinationText += "";
        }

        if(!hideNeighborhood && neighborhood) {
            if(destinationText.length > 0) {
                destinationText += ", " + neighborhood;
            } else {
                destinationText += neighborhood;
            }
        } else {
            destinationText += "";
        }

        $rootScope.$broadcast(EVENT.UPDATE_SEARCH_DESTINATION,{destination:destObj.data, destinationText: destinationText});
        //if(destObj.isDone)
        //{
            //$scope.accordion.collapseAll();
            $rootScope.$broadcast(EVENT.SEARCH_SELECTION_DONE);
        //}
    }

    $scope.closeSearchAccordion = function(){
        //$scope.accordion.collapseAll();
        $rootScope.$broadcast(EVENT.SEARCH_SELECTION_DONE);
    }
    //$scope.clearSelection = function(){
    //    for (var index = 0; index < $scope.countryAry.length; index++) {
    //        $scope.countryAry[index]  = $scope.checkForMatch($scope.countryAry[index], "");
    //
    //    }
    //    $scope.location = '';
    //    var isDone = false;
    //    var destinationText = "";
    //    $rootScope.$broadcast(EVENT.UPDATE_SEARCH_DESTINATION,{destination:{}, destinationText: destinationText});
    //    //$rootScope.$broadcast(EVENT.SEARCH_SELECTION_DONE);
    //
    //}

    $scope.$on(EVENT.CLEAR_SELECTION,function(){
        if(!$scope.googleenable){
            for (var index = 0; index < $scope.countryAry.length; index++) {
                $scope.countryAry[index]  = $scope.checkForMatch($scope.countryAry[index], "");

            }
        }

        var isDone = false;
        var destinationText = "";
        $rootScope.$broadcast(EVENT.UPDATE_SEARCH_DESTINATION,{destination:{}, destinationText: destinationText});
        //$rootScope.$broadcast(EVENT.SEARCH_SELECTION_DONE);
    });


    $scope.$on(EVENT.DESTINATION_CHANGE,function(event, data){
        for (var index = 0; index < $scope.countryAry.length; index++) {
            $scope.countryAry[index]  = $scope.checkForMatch($scope.countryAry[index], data.location);

        }
    });

    checkForScroller("search-filter-accordian");

    function checkForScroller(id){
        var el=document.getElementById(id);
            el.addEventListener('wheel', function(event) {
                var deltaY = event.deltaY;
                var contentHeight = el.scrollHeight;
                var visibleHeight = el.offsetHeight;
                var scrollTop = el.scrollTop;
                if (deltaY < 0)
                {
                    if(scrollTop === 0)
                        event.preventDefault();
                    else if(scrollTop + deltaY <= 0)
                    {
                        event.preventDefault();
                        el.scrollTop = 0;
                    }
                }
                else if (deltaY > 0)
                {
                    if(visibleHeight + scrollTop === contentHeight)
                        event.preventDefault();
                    else if(visibleHeight + scrollTop + deltaY > contentHeight)
                    {
                        el.scrollTop = contentHeight - visibleHeight;
                        event.preventDefault();
                    }
                }

            });
    }

    $scope.checkForMatch = function(obj, char, whiteList) {
        if(char == "")
            whiteList = true;
        if(obj ){
            obj.match = false;
                if(obj.title.toLowerCase().indexOf(char.toLowerCase()) >= 0){
                    obj.match = true;
                }
                if(obj.options)
                {
                    var len = obj.options.length;
                    var isMatch = false;
                    for(var index = 0; index < len; index++)
                    {
                        var tempmatch =   $scope.checkForMatch(obj.options[index], char) ;
                        if(!isMatch)
                        {
                            isMatch = tempmatch.match;
                        }
                    }
                    if(isMatch)
                    {
                        obj.match = true;
                    }
                }

                if(whiteList)
                    obj.match = true;
        }
        return obj;

    }

    $scope.getIndentation = function(obj) {

        switch (obj.type) {

            case 'country':
                if(hideCountry) {
                    return 0;
                } else {
                    return;
                }
                break;

            case 'region':
                if(hideRegion) {
                    return 0
                } else {
                    var isCountryValid = obj.data.country === "" ? true && hideCountry : obj.data.country && hideCountry;
                    if(getUndefinedCount([isCountryValid]) === 0) {
                        return 1;
                    } else {
                        return;
                    }
                }
                break;

            case 'state':
                if(hideState) {
                    return 0;
                } else {
                    var isCountryValid = obj.data.country === "" ? true && hideCountry : obj.data.country && hideCountry;
                    var isRegionValid = obj.data.region === "" ? true && hideRegion : obj.data.region && hideRegion;
                    if(getUndefinedCount([isCountryValid, isRegionValid]) === 0) {
                        return 2;
                    } else if (getUndefinedCount([isCountryValid, isRegionValid]) === 1) {
                        return 1;
                    } else {
                        return;
                    }
                }
                break;

            case 'city':
                if(hideCity) {
                    return 0;
                } else {
                    var isCountryValid = obj.data.country === "" ? true && hideCountry : obj.data.country && hideCountry;
                    var isRegionValid = obj.data.region === "" ? true && hideRegion : obj.data.region && hideRegion;
                    var isStateValid = obj.data.state === "" ? true && hideState : obj.data.state && hideState;
                    if(getUndefinedCount([isCountryValid, isRegionValid, isStateValid]) === 0) {
                        return 3;
                    } else if (getUndefinedCount([isCountryValid, isRegionValid, isStateValid]) === 1) {
                        return 2;
                    } else if (getUndefinedCount([isCountryValid, isRegionValid, isStateValid]) === 2){
                        return 1;
                    } else {
                        return;
                    }
                }
                break;

            case 'neighborhood':
                if(hideNeighborhood) {
                    return 0;
                } else {
                    var isCountryValid = obj.data.country === "" ? true && hideCountry : obj.data.country && hideCountry;
                    var isRegionValid = obj.data.region === "" ? true && hideRegion : obj.data.region && hideRegion;
                    var isStateValid = obj.data.state === "" ? true && hideState : obj.data.state && hideState;
                    var isCityValid = obj.data.city === "" ? true && hideCity : obj.data.city && hideCity;
                    if(getUndefinedCount([isCountryValid, isRegionValid, isStateValid, isCityValid]) === 0) {
                        return 4;
                    } else if (getUndefinedCount([isCountryValid, isRegionValid, isStateValid, isCityValid]) === 1) {
                        return 3;
                    } else if(getUndefinedCount([isCountryValid, isRegionValid, isStateValid, isCityValid]) === 2) {
                        return 2;
                    } else if(getUndefinedCount([isCountryValid, isRegionValid, isStateValid, isCityValid]) === 3) {
                        return 1;
                    } else {
                        return;
                    }
                }
                break;
        }
    }

    function getUndefinedCount(objArray) {
        var count = 0;
        lodash.forEach(objArray, function(obj) {
            if(obj === true || obj === undefined || obj === null) {
                count++;
            }
        })
        return count;
    }

}

SearchFilterController.$inject =['$rootScope', '$log', '$scope', 'EVENT', 'navDataFactory','areaFactory' ,'$filter', '$window','areaService', 'lodash'];
