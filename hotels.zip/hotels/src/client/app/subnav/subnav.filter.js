/**
 * Created by yhuang on 1/31/2017.
 */
"use strict";

angular.module('TravelClApp')
    .filter('filterProperty', function () {
        var filterProperties = function(originalItems, filterSelections){

        };

        return filterProperties;
    });

