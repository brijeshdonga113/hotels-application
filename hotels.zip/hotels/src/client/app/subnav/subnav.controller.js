/**
 * Created by yhuang on 1/26/2017.
 */

function subNavController($scope, areaFactory, apiFactory, areaService, hotelDataService, EVENT, $rootScope, $filter, lodash, $window) {

    var isAvailChange = false;
    areaService.setIsLoadMoreAvail(false);
    $scope.uxConfig = areaFactory.getUxConfiguration();
    $scope.chainInfo = areaFactory.getChainInfo();
    var chainCode = areaFactory.getChainCode();
    $scope.displayTypes = {};
    $scope.displayTypes.displayListView = false;
    $scope.displayTypes.displayGridView = false;
    $scope.displayTypes.displaymapView = false;

    $scope.availCall = false;
    $scope.changeAbb = false;
    $scope.filterDirtyCheck = false;
    $scope.tempPropertyList = [];
    $scope.priceButton = {};
    $scope.clickOutsideFilter = false;
    $scope.isSortOrderChange = false;
    var codeChange = {};

    if ($scope.uxConfig.defaultViewDisplayFormat === 0) {
        $scope.displayTypes.displayGridView = true;
    } else if ($scope.uxConfig.defaultViewDisplayFormat === 1) {
        $scope.displayTypes.displayListView = true;
    } else if ($scope.uxConfig.defaultViewDisplayFormat === 2) {
        $scope.displayTypes.displaymapView = true;
        $scope.refreshMap = true;
    } else {
        $scope.displayTypes.displayGridView = true;
    }

    if (window.innerWidth < 543 && ($scope.uxConfig.defaultViewDisplayFormat === 0 || $scope.uxConfig.defaultViewDisplayFormat === 1)) {
        $scope.displayTypes.displayListView = false;
        $scope.displayTypes.displayGridView = true;
    }

    if ($rootScope.showAddCode == true) {
        $scope.tmobile = "mobile";
    }

    $scope.crmSettings = $scope.uxConfig.crmSettings;

    $scope.filterEnableBeforeAvail = false;
    $scope.filterEnableAfterAvail = false;

    if ($scope.uxConfig.enableDisplaySortOrderFilter || $scope.uxConfig.enableStarRatingFilter || $scope.uxConfig.enableDisplaySortOrderFilter || $scope.uxConfig.enableAmenityFilter) {
        $scope.filterEnableAfterAvail = true;
        $scope.filterEnableBeforeAvail = true;
    }

    if ($scope.uxConfig.enablePriceFilter || $scope.uxConfig.enablePackageTypeFilter || $scope.uxConfig.enableRatePlanFilter || $scope.uxConfig.enableHotelNameFilter)
        $scope.filterEnableAfterAvail = true;

    $scope.specialCodeEnable = $scope.uxConfig.specialCodesFieldEnabled && ($scope.uxConfig.enablePromotionalCodes || $scope.uxConfig.enableDiscountCode || $scope.uxConfig.enableGroupCode );


    function updateTabPosition() {
        var tabCount = 0;
        $scope.isTabCenterAlign = false;

        if ($scope.specialCodeEnable)
            tabCount++;
        if (($scope.filterEnableBeforeAvail) || ( $scope.filterEnableAfterAvail && $scope.availCall))
            tabCount++;

        $scope.filterPosClass = "col-lg-8 col-md-12";
        $scope.filterTabClass = "col-xs-6";
        $scope.specialTabClass = "col-xs-6";

        if (tabCount == 1) {
            $scope.filterPosClass = "left-align col-lg-4 col-md-12 ";
            $scope.filterTabClass = "col-xs-12 left-align-filter";
            $scope.specialTabClass = "col-xs-12";
        }
        else if (tabCount == 2) {
            $scope.isTabCenterAlign = true;
    
              $scope.filterPosClass = "col-xs-12";
              $scope.filterTabClass = "col-xs-6";
              $scope.specialTabClass = "col-xs-6";
        }
    }

    updateTabPosition();

    $scope.$watch("availCall", function () {
        updateTabPosition();
    });

    //$scope.currentCurrency = angular.copy($scope.chainInfo.currentCurrency);
    $scope.currentCurrency = angular.copy(areaService.getCurrency());

    $scope.currencyChange = {};
    $scope.currencyChange.prev = angular.copy($scope.currentCurrency.currencyCode);

    $scope.flagChangeFilter = false;  // user changes filter selections


    var cacheFilter = areaService.getFilter();
    if (!cacheFilter) {
        $scope.filters = {};
        $scope.filters.sortOrder = {};
        $scope.filters.sortOrder.defaultSortOrder = angular.copy($scope.uxConfig.defaultSortOrder);
        $scope.filters.sortOrder.selections = [];
        $scope.filters.priceRange = {};
        $scope.filters.hotelRates = [];
        $scope.filters.filterOptions = [];
        $scope.filters.amenities = [];

        $scope.allAbbrev = {};

        function compareName(a, b) {
            if (a.name < b.name)
                return -1;
            if (a.name > b.name)
                return 1;
            return 0;
        }

        $scope.filters.sortOrder.selections.push(
            {
                "title": "Alphabetical - A to Z",
                "value": false,
                "abbrev": $rootScope.translate.global_az_ASazLbl,
                "sortId": 0,
                "display": $rootScope.translate.global_atoz_ASatozLbl
            },
            {
                "title": "Alphabetical - Z to A",
                "value": false,
                "abbrev": $rootScope.translate.global_za_ASzaLbl,
                "sortId": 1,
                "display": $rootScope.translate.global_ztoa_ASztoaLbl
            },
            {
                "title": "Star Rating - Highest",
                "value": false,
                "abbrev": $rootScope.translate.global_starhighest_ASstarhighestLbl,
                "sortId": 2,
                "display": $rootScope.translate.global_starhighest_ASstarhighestLbl
            });

        if ($scope.filters.sortOrder.defaultSortOrder < 3) {
            //alert("<3"+$scope.filters.sortOrder.defaultSortOrder)
        } else {
            $scope.filters.sortOrder.defaultSortOrder = 0;
        }

        if ($scope.filters.sortOrder.hasOwnProperty("defaultSortOrder") && $scope.filters.sortOrder.defaultSortOrder != null) {
            $scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].value = true;
        }

        if ($scope.currentCurrency.hasOwnProperty("currencySymbol")) {
            $scope.filters.priceRange.currencySymbol = angular.copy($scope.currentCurrency.currencySymbol || '$');
        } else {
            $scope.filters.priceRange.currencySymbol = "$";
        }
        if ($scope.currentCurrency.hasOwnProperty("currencyCode")) {
            $scope.filters.priceRange.currencyCode = angular.copy($scope.currentCurrency.currencyCode);
        } else {
            $scope.filters.priceRange.currencyCode = "USD";
        }
        if ($scope.uxConfig.hasOwnProperty("minPriceRange")) {
            $scope.filters.priceRange.minValue = angular.copy($scope.uxConfig.minPriceRange);
        } else {
            $scope.filters.priceRange.minValue = 0;
        }
        if ($scope.uxConfig.hasOwnProperty("maxPriceRange")) {
            $scope.filters.priceRange.maxValue = angular.copy($scope.uxConfig.maxPriceRange);
        } else {
            $scope.filters.priceRange.maxValue = 1000;
        }

        if ($scope.currentCurrency.exchangeRate != "1") {
            var minValue = $scope.filters.priceRange.minValue * $scope.currentCurrency.exchangeRate;
            $scope.filters.priceRange.minValue = angular.copy(minValue);
            var maxValue = $scope.filters.priceRange.maxValue * $scope.currentCurrency.exchangeRate;
            if (maxValue < 1000) {
                $scope.filters.priceRange.maxValue = 1000;
            } else if (minValue > 50000) {
                $scope.filters.priceRange.maxValue = 50000;
            } else {
                $scope.filters.priceRange.maxValue = Math.round(maxValue / 1000) * 1000;
            }
            $scope.filters.priceRange.chainCurrecnyExchangeRate = angular.copy($scope.currentCurrency.exchangeRate);
        }
        $scope.filters.priceRange.options = {};
        $scope.filters.priceRange.options.ceil = $scope.filters.priceRange.maxValue;
        $scope.filters.priceRange.options.floor = $scope.filters.priceRange.minValue;
        $scope.filters.priceRange.options.translate = function (value) {
            return $scope.filters.priceRange.currencySymbol + value;
        };

        if ($scope.uxConfig.enableDisplaySortOrderFilter == true) {
            $scope.filters.priceRange.ifShowSeparate = "filter-separate";
        }

        $scope.symbolSign = angular.copy($scope.filters.priceRange.currencySymbol || '$');
        var defaultMinValue = angular.copy($scope.filters.priceRange.minValue);
        var defaultMaxValue = angular.copy($scope.filters.priceRange.maxValue);

        $scope.filters.slider_translate = {
            minValue: defaultMinValue,
            maxValue: defaultMaxValue,
            options: {
                ceil: defaultMaxValue,
                floor: defaultMinValue,
                translate: function (value) {
                    if (defaultMaxValue == value) {
                        return $scope.symbolSign + value + "+";
                    } else {
                        return $scope.symbolSign + value;
                    }

                }
            }
        };
        $scope.filters.priceRange.ifMin = true;
        $scope.filters.priceRange.ifMax = true;

        //$scope.getPriceAbbrev();

        $scope.$on(EVENT.SEARCH_CRITERIA_DATA_READY, function () {

            $scope.searchCriteria = hotelDataService.getSearchCriteria();
            $scope.filters.searchCriteria = [];
            $scope.filters.filterOptions = [];
            $scope.filters.amenities = [];
            $scope.filters.hotelRates = [];
            $scope.filters.ifShowFilterOptions = ($scope.uxConfig.enableHotelNameFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("hotels"))
                || ($scope.uxConfig.enableRatePlanFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("ratePlans")) ||
                ($scope.uxConfig.enablePackageTypeFilter && $scope.availCall && $scope.searchCriteria.hasOwnProperty("packageCategories"));

            if ($scope.searchCriteria.hasOwnProperty("packageCategories")) {
                //&& $scope.uxConfig.enablePackageTypeFilter
                var package = {};
                var options = angular.copy($scope.searchCriteria.packageCategories);
                options.sort();
                package.title = "PACKAGES";
                package.display = $rootScope.translate.page_packages_ASpackagesLbl;
                package.default = "0";
                package.enable = $scope.uxConfig.enablePackageTypeFilter;
                package.options = angular.copy(options);
                package.selections = [];
                package.multiSelect = [];
                package.selections.push({
                    "title": $rootScope.translate.global_allpackages_ASallpackagesLbl,
                    "selection": false,
                    id: "",
                    "abbrev": $rootScope.translate.global_allpackages_ASallpackagesLbl
                });

                angular.forEach(package.options, function (eachOption) {
                    package.selections.push({"title": eachOption, "selection": false, id: eachOption});
                });
                package.selections[package.default].selection = false;
                package.abbrev = package.selections[package.default].title;
                package.id = package.selections[package.default].id;
                $scope.filters.filterOptions.push(package);
                $scope.filters.searchCriteria.push("PACKAGES");

            }

            if ($scope.searchCriteria.hasOwnProperty("ratePlans")) {
                //&& $scope.uxConfig.enableRatePlanFilter

                var rateplan = {};
                var options = angular.copy($scope.searchCriteria.ratePlans);

                options.sort(compareName);
                rateplan.title = "RATE PLANS";
                rateplan.display = $rootScope.translate.page_roomrates_ASroomratesLbl;
                rateplan.default = "0";
                rateplan.enable = $scope.uxConfig.enableRatePlanFilter;
                rateplan.options = angular.copy(options);
                rateplan.selections = [];
                rateplan.multiSelect = [];

                rateplan.selections.push({
                    "title": $rootScope.translate.global_allrateoptions_ASallrateoptionsLbl,
                    "selection": false,
                    "id": [],
                    "abbrev": $rootScope.translate.global_allrateoptions_ASallrateoptionsLbl
                });

                rateplan.allTypes = [];
                angular.forEach(options, function (eachOp) {
                    if (rateplan.allTypes.indexOf(eachOp.name) < 0) {
                        rateplan.allTypes.push(eachOp.name);
                    }
                });

                angular.forEach(rateplan.allTypes, function (eachType) {
                    var newType = {};
                    newType.title = eachType;
                    newType.selection = false;
                    newType.id = [];

                    angular.forEach(options, function (eachOp) {
                        if (eachType == eachOp.name) {
                            newType.id.push(eachOp.externalCode);
                        }
                    })

                    rateplan.selections.push(newType);

                });

                //angular.forEach(rateplan.options, function (eachOption) {
                //    rateplan.selections.push({
                //        "title": eachOption.name,
                //        "selection": false,
                //        "id": eachOption.externalCode
                //    });
                //});
                rateplan.selections[rateplan.default].selection = false;
                rateplan.abbrev = rateplan.selections[rateplan.default].title;
                rateplan.id = rateplan.selections[rateplan.default].id;
                $scope.filters.filterOptions.push(rateplan);
                $scope.filters.searchCriteria.push("RATE PLANS");

            }

            if ($scope.searchCriteria.hasOwnProperty("hotels")) {

                var hotelname = {};
                var options = angular.copy($scope.searchCriteria.hotels);
                //options.sort();
                hotelname.title = "HOTEL NAMES";
                hotelname.display = $rootScope.translate.page_property_ASproeprtyLbl;
                hotelname.default = 0;
                hotelname.enable = $scope.uxConfig.enableHotelNameFilter;

                hotelname.selections = [];
                hotelname.multiSelect = [];

                function compareA(a, b) {
                    if (a.name < b.name)
                        return -1;
                    if (a.name > b.name)
                        return 1;
                    return 0;
                }

                options.sort(compareA);
                hotelname.options = angular.copy(options);
                //console.log("hotelname.options:" + JSON.stringify(hotelname.options));
                hotelname.selections.push({
                    "title": $rootScope.translate.global_allproperties_ASallpropertiesLbl,
                    "selection": false,
                    "id": ""
                });

                angular.forEach(hotelname.options, function (eachOption) {
                    hotelname.selections.push({"title": eachOption.name, "id": eachOption.id, "selection": false});
                });
                hotelname.selections[hotelname.default].selection = false;
                hotelname.abbrev = hotelname.selections[hotelname.default].title;
                hotelname.id = hotelname.selections[hotelname.default].id;
                $scope.filters.filterOptions.push(hotelname);
                $scope.filters.searchCriteria.push("HOTEL NAMES");
                areaService.setAllPropertySelection(angular.copy(hotelname.selections));

            }

            if ($scope.searchCriteria.hasOwnProperty("amenities")) {
                //&& $scope.uxConfig.enableHotelNameFilter
                var amenities = angular.copy($scope.searchCriteria.amenities);

                var allAmen = [];
                for (var i = 0; i < amenities.length; i++) {
                    if (allAmen.indexOf(amenities[i].name) < 0) {
                        allAmen.push(amenities[i].name);
                    }
                }

                var updatedAmen = []
                for (var p = 0; p < allAmen.length; p++) {
                    var amenity = {};
                    amenity.title = allAmen[p];
                    amenity.newId = [];
                    amenity.abbrev = allAmen[p];
                    updatedAmen.push(amenity);

                    var name = allAmen[p];

                    for (var q = 0; q < amenities.length; q++) {

                        if (amenities[q].name == name) {

                            if (updatedAmen[p].newId.indexOf(amenities[q].id) < 0) {
                                updatedAmen[p].newId.push(amenities[q].id);
                            }

                        }
                    }
                }

                $scope.filters.amenities = angular.copy(updatedAmen);
                $scope.filters.searchCriteria.push("AMENITIES");

                // $scope.filters.newAmen = [];
                //
                // for (var j = 0; j < 4; j++) {
                //     if ($scope.filters.amenities[j]) {
                //         var amenity = {};
                //         amenity.title = $scope.filters.amenities[j].title;
                //         amenity.id = $scope.filters.amenities[j].newId;
                //         amenity.selection = false;
                //         amenity.abbrev = $scope.filters.amenities[j].title;
                //         $scope.filters.newAmen.push(amenity);
                //     }
                // }
                //if ($scope.filters.amenities.length > 4) {
                if ($scope.filters.amenities.length > 0) {
                    $scope.filters.anoAmen = [];
                    //for (var k = 4; k < $scope.filters.amenities.length; k++) {
                    for (var k = 0; k < $scope.filters.amenities.length; k++) {
                        if ($scope.filters.amenities[k]) {
                            var amenity = {};
                            amenity.title = $scope.filters.amenities[k].title;
                            amenity.id = $scope.filters.amenities[k].newId;
                            amenity.selection = false;
                            amenity.abbrev = $scope.filters.amenities[k].title;
                            $scope.filters.anoAmen.push(amenity);
                        }
                    }
                }


            }

            if (($scope.availCall == true && $scope.uxConfig.enablePriceFilter == true) || ($scope.uxConfig.enableDisplaySortOrderFilter)) {
                $scope.filters.hotelRateIfShowSeparate = "filter-separate";
            }

            if ($scope.searchCriteria.hasOwnProperty("starRatings")) {
                var starRatings = angular.copy($scope.searchCriteria.starRatings);
                if (starRatings.indexOf("1") > -1) {
                    //alert("1: true");
                    $scope.filters.hotelRates.push({"title": "1", "value": false, "abbrev": 1, "displayRate": true});
                } else {
                    $scope.filters.hotelRates.push({"title": "1", "value": false, "abbrev": 1, "displayRate": false});
                }
                if (starRatings.indexOf("2") > -1) {

                    $scope.filters.hotelRates.push({"title": "2", "value": false, "abbrev": 2, "displayRate": true});
                } else {
                    $scope.filters.hotelRates.push({"title": "2", "value": false, "abbrev": 2, "displayRate": false});
                }
                if (starRatings.indexOf("3") > -1) {

                    $scope.filters.hotelRates.push({"title": "3", "value": false, "abbrev": 3, "displayRate": true});
                } else {
                    $scope.filters.hotelRates.push({"title": "3", "value": false, "abbrev": 3, "displayRate": false});
                }
                if (starRatings.indexOf("4") > -1) {

                    $scope.filters.hotelRates.push({"title": "4", "value": false, "abbrev": 4, "displayRate": true});
                } else {
                    $scope.filters.hotelRates.push({"title": "4", "value": false, "abbrev": 4, "displayRate": false});
                }
                if (starRatings.indexOf("5") > -1 || starRatings.indexOf("6") > -1 || starRatings.indexOf("7") > -1
                    || starRatings.indexOf("8") > -1 || starRatings.indexOf("9") > -1) {

                    $scope.filters.hotelRates.push({"title": "5", "value": false, "abbrev": 5, "displayRate": true});
                } else {
                    $scope.filters.hotelRates.push({"title": "5", "value": false, "abbrev": 5, "displayRate": false});
                }
                if (starRatings.indexOf("Not Rated") > -1) {
                    $scope.filters.hotelRates.push({
                        "title": "0",
                        "value": false,
                        "abbrev": "Not Rated",
                        "displayRate": true
                    });
                } else {
                    $scope.filters.hotelRates.push({
                        "title": "0",
                        "value": false,
                        "abbrev": "Not Rated",
                        "displayRate": false
                    });
                }

            }

            $scope.dupFilters = angular.copy($scope.filters);
            areaService.setFilter($scope.filters);
        });
    } else {
        $scope.isSortOrderChange = true;
        $scope.filters = angular.copy(cacheFilter);
        $scope.dupFilters = angular.copy($scope.filters);
        $scope.allAbbrev = angular.copy(areaService.getFilterAbbr());
        if($scope.allAbbrev == undefined)
            $scope.allAbbrev = {};

        $scope.$on(EVENT.SEARCH_CRITERIA_DATA_READY, function () {
            $scope.searchCriteria = hotelDataService.getSearchCriteria();
        });

        $scope.symbolSign = angular.copy($scope.filters.priceRange.currencySymbol || '$');
        var tempSliderVal = angular.copy($scope.filters.slider_translate);
        $scope.filters.slider_translate = {
            minValue: tempSliderVal.minValue,
            maxValue: tempSliderVal.maxValue,
            options: {
                ceil:  tempSliderVal.options.ceil,
                floor:  tempSliderVal.options.floor,
                translate: function (value) {
                    if (tempSliderVal.options.ceil == value) {
                        return $scope.symbolSign + value + "+";
                    } else {
                        return $scope.symbolSign + value;
                    }

                }
            }
        };


    }
    // click outside hide div
    $scope.closeFlag = true;
    $scope.hideDiv = function() {
      if($rootScope.toggle.showFilter){
        $rootScope.toggle.showFilter = !$rootScope.toggle.showFilter;
      }
    }

    $scope.noClose = function() {
      $scope.closeFlag = false;
    }
    $scope.getPriceAbbrev = function () {
        var symbol = $scope.filters.priceRange.currencySymbol || '$';
        if ($scope.filters.priceRange.maxValue == $scope.filters.slider_translate.options.ceil) {
            $scope.filters.priceRange.abbrev = symbol + $scope.filters.priceRange.minValue + " " +
                $scope.filters.priceRange.currencyCode + " - " + symbol + $scope.filters.priceRange.maxValue
                + "+" + $scope.filters.priceRange.currencyCode;
        } else {
            $scope.filters.priceRange.abbrev = symbol + $scope.filters.priceRange.minValue + " " +
                $scope.filters.priceRange.currencyCode + " - " + symbol + $scope.filters.priceRange.maxValue
                + " " + $scope.filters.priceRange.currencyCode;
        }

    };

    $scope.showRzSlider = false;
//    $scope.symbolSign = angular.copy($scope.filters.priceRange.currencySymbol || '$');

    $scope.$on(EVENT.LANG_CHANGE, function () {
        for (var i = 0; i < $scope.filters.filterOptions.length; i++) {
            // Update Package and Rate Plan Drop Down titles
            if ($scope.filters.filterOptions[i].title == "PACKAGES") {
                $scope.filters.filterOptions[i].display = $rootScope.translate.page_packages_ASpackagesLbl;
            }
            if ($scope.filters.filterOptions[i].title == "RATE PLANS") {
                $scope.filters.filterOptions[i].display = $rootScope.translate.page_roomrates_ASroomratesLbl;
            }
            if ($scope.filters.filterOptions[i].title == "HOTEL NAMES") {
                $scope.filters.filterOptions[i].display = $rootScope.translate.page_property_ASproeprtyLbl;
            }
            // Update Default Dropdown Value for Package and Rate Plan drop down
            for (var k = 0; k < $scope.filters.filterOptions[i].selections.length; k++) {
                if ($scope.filters.filterOptions[i].title == "PACKAGES") {
                    if ($scope.filters.filterOptions[i].selections[k].id == "") {
                        $scope.filters.filterOptions[i].selections[k].title = $rootScope.translate.global_allpackages_ASallpackagesLbl;
                    }
                }
                if ($scope.filters.filterOptions[i].title == "RATE PLANS") {
                    if ($scope.filters.filterOptions[i].selections[k].id == "") {
                        $scope.filters.filterOptions[i].selections[k].title = $rootScope.translate.global_allrateoptions_ASallrateoptionsLbl;
                    }
                }
                if ($scope.filters.filterOptions[i].title == "HOTEL NAMES") {
                    if ($scope.filters.filterOptions[i].selections[k].id == "") {
                        $scope.filters.filterOptions[i].selections[k].title = $rootScope.translate.global_allproperties_ASallpropertiesLbl;
                    }
                }
            }
        }

        //update the translations in both the copies(filters and temp filters)
        for (var j = 0; j < $scope.filters.sortOrder.selections.length; j++) {
            if ($scope.filters.sortOrder.selections[j].sortId == 0) {
                $scope.filters.sortOrder.selections[j].display = $rootScope.translate.global_atoz_ASatozLbl;
                $scope.filters.sortOrder.selections[j].abbrev = $rootScope.translate.global_az_ASazLbl;
            }
            if ($scope.filters.sortOrder.selections[j].sortId == 1) {
                $scope.filters.sortOrder.selections[j].display = $rootScope.translate.global_ztoa_ASztoaLbl;
                $scope.filters.sortOrder.selections[j].abbrev = $rootScope.translate.global_za_ASzaLbl;
            }
            if ($scope.filters.sortOrder.selections[j].sortId == 2) {
                $scope.filters.sortOrder.selections[j].display = $rootScope.translate.global_starhighest_ASstarhighestLbl;
                $scope.filters.sortOrder.selections[j].abbrev = $rootScope.translate.global_starhighest_ASstarhighestLbl;
            }
            if ($scope.filters.sortOrder.selections[j].sortId == 3) {
                $scope.filters.sortOrder.selections[j].display = $rootScope.translate.global_lowtohigh_ASlowtohighLbl;
                $scope.filters.sortOrder.selections[j].abbrev = $rootScope.translate.global_lowtohigh_ASlowtohighLbl;
            }
            if ($scope.filters.sortOrder.selections[j].sortId == 4) {
                $scope.filters.sortOrder.selections[j].display = $rootScope.translate.global_hightolow_AShightolowLbl;
                $scope.filters.sortOrder.selections[j].abbrev = $rootScope.translate.global_hightolow_AShightolowLbl;
            }
        }
        if (!$scope.tempFilters) {
            $scope.tempFilters = angular.copy($scope.filters);
        } else {
            for (var j = 0; j < $scope.tempFilters.sortOrder.selections.length; j++) {
                if ($scope.tempFilters.sortOrder.selections[j].sortId == 0) {
                    $scope.tempFilters.sortOrder.selections[j].display = $rootScope.translate.global_atoz_ASatozLbl;
                    $scope.tempFilters.sortOrder.selections[j].abbrev = $rootScope.translate.global_az_ASazLbl;
                }
                if ($scope.tempFilters.sortOrder.selections[j].sortId == 1) {
                    $scope.tempFilters.sortOrder.selections[j].display = $rootScope.translate.global_ztoa_ASztoaLbl;
                    $scope.tempFilters.sortOrder.selections[j].abbrev = $rootScope.translate.global_za_ASzaLbl;
                }
                if ($scope.tempFilters.sortOrder.selections[j].sortId == 2) {
                    $scope.tempFilters.sortOrder.selections[j].display = $rootScope.translate.global_starhighest_ASstarhighestLbl;
                    $scope.tempFilters.sortOrder.selections[j].abbrev = $rootScope.translate.global_starhighest_ASstarhighestLbl;
                }
                if ($scope.tempFilters.sortOrder.selections[j].sortId == 3) {
                    $scope.tempFilters.sortOrder.selections[j].display = $rootScope.translate.global_lowtohigh_ASlowtohighLbl;
                    $scope.tempFilters.sortOrder.selections[j].abbrev = $rootScope.translate.global_lowtohigh_ASlowtohighLbl;
                }
                if ($scope.tempFilters.sortOrder.selections[j].sortId == 4) {
                    $scope.tempFilters.sortOrder.selections[j].display = $rootScope.translate.global_hightolow_AShightolowLbl;
                    $scope.tempFilters.sortOrder.selections[j].abbrev = $rootScope.translate.global_hightolow_AShightolowLbl;
                }
            }
        }

        updateAbbrev();

        var currencyDetail = areaService.getCurrencyDetails();
        $scope.currencyChange.cur = angular.copy(currencyDetail.currencyCode);
        if ($scope.currencyChange.prev != $scope.currencyChange.cur) {
            $scope.changePriceRangeCurrency();
        }
        try{
          //  $scope.$apply();
        }
        catch(e)
        {}
    });


    $scope.changeNewAmen = function (_element) {
        _element.selection = !_element.selection;
        $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
        $scope.filterDirtyCheck = true;
        isAvailChange = true;
    };

    // $scope.clickAmen = function (n, $event, ) {
    //     var amen = n.replace("amen-", "");
    //
    //     $scope.filters.anoAmen[amen].selection = !$scope.filters.anoAmen[amen].selection;
    //     $event.preventDefault();
    //     isAvailChange = true;
    //     $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
    //     $scope.filterDirtyCheck = true;
    // }
    if(!$scope.filters.selectedAmenities){
      $scope.filters.selectedAmenities = [];
    };
    $scope.changeInput = function () {
      $scope.filters.selectedAmenities = [];
        for (var j = 0; j < $scope.filters.anoAmen.length; j++) {
            if ($scope.filters.anoAmen[j].selection == true) {
                $scope.filters.selectedAmenities.push({
                    "id": $scope.filters.anoAmen[j].id,
                    "abbrev": $scope.filters.anoAmen[j].abbrev
                });
            }
        }
        //var amen = title.replace("amen-", "");
        isAvailChange = true;
        $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
        $scope.filterDirtyCheck = true;
    };

    $scope.selections = {};
    $scope.changeFilterOptions = function (title, i) {
        var indOfTitle = $scope.filters.searchCriteria.indexOf(title);
        var filterValue = {
            abbrev: $scope.filters.filterOptions[indOfTitle].selections[i].title,
            id: $scope.filters.filterOptions[indOfTitle].selections[i].id
        }
        if($scope.filters.filterOptions[indOfTitle].selections[i].selection) {
            $scope.filters.filterOptions[indOfTitle].multiSelect.push(filterValue);
        } else {
            var index = lodash.findIndex($scope.filters.filterOptions[indOfTitle].multiSelect, function (obj) {
                return obj.id.toString() == filterValue.id.toString();
            });

            if(index != -1) {
                $scope.filters.filterOptions[indOfTitle].multiSelect = lodash.without($scope.filters.filterOptions[indOfTitle].multiSelect, $scope.filters.filterOptions[indOfTitle].multiSelect[index]);
            }
        }
        $scope.flagChangeFilter = true;
        $scope.filterDirtyCheck = true;
        isAvailChange = true;
    };

    $scope.changeSortOrder = function (n, $event) {
        $event.preventDefault();
        //$event.stopPropagation();
        for (var le = 0; le < $scope.filters.sortOrder.selections.length; le++) {
            $scope.filters.sortOrder.selections[le].value = false;
        }
        $scope.filters.sortOrder.defaultSortOrder = n;
        $scope.filters.sortOrder.selections[n].value = true;
        $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
        $scope.filterDirtyCheck = true;
        if ($scope.filters.sortOrder.defaultSortOrder >= 0 && $scope.filters.sortOrder.defaultSortOrder <= 2)
            isAvailChange = true;
    };

    $scope.changeHotelRates = function () {
        $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
        $scope.filterDirtyCheck = true;
        isAvailChange = true;

    };

    $scope.$on("slideEnded", function () {
        $scope.filters.priceRange.minValue = angular.copy($scope.filters.slider_translate.minValue);
        $scope.filters.priceRange.maxValue = angular.copy($scope.filters.slider_translate.maxValue);
        $scope.filters.priceRange.currencySymbol = angular.copy($scope.symbolSign || '$');
        $scope.getPriceAbbrev();
        $scope.flagChangeFilter = true;    //user changes filter selections, unsaved changes
        $scope.filterDirtyCheck = true;
        if ($scope.filters.slider_translate.maxValue === $scope.filters.slider_translate.options.ceil) {
            $scope.filters.priceRange.ifMax = true;
        } else {
            $scope.filters.priceRange.ifMax = false;
        }
        if ($scope.filters.slider_translate.minValue === $scope.filters.slider_translate.options.floor) {
            $scope.filters.priceRange.ifMin = true;
        } else {
            $scope.filters.priceRange.ifMin = false;
        }

//console.log("AA  $scope.filters.priceRange:"+JSON.stringify($scope.filters.priceRange));
        //isAvailChange = true;  // price range filter is handled by UI only
    });

    $rootScope.toggle.showFilter = false;
    $rootScope.showAddCode = false;
    if ($rootScope.toggle.showFilter === false) {
        $scope.filterBtn = "filter-unShow";
    } else {
        $scope.filterBtn = "filter-show";
    }
    if ($rootScope.showAddCode === false) {
        $scope.filterAddCode = "filter-unShow";
    } else {
        $scope.filterAddCode = "filter-show";
    }

    $scope.filterDropdown={};
    $scope.filterDropdown.statusSortOrder = {};
    $scope.filterDropdown.statusMoreAmen = {};

    $scope.changShowFilter = function ($event) {
        $rootScope.toggle.showFilter = !$rootScope.toggle.showFilter;
        $event.preventDefault();
        $event.stopPropagation();

    };


    $scope.$watch('showAddCode', function () {
        if ($rootScope.showAddCode === false) {
            $scope.filterAddCode = "filter-unShow";
        } else {
            $scope.filterAddCode = "filter-show";
            $rootScope.toggle.showFilter = false;
            $scope.filterBtn = "filter-unShow";
            $scope.tmobile = "mobile";
        }
    });


    $scope.changeAbbrev = function ($event) {
        $scope.cancelFilters = false;   // change comes from DONE button, not CLEAR button
        $scope.filterDirtyCheck = false;
        $scope.tempFilters = angular.copy($scope.filters);
        $scope.changeAbbrevOnly();

        //$scope.filterDirtyCheck = false;
        $scope.changShowFilter($event);

        //$scope.tempFilters = angular.copy($scope.filters);


    };

    $scope.changeAbbrevOnly = function () {

        //console.log("BBBB    $scope.filters.filterOptions:" + JSON.stringify($scope.filters.filterOptions));
        if ($scope.flagChangeFilter === true) {   //user changes filter selections without saving

            updateAbbrev();
        }
        var selectedDates = areaService.getCalendarData();
        if (selectedDates.startDate && selectedDates.endDate && isAvailChange) {
            areaService.setMoreDataEchoToken(0);
            areaService.removeRatePlanId();
            hotelDataService.loadAvailHotels();
        }
        else {

            $rootScope.$broadcast(EVENT.APPLY_UI_FILTER);
        }
        isAvailChange = false;  //after a new avail call, reset to false

    }

    function updateAbbrev(fromLoadMore)
    {
        var filterAvailStr = {
            "searchResultSortOrder": 0,
            "starRatings": [],
            "hotelIds": [],
            "amenityIds": [],
            "ratePlanCategory": [],
            "ratePlanCode": [],
            priceRange: {
                maxRate: $scope.filters.priceRange.maxValue,
                minRate: $scope.filters.priceRange.minValue
            }
        };

        $scope.allAbbrev = {};

        if ($scope.filters.sortOrder.hasOwnProperty("defaultSortOrder") && $scope.filters.sortOrder.hasOwnProperty("selections")) {
            $scope.allAbbrev["sortOrder"] = [];

            if ($scope.cancelFilters == true) {   // change comes from click cancel
                // clear sort order
            } else {
                $scope.allAbbrev["sortOrder"] = [];
                $scope.allAbbrev["sortOrder"].push($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].abbrev);
            }
            filterAvailStr.searchResultSortOrder = $scope.filters.sortOrder.defaultSortOrder;
        }

        if ($scope.filters.priceRange.hasOwnProperty("abbrev")) {
            $scope.allAbbrev["priceRange"] = [];
            $scope.showRzSlider = false;
            if ($scope.cancelFilters == true || ($scope.filters.priceRange.ifMax && $scope.filters.priceRange.ifMin)) {
                // change comes from click cancel or price range contains ceil and floor
                $scope.allAbbrev["priceRange"] = [];
                $scope.filters.priceRange.minValue = angular.copy($scope.filters.slider_translate.options.floor);
                $scope.filters.priceRange.maxValue = angular.copy($scope.filters.slider_translate.options.ceil);
                // clear priceRange
            } else {
                $scope.filters.priceRange.minValue = angular.copy($scope.filters.slider_translate.minValue);
                $scope.filters.priceRange.maxValue = angular.copy($scope.filters.slider_translate.maxValue);
                $scope.allAbbrev["priceRange"].push($scope.filters.priceRange.abbrev);
            }
        }

        if ($scope.filters.hotelRates) {
            $scope.allAbbrev["hotelRates"] = [];
            var repArr = [];
            for (var i = 0; i < $scope.filters.hotelRates.length; i++) {
                if ($scope.filters.hotelRates[i].value == true) {
                    if (i > -1 && i < 5) {
                        for (var q = 1; q < i + 2; q++) {
                            repArr.push(q);

                        }
                        $scope.allAbbrev["hotelRates"].push({
                            "title": $scope.filters.hotelRates[i].title,
                            "repArr": repArr
                        });

                        var currentRate = parseInt($scope.filters.hotelRates[i].title);
                        if (currentRate == 5) {
                            filterAvailStr.starRatings.push(5);
                            filterAvailStr.starRatings.push(6);
                            filterAvailStr.starRatings.push(7);
                            filterAvailStr.starRatings.push(8);
                            filterAvailStr.starRatings.push(9);
                        } else {
                            filterAvailStr.starRatings.push(parseInt($scope.filters.hotelRates[i].title));
                        }

                    }


                    if (i == 5) {  //not rated
                        $scope.allAbbrev["hotelRates"].push({
                            "title": $scope.filters.hotelRates[i].title,
                            "repArr": $scope.filters.hotelRates[i].abbrev
                        });
                        filterAvailStr.starRatings.push(parseInt($scope.filters.hotelRates[i].title));
                    }

                    repArr = [];
                }
            }

        }

        // if ($scope.filters.newAmen && $scope.filters.newAmen.length > 0) {
        //     $scope.allAbbrev["newAmen"] = [];
        //     for (var i = 0; i < $scope.filters.newAmen.length; i++) {
        //         if ($scope.filters.newAmen[i].selection == true) {
        //             //alert($scope.filters.newAmen[i].id.length);
        //             for (var p = 0; p < $scope.filters.newAmen[i].id.length; p++) {
        //                 filterAvailStr.amenityIds.push($scope.filters.newAmen[i].id[p]);
        //             }
        //             $scope.allAbbrev["newAmen"].push({
        //                 "id": $scope.filters.newAmen[i].id,
        //                 "abbrev": $scope.filters.newAmen[i].abbrev
        //             });
        //         }
        //     }
        // }

        if ($scope.filters.anoAmen && $scope.filters.anoAmen.length > 0) {
            $scope.allAbbrev["anoAmen"] = [];
            for (var j = 0; j < $scope.filters.anoAmen.length; j++) {
                if ($scope.filters.anoAmen[j].selection == true) {
                    for (var p = 0; p < $scope.filters.anoAmen[j].id.length; p++) {
                        filterAvailStr.amenityIds.push($scope.filters.anoAmen[j].id[p]);
                    }

                    $scope.allAbbrev["anoAmen"].push({
                        "id": $scope.filters.anoAmen[j].id,
                        "abbrev": $scope.filters.anoAmen[j].abbrev
                    });
                }
            }
        }

        if ($scope.filters.filterOptions && $scope.filters.filterOptions.length > 0) {
            $scope.allAbbrev["filterOptions"] = [];
            $scope.allAbbrev["filterOptionsIfShow"] = false;
            for (var i = 0; i < $scope.filters.filterOptions.length; i++) {
                $scope.allAbbrev["filterOptions"].push({});
                $scope.allAbbrev.filterOptions[i].multiSelectAbbrev = [];
                $scope.allAbbrev.filterOptions[i].title = $scope.filters.filterOptions[i].title;
                $scope.allAbbrev.filterOptions[i].abbrev = $scope.filters.filterOptions[i].abbrev;

                if ($scope.filters.filterOptions[i].title == "PACKAGES" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                    lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                        filterAvailStr.ratePlanCategory.push(val.id);
                        $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                    });
                }
                else if ($scope.filters.filterOptions[i].title == "RATE PLANS" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                    lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                        lodash.forEach(val.id, function(idVal) {
                            filterAvailStr.ratePlanCode.push(idVal);
                        });
                        $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                    });
                }
                else if ($scope.filters.filterOptions[i].title == "HOTEL NAMES" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                    lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                        filterAvailStr.hotelIds.push(val.id);
                        $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                    });
                }


                if ($scope.allAbbrev.filterOptions[i].title == "PACKAGES") {

                    if ($scope.uxConfig.enablePackageTypeFilter == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                        $scope.allAbbrev.filterOptions[i].ifShow = true;
                    } else {
                        $scope.allAbbrev.filterOptions[i].ifShow = false;
                    }

                } else if ($scope.allAbbrev.filterOptions[i].title == "RATE PLANS") {

                    if ($scope.uxConfig.enableRatePlanFilter == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                        $scope.allAbbrev.filterOptions[i].ifShow = true;
                    } else {
                        $scope.allAbbrev.filterOptions[i].ifShow = false;
                    }

                } else if ($scope.allAbbrev.filterOptions[i].title == "HOTEL NAMES") {

                    if ($scope.uxConfig.enableHotelNameFilter == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                        $scope.allAbbrev.filterOptions[i].ifShow = true;
                    } else {
                        $scope.allAbbrev.filterOptions[i].ifShow = false;
                    }

                }

                $scope.allAbbrev.filterOptionsIfShow = $scope.allAbbrev.filterOptionsIfShow || $scope.allAbbrev.filterOptions[i].ifShow;
            }

        }

        areaService.setFilter($scope.filters);
        if(!fromLoadMore) {
            areaService.setAvailFilters(filterAvailStr);
        }
        $scope.flagChangeFilter = false;    //user changes filter selections and clicks DONE button to save, save finished
        areaService.setFilterAbbr($scope.allAbbrev);

        $scope.changeAbb = false;

    }

    $scope.cancelChangeFilters = function ($event) {
        $scope.filters.selectedAmenities = [];
        $scope.cancelFilters = true;  // change comes from click cancel
        var filterAvailStr = {
            "searchResultSortOrder": 0,
            "starRatings": [],
            "hotelIds": [],
            "amenityIds": [],
            "ratePlanCategory": [],
            "ratePlanCode": [],
            priceRange: {
                maxRate: $scope.filters.priceRange.options.ceil,
                minRate: $scope.filters.priceRange.options.floor
            }
        };

        //reset $scope.filters, remove all checkboxes , reset all dropdown to 0

        //reset sort order
        if (!$scope.availCall && $scope.uxConfig.defaultSortOrder > 2) {
            $scope.filters.sortOrder.defaultSortOrder = 0;
        } else {
            $scope.filters.sortOrder.defaultSortOrder = $scope.uxConfig.defaultSortOrder;
        }
        filterAvailStr.searchResultSortOrder = $scope.filters.sortOrder.defaultSortOrder;
        areaService.setAvailFilters(filterAvailStr);


        angular.forEach($scope.filters.sortOrder.selections, function (each) {
            each.value = false;
        });
        $scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].value = true;

        //reset price range
        var newMin = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.minPriceRange);
        var newMax = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.maxPriceRange);
        var currencyDetail = areaService.getCurrencyDetails();
        var currentSymbol = currencyDetail.currencySymbol || "";

        $scope.filters.priceRange.maxValue = Math.round(newMax.toString().replace(currentSymbol, ''));
        $scope.filters.priceRange.minValue = Math.round(newMin.toString().replace(currentSymbol, ''));

        $scope.symbolSign = angular.copy($scope.filters.priceRange.currencySymbol || '$');
        var defaultMinValue = angular.copy($scope.filters.priceRange.minValue);
        var defaultMaxValue = angular.copy($scope.filters.priceRange.maxValue);

        $scope.filters.slider_translate = {
            minValue: defaultMinValue,
            maxValue: defaultMaxValue,
            options: {
                ceil: defaultMaxValue,
                floor: defaultMinValue,
                translate: function (value) {
                    if (defaultMaxValue == value) {
                        return $scope.symbolSign + value + "+";
                    } else {
                        return $scope.symbolSign + value;
                    }

                }
            }
        };

        $scope.getPriceAbbrev();

        $scope.filters.priceRange.ifMax = true;
        $scope.filters.priceRange.ifMin = true;

        // remove hotel class
        if ($scope.filters.hotelRates) {
            $scope.allAbbrev["hotelRates"] = [];
            for (var i = 0; i < $scope.filters.hotelRates.length; i++) {
                $scope.filters.hotelRates[i].value = false;
            }
        }


        //reset filter option
        angular.forEach($scope.filters.filterOptions, function (eachOption) {
            eachOption.default = 0;
            eachOption.selections[0].selection = false;
            eachOption.abbrev = "";
            eachOption.id = eachOption.selections[0].id;
            eachOption.multiSelect = [];
            angular.forEach(eachOption.selections, function (selection) {
                selection.selection = false;
            })
        });

        // reset amenities

        // angular.forEach($scope.filters.newAmen, function (each) {
        //     each.selection = false;
        // });

        angular.forEach($scope.filters.anoAmen, function (each) {
            each.selection = false;
        });

        //$scope.filters = angular.copy($scope.dupFilters);
        $scope.flagChangeFilter = true;    //user clicks CLEAR button to make changes to filter selections, unsaved changes

        //if (areaService.getAvailSearchStatus()) {
        //    areaService.setMoreDataEchoToken(0);
        //    hotelDataService.loadAvailHotels();
        //}
        //else {
        //$rootScope.$broadcast(EVENT.APPLY_UI_FILTER);
        //}
        isAvailChange = true;   //user clicks CLEAR button, reset to true
        $scope.changeAbbrevOnly();
        $scope.filterDirtyCheck = false;

        $scope.changShowFilter($event);
        $scope.tempFilters = angular.copy($scope.filters);
        var allCodeTypes = areaService.getCodeTypes();
        if(allCodeTypes != undefined && allCodeTypes.length != 0) {
            areaService.setIsNewCode(true);
        }
    };

    $scope.goGrid = function () {
        $scope.displayTypes.displayListView = false;
        $scope.displayTypes.displayListGrid = false;
        $scope.displayTypes.displayGridView = true;
        $scope.displayTypes.displaymapView = false;
        $scope.refreshMap = false;
    };

    $scope.goList = function () {
        $scope.displayTypes.displayListView = true;
        $scope.displayTypes.displayListGrid = true;
        $scope.displayTypes.displayGridView = false;
        $scope.displayTypes.displaymapView = false;
        $scope.refreshMap = false;
    };

    $scope.goMap = function () {
        $scope.displayTypes.displayListView = false;
        $scope.displayTypes.displayListGrid = false;
        $scope.displayTypes.displayGridView = false;
        $scope.displayTypes.displaymapView = true;

        setTimeout(function () {
            $scope.refreshMap = true;
            try{
                $scope.$apply();
            }
            catch(e)
            {}
        }, 100)
    };

    $scope.Show = function () {
        if ($scope.cantFind == false && $scope.combinationError == false) {
            $scope.addBorder = "";
            $scope.addError = "";
        }
        $rootScope.showAddCode = !$rootScope.showAddCode;
    };

    $scope.changePriceRangeCurrency = function ($event) {  //change the currency value and symbol
        $rootScope.toggle.showFilter = false;     //close filter panel when changing currency
        $scope.showRzSlider = false;

        var currencyDetail = areaService.getCurrencyDetails();
        var currentSymbol = currencyDetail.currencySymbol || "";
        var currentSymbol = currencyDetail.currencySymbol || "";

        var newCeil = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.maxPriceRange);
        var newFloor = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.minPriceRange);
        var newMinValue = $filter('currencyConversionAndSymbolNew')($scope.filters.slider_translate.minValue, $scope.filters.priceRange.currencyCode);
        var newMaxValue = $filter('currencyConversionAndSymbolNew')($scope.filters.slider_translate.maxValue, $scope.filters.priceRange.currencyCode);

        var ceil = Math.round(newCeil.toString().replace(currentSymbol, ''));
        var floor = Math.round(newFloor.toString().replace(currentSymbol, ''));
        var minValue = Math.round(newMinValue.toString().replace(currentSymbol, ''));
        var maxValue = Math.round(newMaxValue.toString().replace(currentSymbol, ''));
        //console.log("ceil:" + ceil + "; floor:" + floor + ";minValue:" + minValue + ";maxValue:" + maxValue);

        if (maxValue > ceil) {
            maxValue = ceil;
        }
        if (minValue < floor) {
            minValue = floor;
        }

        $scope.filters.priceRange.minValue = minValue;
        $scope.filters.priceRange.maxValue = maxValue;


        $scope.symbolSign = currencyDetail.currencySymbol || '$';
        $scope.filters.priceRange.currencySymbol = currencyDetail.currencySymbol || '$';
        $scope.filters.priceRange.currencyCode = currencyDetail.currencyCode;
        $scope.filters.priceRange.chainCurrecnyExchangeRate = currencyDetail.chainCurrecnyExchangeRate;
        $scope.filters.slider_translate = {
            minValue: minValue,
            maxValue: maxValue,
            options: {
                ceil: ceil,
                floor: floor,
                translate: function (value) {
                    if (value == ceil) {
                        return $scope.symbolSign + value + "+";
                    } else {
                        return $scope.symbolSign + value;
                    }

                }
            }
        };

        //console.log("$scope.filters.slider_translate:" + JSON.stringify($scope.filters.slider_translate));

        $scope.getPriceAbbrev();

        if ($scope.filters.priceRange.hasOwnProperty("abbrev")) {
            $scope.allAbbrev["priceRange"] = [];
            $scope.showRzSlider = false;
            if ($scope.cancelFilters == true || ($scope.filters.priceRange.ifMax && $scope.filters.priceRange.ifMin)) {
                // change comes from click cancel or price range contains ceil and floor

                $scope.allAbbrev["priceRange"] = [];
                $scope.filters.slider_translate.minValue = angular.copy(floor);
                $scope.filters.slider_translate.maxValue = angular.copy(ceil);
                // clear priceRange
            } else {

                $scope.allAbbrev["priceRange"].push($scope.filters.priceRange.abbrev);
            }
        }

        $scope.currencyChange.prev = angular.copy($scope.currencyChange.cur);
        $scope.tempFilters = angular.copy($scope.filters);

        areaService.setFilter($scope.filters);
        areaService.setFilterAbbr($scope.allAbbrev);

        //$event.preventDefault();
    };

    $scope.$on(EVENT.CODE_ADD, function () {
        //console.log("CODE_ADD");

        isAvailChange = true;    //group code is added, need avail call
        $scope.codeAdded = true;  // one add group code action, or add other types of code while group in already added
        $scope.updateAfterADDCode();
    });

    $scope.$on(EVENT.CODE_REMOVE, function () {
        //console.log("CODE_REMOVE");

        //console.log("CCCC  $scope.filters.filterOptions[1]:" + JSON.stringify($scope.filters.filterOptions[1]));
        $scope.codeAdded = false;  // no group code is added
        $scope.codeRemoved = true;    //one remove group code action
    });

    $scope.updateAfterADDCode = function () {

        var filterAvailStr = {
            "searchResultSortOrder": 0,
            "starRatings": [],
            "hotelIds": [],
            "amenityIds": [],
            "ratePlanCategory": [],
            "ratePlanCode": [],
            priceRange: {
                maxRate: $scope.filters.priceRange.maxValue,
                minRate: $scope.filters.priceRange.minValue
            }
        };

        $scope.allAbbrev = {};

        if ($scope.filters.sortOrder.hasOwnProperty("defaultSortOrder") && $scope.filters.sortOrder.hasOwnProperty("selections")) {
            $scope.allAbbrev["sortOrder"] = [];
            if ($scope.cancelFilters == true || $scope.cancelFilters == undefined) {
                // clear sort order
            } else {
                $scope.allAbbrev["sortOrder"].push($scope.filters.sortOrder.selections[$scope.filters.sortOrder.defaultSortOrder].abbrev);
            }
            filterAvailStr.searchResultSortOrder = $scope.filters.sortOrder.defaultSortOrder;

        }

        if ($scope.filters.priceRange.hasOwnProperty("abbrev")) {
            $scope.allAbbrev["priceRange"] = [];
            $scope.showRzSlider = false;
            if ($scope.cancelFilters == true || ($scope.filters.priceRange.ifMax && $scope.filters.priceRange.ifMin)) {
                $scope.allAbbrev["priceRange"] = [];
                $scope.filters.priceRange.minValue = angular.copy($scope.filters.slider_translate.options.floor);
                $scope.filters.priceRange.maxValue = angular.copy($scope.filters.slider_translate.options.ceil);
                // clear priceRange
            } else {
                $scope.filters.priceRange.minValue = angular.copy($scope.filters.slider_translate.minValue);
                $scope.filters.priceRange.maxValue = angular.copy($scope.filters.slider_translate.maxValue);
                $scope.allAbbrev["priceRange"].push($scope.filters.priceRange.abbrev);
            }
        }

        if ($scope.filters.hotelRates) {
            $scope.allAbbrev["hotelRates"] = [];
            var repArr = [];
            for (var i = 0; i < $scope.filters.hotelRates.length; i++) {
                if ($scope.filters.hotelRates[i].value == true) {
                    if (i > -1 && i < 5) {
                        for (var q = 1; q < i + 2; q++) {
                            repArr.push(q);

                        }
                        $scope.allAbbrev["hotelRates"].push({
                            "title": $scope.filters.hotelRates[i].title,
                            "repArr": repArr
                        });

                        var currentRate = parseInt($scope.filters.hotelRates[i].title);
                        if (currentRate == 5) {
                            filterAvailStr.starRatings.push(5);
                            filterAvailStr.starRatings.push(6);
                            filterAvailStr.starRatings.push(7);
                            filterAvailStr.starRatings.push(8);
                            filterAvailStr.starRatings.push(9);
                        } else {
                            filterAvailStr.starRatings.push(parseInt($scope.filters.hotelRates[i].title));
                        }

                    }


                    if (i == 5) {  //not rated
                        $scope.allAbbrev["hotelRates"].push({
                            "title": $scope.filters.hotelRates[i].title,
                            "repArr": $scope.filters.hotelRates[i].abbrev
                        });
                        filterAvailStr.starRatings.push(parseInt($scope.filters.hotelRates[i].title));
                    }

                    repArr = [];
                }
            }

        }

        // if ($scope.filters.newAmen && $scope.filters.newAmen.length > 0) {
        //     $scope.allAbbrev["newAmen"] = [];
        //     for (var i = 0; i < $scope.filters.newAmen.length; i++) {
        //         if ($scope.filters.newAmen[i].selection == true) {
        //             //alert($scope.filters.newAmen[i].id.length);
        //             for (var p = 0; p < $scope.filters.newAmen[i].id.length; p++) {
        //                 filterAvailStr.amenityIds.push($scope.filters.newAmen[i].id[p]);
        //             }
        //             $scope.allAbbrev["newAmen"].push({
        //                 "id": $scope.filters.newAmen[i].id,
        //                 "abbrev": $scope.filters.newAmen[i].abbrev
        //             });
        //         }
        //     }
        //
        // }

        if ($scope.filters.anoAmen && $scope.filters.anoAmen.length > 0) {
            $scope.allAbbrev["anoAmen"] = [];
            for (var j = 0; j < $scope.filters.anoAmen.length; j++) {
                if ($scope.filters.anoAmen[j].selection == true) {
                    for (var p = 0; p < $scope.filters.anoAmen[j].id.length; p++) {
                        filterAvailStr.amenityIds.push($scope.filters.anoAmen[j].id[p]);
                    }

                    $scope.allAbbrev["anoAmen"].push({
                        "id": $scope.filters.anoAmen[j].id,
                        "abbrev": $scope.filters.anoAmen[j].abbrev
                    });
                }
            }

        }

        if ($scope.filters.filterOptions && $scope.filters.filterOptions.length > 0) {
            $scope.allAbbrev["filterOptions"] = [];
            $scope.allAbbrev["filterOptionsIfShow"] = false;
            for (var i = 0; i < $scope.filters.filterOptions.length; i++) {
                $scope.allAbbrev["filterOptions"].push({});
                $scope.allAbbrev.filterOptions[i].multiSelectAbbrev = [];
                $scope.allAbbrev.filterOptions[i].title = $scope.filters.filterOptions[i].title;
                $scope.allAbbrev.filterOptions[i].abbrev = $scope.filters.filterOptions[i].abbrev;

                if ($scope.filters.filterOptions[i].title == "PACKAGES")
                    filterAvailStr.ratePlanCategory = [];
                else if ($scope.filters.filterOptions[i].title == "RATE PLANS")
                    filterAvailStr.ratePlanCode = [];
                else if ($scope.filters.filterOptions[i].title == "HOTEL NAMES" && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                    lodash.forEach($scope.filters.filterOptions[i].multiSelect, function(val) {
                        filterAvailStr.hotelIds.push(val.id);
                        $scope.allAbbrev.filterOptions[i].multiSelectAbbrev.push(val.abbrev);
                    });
                }

                if ($scope.allAbbrev.filterOptions[i].title == "PACKAGES") {
                    $scope.filters.filterOptions[i].default = 0;
                    for (var p = 0; p < $scope.filters.filterOptions[i].selections.length; p++) {
                        $scope.filters.filterOptions[i].selections[p].selection = false;
                    }
                    $scope.filters.filterOptions[i].selections[0].selection = false;
                    $scope.filters.filterOptions[i].abbrev = "";
                    $scope.filters.filterOptions[i].id = $scope.filters.filterOptions[i].selections[0].id;
                    $scope.filters.filterOptions[i].multiSelect = [];
                    $scope.allAbbrev.filterOptions[i].ifShow = false;

                } else if ($scope.allAbbrev.filterOptions[i].title == "RATE PLANS") {
                    $scope.filters.filterOptions[i].default = 0;
                    for (var q = 0; q < $scope.filters.filterOptions[i].selections.length; q++) {
                        $scope.filters.filterOptions[i].selections[q].selection = false;
                    }
                    $scope.filters.filterOptions[i].selections[0].selection = false;
                    $scope.filters.filterOptions[i].abbrev = "";
                    $scope.filters.filterOptions[i].id = $scope.filters.filterOptions[i].selections[0].id;
                    $scope.filters.filterOptions[i].multiSelect = [];
                    $scope.allAbbrev.filterOptions[i].ifShow = false;

                } else if ($scope.allAbbrev.filterOptions[i].title == "HOTEL NAMES") {
                    if ($scope.uxConfig.enableHotelNameFilter == true && $scope.filters.filterOptions[i].multiSelect.length != 0) {
                        $scope.allAbbrev.filterOptions[i].ifShow = true;
                    } else {
                        $scope.allAbbrev.filterOptions[i].ifShow = false;
                    }

                }

                $scope.allAbbrev.filterOptionsIfShow = $scope.allAbbrev.filterOptionsIfShow || $scope.allAbbrev.filterOptions[i].ifShow;
            }

        }

        areaService.setFilter($scope.filters);
        areaService.setAvailFilters(filterAvailStr);
        $scope.flagChangeFilter = false;   //user add codes, without changing filter selections
        //console.log("AAAA    $scope.filters.filterOptions:" + JSON.stringify($scope.filters.filterOptions));
        $scope.tempFilters = angular.copy($scope.filters);
        $scope.changeAbbrevOnly();


        //console.log("$scope.filters::" + JSON.stringify($scope.filters));
    }

    $scope.$watch('toggle.showFilter', function () {

        if ($rootScope.toggle.showFilter == false) {
            document.getElementById("filterOptionDropdown").style.display = "none";
            if ($scope.tempFilters) {
                setTimeout( (function() {
                    return function() {
                        $scope.filterDropdown.statusSortOrder.isopen = false;
                        $scope.filterDropdown.statusMoreAmen.isopen = false;
                        $scope.filters = angular.copy($scope.tempFilters);
                    };
                })() , 0);

                /*        $scope.symbolSign = angular.copy($scope.filters.priceRange.currencySymbol || '$');
                        var defaultMinValue = angular.copy($scope.filters.priceRange.minValue);
                        var defaultMaxValue = angular.copy($scope.filters.priceRange.maxValue);
                        var newCeil = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.maxPriceRange);
                        var newFloor = $filter('currencyConversionAndSymbolNew')($scope.uxConfig.minPriceRange);
                        var ceil = Math.round(newCeil.toString().replace($scope.symbolSign, ''));
                        var floor = Math.round(newFloor.toString().replace($scope.symbolSign, ''));
                        //console.log("defaultMinValue:" + defaultMinValue + "defaultMaxValue:" + defaultMaxValue + "ceil:" + ceil + " ;floor:" + floor)

                        $scope.filters.slider_translate = {
                            minValue: defaultMinValue,
                            maxValue: defaultMaxValue,
                            options: {
                                ceil: ceil,
                                floor: floor,
                                translate: function (value) {
                                    if (ceil == value) {
                                        return $scope.symbolSign + value + "+";
                                    } else {
                                        return $scope.symbolSign + value;
                                    }

                                }
                            }
                        };*/
            }
        }
        else if ($rootScope.toggle.showFilter === true) {   //open filter panel, $scope.tempFilters update to $scope.filters
            document.getElementById("filterOptionDropdown").style.display = "block";
            setTimeout( (function() {
                return function() {
                    $scope.tempFilters = angular.copy($scope.filters);
                };
            })() , 0);
            if ($rootScope.toggle != undefined && $rootScope.toggle.guestMenu == true) {
                $rootScope.toggle.guestMenu = false;
            }

            if ($rootScope.showAddCode == true) {
                $rootScope.showAddCode = false;
            }

            if ($scope.uxConfig.enablePriceFilter && $scope.availCall)
            {
                setTimeout( (function() {
                    return function() {
                        $scope.showRzSlider = true;
                        $scope.$broadcast('rzSliderForceRender');
                    };
                })() , 0);
            }

        }
    })


    $scope.$on(EVENT.CHANGE_SEARCH_CRITERIA_POST_AVAIL, function() {

        var postAvailSearchCriteria = angular.copy(hotelDataService.getPostAvailSearchCriteria());
        postAvailSearchCriteria.hotelsList = angular.copy(hotelDataService.getHotelList());
        var previousFilters = angular.copy(areaService.getFilter());
        var searchData = areaService.getMainReservation();
        $scope.filters.searchCriteria = [];
        $scope.filters.filterOptions = [];
        $scope.filters.amenities = [];
        $scope.filters.hotelRates = [];
        $scope.filters.selectedAmenities = [];
        var premiumAmenities = [];
        var basicAmenities = [];
        $scope.filters.ifShowFilterOptions = ($scope.uxConfig.enableHotelNameFilter && $scope.availCall && postAvailSearchCriteria.hasOwnProperty("hotels"))
            || ($scope.uxConfig.enableRatePlanFilter && $scope.availCall && postAvailSearchCriteria.hasOwnProperty("ratePlans")) ||
            ($scope.uxConfig.enablePackageTypeFilter && $scope.availCall && postAvailSearchCriteria.hasOwnProperty("packageCategories"));

        if (postAvailSearchCriteria.hasOwnProperty("packageCategories") && postAvailSearchCriteria.packageCategories.length > 0) {
            var package = {};
            var options = [];
            if(areaService.getIsLoadMoreAvail()) {
                postAvailSearchCriteria.packageCategories = angular.copy(areaService.getPreviousPostAvailCriteria().packageCategories.concat(postAvailSearchCriteria.packageCategories));
                var optionsNew = angular.copy(postAvailSearchCriteria.packageCategories);
                lodash.forEach(optionsNew, function(option) {
                    if(options.indexOf(option) == -1) {
                        options.push(option);
                    }
                });
            } else {
                var options = angular.copy(postAvailSearchCriteria.packageCategories);
            }
            options.sort();
            package.title = "PACKAGES";
            package.display = $rootScope.translate.page_packages_ASpackagesLbl;
            package.default = "0";
            package.enable = $scope.uxConfig.enablePackageTypeFilter;
            package.options = angular.copy(options);
            package.selections = [];
            package.multiSelect = [];
            package.selections.push({
                "title": $rootScope.translate.global_allpackages_ASallpackagesLbl,
                "selection": false,
                id: "",
                "abbrev": $rootScope.translate.global_allpackages_ASallpackagesLbl
            });

            angular.forEach(package.options, function (eachOption) {
                package.selections.push({"title": eachOption, "selection": false, id: eachOption});
            });
            package.selections[package.default].selection = false;
            package.abbrev = package.selections[package.default].title;
            package.id = package.selections[package.default].id;

            if(areaService.getIsLoadMoreAvail()) {
                var packageIds = angular.copy(hotelDataService.getLoadMoreRequestData().searchCriteria.ratePlanCategory);
                lodash.forEach(packageIds, function(packageId) {
                    var index = lodash.findIndex(package.selections, function(selectionVal) {
                        return selectionVal.id == packageId;
                    });
                    if(index != -1 && !package.selections[index].selection) {
                        package.selections[index].selection = true;
                        var filterValue = {
                            abbrev: package.selections[index].title,
                            id: package.selections[index].id
                        }
                        package.multiSelect.push(filterValue);
                    }
                });
            } else {
                for (var j = 0; j < previousFilters.filterOptions.length; j++) {
                    if(previousFilters.filterOptions[j].title === "PACKAGES") {
                        lodash.forEach(previousFilters.filterOptions[j].multiSelect, function(val) {
                            var index = lodash.findIndex(package.selections, function(selectionVal) {
                                return selectionVal.id == val.id;
                            });

                            if(index != -1 && !package.selections[index].selection) {
                                package.selections[index].selection = true;
                                var filterValue = {
                                    abbrev: package.selections[index].title,
                                    id: package.selections[index].id
                                }
                                package.multiSelect.push(filterValue);
                            }
                        });
                    }
                }
            }
            $scope.filters.filterOptions.push(package);
            $scope.filters.searchCriteria.push("PACKAGES");

        } else if(postAvailSearchCriteria.hasOwnProperty("ratePlans") && postAvailSearchCriteria.ratePlans.length == 0 && !postAvailSearchCriteria.hasOwnProperty("groupAttendeeCode")) {
            for (var j = 0; j < previousFilters.filterOptions.length; j++) {
                if(previousFilters.filterOptions[j].title === "PACKAGES") {
                    $scope.filters.filterOptions.push(previousFilters.filterOptions[j]);
                    $scope.filters.searchCriteria.push("PACKAGES");
                }
            }
        }

        if (postAvailSearchCriteria.hasOwnProperty("ratePlans") && postAvailSearchCriteria.ratePlans.length > 0) {

            var rateplan = {};
            if(areaService.getIsLoadMoreAvail()) {
                postAvailSearchCriteria.ratePlans = angular.copy(areaService.getPreviousPostAvailCriteria().ratePlans.concat(postAvailSearchCriteria.ratePlans));
                var options = angular.copy(postAvailSearchCriteria.ratePlans);
            } else {
                var options = angular.copy(postAvailSearchCriteria.ratePlans);
            }

            options.sort(compareName);
            rateplan.title = "RATE PLANS";
            rateplan.display = $rootScope.translate.page_roomrates_ASroomratesLbl;
            rateplan.default = "0";
            rateplan.enable = $scope.uxConfig.enableRatePlanFilter;
            rateplan.options = angular.copy(options);
            rateplan.selections = [];
            rateplan.multiSelect = [];

            rateplan.selections.push({
                "title": $rootScope.translate.global_allrateoptions_ASallrateoptionsLbl,
                "selection": false,
                "id": [],
                "abbrev": $rootScope.translate.global_allrateoptions_ASallrateoptionsLbl
            });

            rateplan.allTypes = [];
            angular.forEach(options, function (eachOp) {
                if (rateplan.allTypes.indexOf(eachOp.name) < 0) {
                    rateplan.allTypes.push(eachOp.name);
                }
            });

            angular.forEach(rateplan.allTypes, function (eachType) {
                var newType = {};
                newType.title = eachType;
                newType.selection = false;
                newType.id = [];

                angular.forEach(options, function (eachOp) {
                    if (eachType == eachOp.name) {
                        newType.id.push(eachOp.externalCode);
                    }
                })

                rateplan.selections.push(newType);

            });

            rateplan.selections[rateplan.default].selection = false;
            rateplan.abbrev = rateplan.selections[rateplan.default].title;
            rateplan.id = rateplan.selections[rateplan.default].id;

            for (var j = 0; j < previousFilters.filterOptions.length; j++) {
                if(previousFilters.filterOptions[j].title === "RATE PLANS") {
                    lodash.forEach(previousFilters.filterOptions[j].multiSelect, function(val) {
                        var index = lodash.findIndex(rateplan.selections, function(selectionVal) {
                            return selectionVal.title == val.abbrev;
                        });

                        if(index != -1 && !rateplan.selections[index].selection) {
                            rateplan.selections[index].selection = true;
                            var filterValue = {
                                abbrev: rateplan.selections[index].title,
                                id: rateplan.selections[index].id
                            }
                            rateplan.multiSelect.push(filterValue);
                        }
                    });
                }
            }

            if(searchData != undefined && searchData.searchCriteria != undefined && searchData.searchCriteria.ratePlanId != undefined && rateplan.selections != undefined && rateplan.selections.length > 1) {
                var isValidRatePlan = false;
                var extCode;
                var hotels = angular.copy(hotelDataService.getHotelList());
                lodash.forEach(hotels, function(hotel) {
                    lodash.forEach(hotel.ratePlans, function(ratePlan) {
                        if(ratePlan.ratePlanCode == searchData.searchCriteria.ratePlanId) {
                            isValidRatePlan = true;
                            extCode = ratePlan.externalCode;
                        }
                    });
                });
                if(isValidRatePlan) {
                    rateplan.multiSelect = [];
                    lodash.forEach(rateplan.selections, function(selection) {
                        lodash.forEach(selection.id, function(idVal) {
                            if(idVal.toLowerCase() == extCode.toLowerCase()) {
                                selection.selection = true;
                                var filterValue = {
                                    abbrev: selection.title,
                                    id: selection.id
                                }
                                rateplan.multiSelect.push(filterValue);
                            }
                        });
                    });

                }
            }

            $scope.filters.filterOptions.push(rateplan);
            $scope.filters.searchCriteria.push("RATE PLANS");

        } else if(postAvailSearchCriteria.hasOwnProperty("packageCategories") && postAvailSearchCriteria.packageCategories.length == 0 && !postAvailSearchCriteria.hasOwnProperty("groupAttendeeCode")) {
            for (var j = 0; j < previousFilters.filterOptions.length; j++) {
                if(previousFilters.filterOptions[j].title === "RATE PLANS") {
                    $scope.filters.filterOptions.push(previousFilters.filterOptions[j]);
                    $scope.filters.searchCriteria.push("RATE PLANS");
                }
            }
        }

        if (postAvailSearchCriteria.hasOwnProperty("hotels")) {
            var hotelname = {};
            var options = [];
            if(areaService.getIsLoadMoreAvail()) {
                postAvailSearchCriteria.hotels = angular.copy(areaService.getPreviousPostAvailCriteria().hotels.concat(postAvailSearchCriteria.hotels));
                var optionsNew = angular.copy(postAvailSearchCriteria.hotels);
                lodash.forEach(optionsNew, function(hotel) {
                    var flag = false;
                    lodash.forEach(options, function(optionEach) {
                        if(optionEach.id == hotel.id) {
                            flag = true;
                        }
                    });
                    if(flag == false) {
                        options.push(hotel);
                    }
                });
            } else {
                var options = angular.copy(postAvailSearchCriteria.hotels);
            }
            //options.sort();
            hotelname.title = "HOTEL NAMES";
            hotelname.display = $rootScope.translate.page_property_ASproeprtyLbl;
            hotelname.default = 0;
            hotelname.enable = $scope.uxConfig.enableHotelNameFilter;

            hotelname.selections = [];
            hotelname.multiSelect = [];

            function compareA(a, b) {
                if (a.name < b.name)
                    return -1;
                if (a.name > b.name)
                    return 1;
                return 0;
            }

            options.sort(compareA);
            hotelname.options = angular.copy(options);
            //console.log("hotelname.options:" + JSON.stringify(hotelname.options));
            hotelname.selections.push({
                "title": $rootScope.translate.global_allproperties_ASallpropertiesLbl,
                "selection": false,
                "id": ""
            });

            angular.forEach(hotelname.options, function (eachOption) {
                hotelname.selections.push({"title": eachOption.name, "id": eachOption.id, "selection": false});
            });
            hotelname.selections[hotelname.default].selection = false;
            hotelname.abbrev = hotelname.selections[hotelname.default].title;
            hotelname.id = hotelname.selections[hotelname.default].id;

            if(areaService.getIsLoadMoreAvail()) {
                var hotelIds = angular.copy(hotelDataService.getLoadMoreRequestData().searchCriteria.hotelIds);
                lodash.forEach(hotelIds, function(hotelId) {
                    var index = lodash.findIndex(hotelname.selections, function(selectionVal) {
                        return selectionVal.id == hotelId;
                    });
                    if(index != -1 && !hotelname.selections[index].selection) {
                        hotelname.selections[index].selection = true;
                        var filterValue = {
                            abbrev: hotelname.selections[index].title,
                            id: hotelname.selections[index].id
                        }
                        hotelname.multiSelect.push(filterValue);
                    }
                });
            } else {

                for (var j = 0; j < previousFilters.filterOptions.length; j++) {
                    if(previousFilters.filterOptions[j].title === "HOTEL NAMES") {
                        lodash.forEach(previousFilters.filterOptions[j].multiSelect, function(val) {
                            var index = lodash.findIndex(hotelname.selections, function(selectionVal) {
                                return selectionVal.id == val.id;
                            });

                            if(index != -1 && !hotelname.selections[index].selection) {
                                hotelname.selections[index].selection = true;
                                var filterValue = {
                                    abbrev: hotelname.selections[index].title,
                                    id: hotelname.selections[index].id
                                }
                                hotelname.multiSelect.push(filterValue);
                            }
                        });
                    }
                }
            }

            $scope.filters.filterOptions.push(hotelname);
            $scope.filters.searchCriteria.push("HOTEL NAMES");
            areaService.setAllPropertySelection(angular.copy(hotelname.selections));

        }


        var tempHotelList = [];

        if(areaService.getIsLoadMoreAvail()) {
            postAvailSearchCriteria.hotelsList = angular.copy(areaService.getPreviousPostAvailCriteria().hotelsList.concat(postAvailSearchCriteria.hotelsList));
            var optionsNew = angular.copy(postAvailSearchCriteria.hotelsList);
            lodash.forEach(optionsNew, function(hotel) {
                var flag = false;
                lodash.forEach(tempHotelList, function(optionEach) {
                    if(optionEach.hotelCode == hotel.hotelCode) {
                        flag = true;
                    }
                });
                if(flag == false) {
                    tempHotelList.push(hotel);
                }
            });
        } else {
            tempHotelList = angular.copy(postAvailSearchCriteria.hotelsList);
        }

        var hotels = angular.copy(tempHotelList);
        lodash.forEach(hotels, function(hotel) {
            if(hotel.amenity != undefined && hotel.amenity.length > 0) {
                lodash.forEach(hotel.amenity, function(amen) {
                    if(amen.premium) {
                        premiumAmenities.push(amen);
                    } else {
                        basicAmenities.push(amen);
                    }
                });
            }
        });

        if (premiumAmenities.length > 0 || basicAmenities.length > 0) {
            var amenities = angular.copy(premiumAmenities.concat(basicAmenities));
            var allAmen = [];
            for (var i = 0; i < amenities.length; i++) {
                if (allAmen.indexOf(amenities[i].name) < 0) {
                    allAmen.push(amenities[i].name);
                }
            }

            var updatedAmen = []
            for (var p = 0; p < allAmen.length; p++) {
                var amenity = {};
                amenity.title = allAmen[p];
                amenity.newId = [];
                amenity.abbrev = allAmen[p];
                updatedAmen.push(amenity);

                var name = allAmen[p];

                for (var q = 0; q < amenities.length; q++) {

                    if (amenities[q].name == name) {

                        if (updatedAmen[p].newId.indexOf(amenities[q].id) < 0) {
                            updatedAmen[p].newId.push(amenities[q].id);
                        }

                    }
                }
            }

            $scope.filters.amenities = angular.copy(updatedAmen);
            $scope.filters.searchCriteria.push("AMENITIES");

            if ($scope.filters.amenities.length > 0) {
                $scope.filters.anoAmen = [];
                for (var k = 0; k < $scope.filters.amenities.length; k++) {
                    if ($scope.filters.amenities[k]) {
                        var amenity = {};
                        amenity.title = $scope.filters.amenities[k].title;
                        amenity.id = $scope.filters.amenities[k].newId;
                        amenity.selection = false;
                        amenity.abbrev = $scope.filters.amenities[k].title;
                        $scope.filters.anoAmen.push(amenity);
                    }
                }
            }

            lodash.forEach(previousFilters.selectedAmenities, function(ameVal) {
                var index = lodash.findIndex($scope.filters.anoAmen, function(amenity) {
                    return amenity.title == ameVal.abbrev;
                });

                if(index != -1 && !$scope.filters.anoAmen[index].selection) {
                    $scope.filters.anoAmen[index].selection = true;
                    $scope.filters.selectedAmenities.push({
                        "id": $scope.filters.anoAmen[index].id,
                        "abbrev": $scope.filters.anoAmen[index].abbrev
                    });
                }
            });

        }

        if (($scope.availCall == true && $scope.uxConfig.enablePriceFilter == true) || ($scope.uxConfig.enableDisplaySortOrderFilter)) {
            $scope.filters.hotelRateIfShowSeparate = "filter-separate";
        }

        if (postAvailSearchCriteria.hasOwnProperty("starRatings")) {
            var starRatings = [];
            if(areaService.getIsLoadMoreAvail()) {
                postAvailSearchCriteria.starRatings = angular.copy(areaService.getPreviousPostAvailCriteria().starRatings.concat(postAvailSearchCriteria.starRatings));
                var starRatingsNew = angular.copy(postAvailSearchCriteria.starRatings);
                lodash.forEach(starRatingsNew, function(option) {
                    if(starRatings.indexOf(option) == -1) {
                        starRatings.push(option);
                    }
                });
            } else {
                var starRatings = angular.copy(postAvailSearchCriteria.starRatings);
            }

            if (starRatings.indexOf("1") > -1) {
                //alert("1: true");
                $scope.filters.hotelRates.push({"title": "1", "value": false, "abbrev": 1, "displayRate": true});
            } else {
                $scope.filters.hotelRates.push({"title": "1", "value": false, "abbrev": 1, "displayRate": false});
            }
            if (starRatings.indexOf("2") > -1) {

                $scope.filters.hotelRates.push({"title": "2", "value": false, "abbrev": 2, "displayRate": true});
            } else {
                $scope.filters.hotelRates.push({"title": "2", "value": false, "abbrev": 2, "displayRate": false});
            }
            if (starRatings.indexOf("3") > -1) {

                $scope.filters.hotelRates.push({"title": "3", "value": false, "abbrev": 3, "displayRate": true});
            } else {
                $scope.filters.hotelRates.push({"title": "3", "value": false, "abbrev": 3, "displayRate": false});
            }
            if (starRatings.indexOf("4") > -1) {

                $scope.filters.hotelRates.push({"title": "4", "value": false, "abbrev": 4, "displayRate": true});
            } else {
                $scope.filters.hotelRates.push({"title": "4", "value": false, "abbrev": 4, "displayRate": false});
            }
            if (starRatings.indexOf("5") > -1 || starRatings.indexOf("6") > -1 || starRatings.indexOf("7") > -1
                || starRatings.indexOf("8") > -1 || starRatings.indexOf("9") > -1) {

                $scope.filters.hotelRates.push({"title": "5", "value": false, "abbrev": 5, "displayRate": true});
            } else {
                $scope.filters.hotelRates.push({"title": "5", "value": false, "abbrev": 5, "displayRate": false});
            }
            if (starRatings.indexOf("Not Rated") > -1) {
                $scope.filters.hotelRates.push({
                    "title": "0",
                    "value": false,
                    "abbrev": "Not Rated",
                    "displayRate": true
                });
            } else {
                $scope.filters.hotelRates.push({
                    "title": "0",
                    "value": false,
                    "abbrev": "Not Rated",
                    "displayRate": false
                });
            }

            lodash.forEach(previousFilters.hotelRates, function(hotelRates) {
                if(hotelRates.value == true) {
                    var index = lodash.findIndex($scope.filters.hotelRates, function(ratingValue) {
                        return ratingValue.title == hotelRates.title;
                    });

                    if(index != -1 && $scope.filters.hotelRates[index].displayRate == true) {
                        $scope.filters.hotelRates[index].value = true;
                    }
                }
            });

        }

        $scope.dupFilters = angular.copy($scope.filters);
        areaService.setFilter($scope.filters);
        $scope.tempFilters = angular.copy($scope.filters);
        updateAbbrev(areaService.getIsLoadMoreAvail() || (hotelDataService.getMoreDataEchoToken() != null && hotelDataService.getMoreDataEchoToken() != undefined));
        areaService.setPreviousPostAvailCriteria(angular.copy(postAvailSearchCriteria));
        areaService.setIsLoadMoreAvail(false);
    });

}

subNavController.$inject = ["$scope", "areaFactory", "apiFactory", "areaService", "hotelDataService", "EVENT", '$rootScope', '$filter', 'lodash', '$window'];
