/**
 * @ngdoc directive
 * @name initCode
 * @module TravelClApp
 *
 * @description
 * Renders an input box with tag editing support.
 * support code combination logic
 */
(function () {
    'use strict';
    angular.module('TravelClApp')
        .directive('tcSpecialCodes', ['$log', '$rootScope', 'EVENT' ,'areaService', 'hotelDataService', 'areaFactory', intlCode]);
    function intlCode($log, $rootScope,EVENT, areaService, hotelDataService, areaFactory) {
        var flag = false;
        var index, i, j, k;
        return {
            restrict: 'E',
            templateUrl: './subnav/specialcodes.html',
            link: function (scope, element, attrs) {
                scope.bookNowBtn = true;
                scope.showGroupModal = 'display-none';
                scope.groupCannotRemoved = false;
                scope.reviewGroupDetails = false;
                scope.placeHolder = false;

                var uxConfig = areaFactory.getUxConfiguration();
                var isSpecialCodeEnabled = uxConfig.specialCodesFieldEnabled;



                scope.codes = [];

                scope.codeType = null;
                scope.code = null;


                var retrieveReservation = function () {
                    var Reservation = areaService.getMainReservation();
                    scope.codes = [];
                //
                   angular.forEach(Reservation.posSource.requestorIds, function (codeObj) {
                        if ((codeObj.codeType == "Group") || (codeObj.codeType == "group")) {
                            scope.groupExist = true;
                            scope.codeType = codeObj.codeType;
                            scope.code = codeObj.id;
                            updateCode();
                            scope.placeHolder = true;
                //        }else if((Reservation.isModifiable == true) && (codeObj.codeType == "corporate") || (codeObj.codeType == "Corporate")){
                        }else {
                            scope.codeType = codeObj.codeType;
                            scope.code = codeObj.id;
                            updateCode();
                            scope.placeHolder = true;
                        }

                    })

                    scope.code = null;

                };
                scope.$on(EVENT.SET_GROUP_CODE, function () {
                    var Reservation = areaService.getMainReservation();
                    scope.codes = [];
                    scope.codeType = 'Group';
                    scope.code = Reservation.groupAttendeeCode;
                    updateCode();
                    scope.placeHolder = true;
                    scope.code = null;
                    scope.codeType = scope.codeTypes[0].name;
                });

                scope.displayWidget = false;
                if ((uxConfig.enablePromotionalCodes == true) || (uxConfig.enableDiscountCode == true) || (uxConfig.enableGroupCode == true)) {
                    scope.displayWidget = true;
                }
                var initCodes = function () {
                    scope.codes = [];
                //    $log.debug(areaService.getCodeTypes());
                    if (areaService.getCodeTypes()) {
                        angular.forEach(areaService.getCodeTypes(), function (response) {
                            if ((response == "Group") || (response == "group")) {
                                scope.groupExist = true;
                            }
                            var allCode = areaService.getCodeValue(response);
                            if (allCode) {
                                scope.codes.push(allCode);
                            }

                        });
                        if (scope.codes[0]) {
                            scope.placeHolder = true
                        }
                    }
                    else {
                        if (areaService.getConfig("GROUP_SPlASH") == undefined) {
                            retrieveReservation();
                        }

                    }
                };
                ////For custome dropdown selected value.
                scope.setSelectedItem = function (codeType) {
                    //console.log("setSelectedItem ::" +codeType );
                    scope.selected = codeType.language;
                    scope.codeType = codeType.name;
                }
                //
                var getDropDown = function () {

                    var codesArray = [];
                    scope.codeTypes = [];
                     if (scope.displayWidget == true) {
                        for (var i = 0; i < areaFactory.getCodeDisplay().length; i++) {

                            if ((areaFactory.getCodeDisplay()[i].code == "Corporate") && (uxConfig.enablePromotionalCodes == true)) {
                                codesArray.push({
                                    name: areaFactory.getCodeDisplay()[i].code,
                                    language: scope.translate[areaFactory.getCodeDisplay()[i].name]
                                });
                            }
                            else if ((areaFactory.getCodeDisplay()[i].code == "Discount") && (uxConfig.enableDiscountCode == true)) {
                                codesArray.push({
                                    name: areaFactory.getCodeDisplay()[i].code,
                                    language: scope.translate[areaFactory.getCodeDisplay()[i].name]
                                });
                            }
                            else if ((areaFactory.getCodeDisplay()[i].code == "Group") && (uxConfig.enableGroupCode == true)) {
                                codesArray.push({
                                    name: areaFactory.getCodeDisplay()[i].code,
                                    language: scope.translate[areaFactory.getCodeDisplay()[i].name]
                                });
                            }

                        }

                        codesArray.sort(function (a, b) {
                            if(a.language != undefined && b.language != undefined){
                                var textA = a.language.toUpperCase();
                                var textB = b.language.toUpperCase();
                                return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                            }

                        });
                         scope.codeTypes = codesArray;
                         scope.codeType = scope.codeTypes[0].name;
                         scope.selected = scope.codeTypes[0].language;
                         //

                    }
                };

              /*  scope.$on(EVENT.LANG_CHANGE, function () {
                    console.log("EVENT.LANG_CHANGE >> .");
                    getDropDown();
                    //$scope.$apply();
                });
*/
                scope.$watch("translate", function(){
                    getDropDown();
                })

                var GroPro = function () {
                    if ((scope.codeType == "Group") && (areaService.getCodeTypes()[j] == "Corporate")) {
                        if (scope.cantFind == true) {
                            scope.cantFind = false;
                        }
                        scope.combinationError = true;
                     //   scope.addBorder = "1px solid #ccc";
                     //   scope.addError = "1px solid red";
                        areaService.deleteCodeTypeByIndex(j);
                        areaService.deleteAllCodeByKey("Corporate");
                        scope.codes.splice(j, 1);
                        j--;

                    }
                };
                var ProGro = function () {
                    if ((scope.codeType == "Corporate") && (areaService.getCodeTypes()[j].toLowerCase() == "group" || areaService.getGroupId())) {
                        if (scope.cantFind == true) {
                            scope.cantFind = false;
                        }
                        scope.combinationError = true;
                    //    scope.addBorder = "1px solid #ccc";
                    //    scope.addError = "1px solid red";
                        areaService.deleteCodeTypeByIndex(j);
                        areaService.deleteAllCodeByKey("Group");
                        scope.codes.splice(j, 1);
                        j--;
                    }
                };

                //to get flag decide if update the code
                var updateFlag = function () {
                    for (i = 0; i < areaService.getCodeTypes().length; i++) {
                        if (areaService.getCodeTypes()[i] == scope.codeType) {
                            flag = true;
                            index = i;
                        }
                    }
                };
                //update Code or not
                var updateCode = function () {
                    if (flag) {
                        //if(scope.codeType == "Group"){
                        //    areaService.addGroupCode(scope.code);
                        //}
                        scope.codes[index] = scope.code;
                        areaService.addToAllCodes(scope.codeType, scope.code);
                        flag = false;


                    }
                    else {
                        if (scope.code) {
                            //if(scope.codeType == "Group"){
                            //    areaService.addGroupCode(scope.code);
                            //}
                            scope.codes.push(scope.code);
                            areaService.setCodeType(scope.codeType);
                            areaService.addToAllCodes(scope.codeType, scope.code);
                        }
                    }
                };
                //
                //

                if(isSpecialCodeEnabled && scope.displayWidget)
                {
                    initComponent();
                }

                function initComponent()
                {
                    initCodes();
                    scope.toggle = false;
                    getDropDown();
                }

                scope.Show = function (event) {
                    removeCombineError();

                    $rootScope.showAddCode = !$rootScope.showAddCode;
                    scope.toggle = !scope.toggle;

                    if($rootScope.toggle != undefined && $rootScope.toggle.guestMenu == true) {
                        $rootScope.toggle.guestMenu = false;
                    }

                    event.stopPropagation();
                };

                scope.toggleShowAddShow = function() {
                    if($rootScope.showAddCode == true) {
                        $rootScope.showAddCode = false;
                    }
                }


                scope.addCode = function () {
                    //console.log("scope.codeType && scope.code :: "+scope.codeType + " :" +  scope.code);
                    if (scope.codeType && scope.code) {
                        $rootScope.startTime = Date.now();
                        scope.cantFind = false;
                        scope.combinationError = false;
                        scope.showCutOffError = false;

                        scope.code = scope.code.toLowerCase();
                    //    //then validate in server side use post then get the response
                        var codeType = scope.codeType.toLowerCase();

                        if ((scope.codeType == "Group") && areaService.getGroupId()){
                            areaService.deleteAllCodeByKey("Group");
                        }

                            var resCodeTypes = areaService.getCodeTypes();
                            if (resCodeTypes != undefined) {
                    //            $log.error("enter the validateTAPromoDiscount success function");
                                var loopLength = resCodeTypes.length;
                    //
                                for (j = 0; j < areaService.getCodeTypes().length; j++) {

                                        //input Group Attendee, already have the Promo/Corporate, remain the Group Attendee
                                        GroPro();
                                        //input Promo/Corporate, already have the Group Attendee,remain the Promo/Corporate
                                        ProGro();

                                    if (j + 1 == areaService.getCodeTypes().length) {
                                        // update the codes
                                        updateFlag();
                    //
                    //                    //updateCode();
                                    }
                    //
                                }
                              }
                              updateCode();


                        var allCodeTypes = areaService.getCodeTypes();
                        areaService.setIsNewCode(true);
                        //console.log("allCodeTypes:"+JSON.stringify(allCodeTypes));
                        if(codeType === "group") {
                        //|| allCodeTypes.indexOf("Group")>-1
                        //    console.log("group")
                            $rootScope.$broadcast(EVENT.CODE_ADD);
                        } else {
                            if(allCodeTypes.indexOf("Group") < 0) {
                                $rootScope.$broadcast(EVENT.CODE_REMOVE);
                            }
                            //console.log("not  group")
                            areaService.setMoreDataEchoToken(0);
                            areaService.removeRatePlanId();
                            hotelDataService.loadAvailHotels();
                        }


                         /*   if (scope.combinationError == false) {
                                scope.addBorder = "";
                                scope.addError = "";
                            }*/
                              scope.placeHolder = true;
                              scope.toggle = false;
                              $rootScope.showAddCode = false;
                    //
                             scope.codeType = scope.codeTypes[0].name;
                            //Added default code for custome dropdown.
                            scope.setSelectedItem(scope.codeTypes[0]);
                            scope.code = undefined;


                    }
                    else {
                     /*   scope.addError = "1px solid red";
                        scope.addBorder = "1px solid #ccc";
                        if (scope.combinationError == true) {
                            scope.combinationError = false;
                        }*/
                        scope.cantFind = true;
                    }

                };

                function removeCombineError()
                {
                    scope.cantFind = false;
                    scope.combinationError = false;
                //    scope.addBorder = "";
                //    scope.addError = "";

                }


                scope.cancelAdd = function () {
                    scope.code = undefined;
                    scope.codeType = scope.codeTypes[0].name;
                    //Added default code for custome dropdown.
                    scope.setSelectedItem(scope.codeTypes[0]);
                //    scope.addError = "";
                    //scope.toggle = false;
                    scope.combinationError = false;
                    scope.cantFind = false;
                    scope.showCutOffError = false;
                    $rootScope.showAddCode = false;
                    scope.toggle = false;

                };

                scope.remove = function (idx, event) {
                    removeCombineError();
                    scope.groupCannotRemoved = false;
                    var codeType = areaService.getCodeTypes()[idx];
                    $log.debug(codeType);
                        if (codeType.toLowerCase() == "group") {
                            //scope.deleteGroup = "display-block";
                            //scope.deleteGroupWindow = $window.pageYOffset + 180 + 'px';
                            $rootScope.$broadcast("EVENT.DELETE_GROUP");
                          //  return false
                            areaService.removeOtherCode(codeType.toLowerCase())

                        }
                        else {
                            if (codeType.toLowerCase() == "discount") {
                                areaService.removeDiscountCode();
                            } else {
                                areaService.removeOtherCode(codeType.toLowerCase())
                            }

                        }
                    scope.codes.splice(idx, 1);

                //    //delete the code pair in service
                    areaService.deleteAllCodeByKey(areaService.getCodeTypes()[idx]);
                //    //delete CodeType in service
                    areaService.deleteCodeTypeByIndex(idx);
                    if (areaService.getCodeTypes().length <= 0) {
                        scope.placeHolder = false;
                    }

                    var allCodeTypes = areaService.getCodeTypes();

                    if(allCodeTypes != undefined && allCodeTypes.length != 0) {
                        areaService.setIsNewCode(true);
                    } else {
                        areaService.setIsNewCode(false);
                        areaService.setResetPropertyFilterSelection(true);
                    }
                    //console.log("codeType:"+codeType);
                    if(codeType == "Group") {
                        $rootScope.$broadcast(EVENT.CODE_REMOVE);
                        areaService.removeRatePlanId();
                        hotelDataService.loadAvailHotels();
                    } else if(allCodeTypes.indexOf("Group")> -1) {
                        $rootScope.$broadcast(EVENT.CODE_ADD);
                    } else {
                        areaService.removeRatePlanId();
                        hotelDataService.loadAvailHotels();
                    }


                //    $log.error(JSON.stringify(areaService.getMainReservation()) + "asdasdasdasd")
                    event.stopPropagation();
                };

            }
        }

    }
})();
