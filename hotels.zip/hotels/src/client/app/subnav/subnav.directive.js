/**
 * Created by yhuang on 1/26/2017.
 */

angular.module('TravelClApp').directive('subNav', function () {
    return {
        restrict: 'E',
        templateUrl: './subnav/subnav.html',
        controller: subNavController
    };
});

angular.module('TravelClApp').directive("outsideClick", ['$document', '$parse', function($document, $parse) {
  return {
    restrict: 'A',
    link: function (scope, element, attrs) {
      var clickOutFunction = $parse(attrs.clickOutFunction);

      $document.on('touchend click', function (event) {
        if (element[0].contains(event.target)) return;
        scope.$apply(function() {
            clickOutFunction(scope, {$event: event});
        });
      });
    }
  };
}]);
