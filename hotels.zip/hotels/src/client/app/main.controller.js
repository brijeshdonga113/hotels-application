/**
 * Created by sramani on 1/5/2017.
 */
angular.module('TravelClApp')
//    .controller('MainController', ['$scope', 'areaService', 'EVENT', '$rootScope', 'areaFactory', '$analytics', '$window', '$location', 'navDataFactory', '$log', 'apiFactory','toaster', function MainController($scope, areaService, EVENT, $rootScope, areaFactory, $analytics, $window, $location, navDataFactory, $log, apiFactory, toaster) {
     .controller('MainController', ['$rootScope', '$window', function MainController( $rootScope, $window) {

         $rootScope.translate =  $window.chainInfo.translations;
         $rootScope.params = $window.params;
    }]);
