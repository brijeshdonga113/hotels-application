angular.module('TravelClApp',
    [
        'ngSanitize',
        'ui.bootstrap',
        'ui.router',
        'ngAnimate',
        'toaster',
        'duScroll',
        'angular-cache',
        'angulartics',
        'uiGmapgoogle-maps',
        'ngTouch',
        'angular-jwt',
        'angular-storage',
        'daterangepicker',
        'rzModule',
        'vAccordion'
    ]);

angular.module('TravelClApp')
    .run([
        "$rootScope","$state", "$stateParams","$http","CacheFactory", "$document", "$window",function ($rootScope, $state, $stateParams, $http, CacheFactory, $document, $window) {

            $rootScope.$state = $state;
            $rootScope.bgHideSpinner = true;
            //Added for vertical stop to 0 when visiting any page
            $rootScope.$on('$stateChangeSuccess', function(){
                $document.scrollTopAnimated(0,0);
            });
            //if(!CacheFactory.get('defaultCache')){
            $http.defaults.cache = CacheFactory('defaultCache', {
                maxAge: 5 * 60 * 1000,  //Items added to this cache expire after 5 minutes
                cacheFlushInterval: 30 * 60 * 1000,  //This cache will clear itself every 30 minutes
                deleteOnExpire: 'aggressive' // Items will be deleted from this cache when they expire
            });

            $rootScope.toggle = {
                collapse: true,
                guestMenu:false,
                searchMenu:false,
                datesMenu:false,
                showFilter : false
            };
            $rootScope.isGoogleLocationProgress = false;
            $rootScope.apiCountValue = 0;

            return $rootScope.$stateParams = $stateParams;
        }
    ])

  .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$uiViewScrollProvider', '$httpProvider', '$provide', function ($stateProvider, $urlRouterProvider, $locationProvider, $uiViewScrollProvider, $httpProvider, $provide) {

        $uiViewScrollProvider.useAnchorScroll();
        // For any unmatched url, redirect to /
        $urlRouterProvider.otherwise("/");

        $httpProvider.interceptors.push('APIInterceptor');


    }]);
