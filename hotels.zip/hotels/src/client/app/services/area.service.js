/**
 * Created by sramani on 1/19/2017.
 */
angular.module('TravelClApp')
    .factory('areaService', ['$log', '$rootScope', 'EVENT', 'areaFactory', 'CacheFactory', '$window', '$filter', areaService]);
// .factory('hotelFactory', buildOptions);

function areaService($log, $rootScope, EVENT, areaFactory, CacheFactory, $window, $filter) {
    //FUTURE CONCERN: Will this become asynchronous?
    //Most values here are hardCoded. Where Should we be populating the values from?


    var isHotelInfoDone = false;
    var isAvailCallDone = false

    var hotelDataReady = false;
    var previousPostAvailCriteria;
    var currentCurrency;
    var currentLanguage;
    var currencyDetails;
    var guestData;
    var searchDestination;
    var filterSelection;
    var zoomLevel;
    var filterAbbr;
    var defaultSortOrder = areaFactory.getDefaultOrder();
    var allPropertySelection;
    var hoverHotelId;
    var isNewCode;
    var resetPropertyFilterSelection;
    var isLoadMoreAvail;

    var gtmDataLayerPropertyVariables = {};

    var maxAvailResponseLimit = 24;

    var availSearchStatus = false;

    var checkPromo = false;

    var googleNoResults = false;

    var MainReservation = {
        "languageCode": "",
        "maxResponses": maxAvailResponseLimit,
        "moreDataEchoToken": 0,
        "searchCriteria": {
            "searchResultSortOrder": defaultSortOrder,
            "numberOfUnits": 1,
            "destinationSearch": {},
            "timeSpan": {
                "start": null,
                "end": null
            },

            "guestCounts": [
                {
                    "ageQualifyingCode": "10",
                    "count": 0
                },
                {
                    "ageQualifyingCode": "8",
                    "count": 0
                }, {
                    "ageQualifyingCode": "7",
                    "count": 0
                }],

            "starRatings": [],
            "hotelIds": [],
            "position": {},
            "radius": {
                "distance": "100",
                "unitOfMeasureCode": 1
            },
            "priceRange": {
                "maxRate": 0,
                "minRate": 0
            },
            "amenityIds": [],
            "ratePlanCategory": [],
            "ratePlanCodes": []

        },
        "posSource": {
            "requestorIds": []
        }
    };

    /*{
     geoPosition:{},
     geoName:'',
     destinationSearch:{}
     } ;*/

    var dates = {};

    var config = {};
    var pageCache;

    var specialCodes = [];

    var groupInfo = undefined;

    var params = $window.params;
    params = params.split("\\");
    if(params != "{}"){
        params = JSON.parse(params);
    }


    init();

    function setConfig(key) {
        if (config == undefined) {
            config = {};
        }
        config[key] = true;
    }

    function getConfig(key) {
        return config[key];
    }

    function deleteConfig(key) {
        if (config[key] != undefined) {
            delete config[key]
        }
    }

    var openNewWindow;

    function setOpenNewWindowFlag(value) {
        if (!CacheFactory.get('openNewWindow')) {
            openNewWindow = CacheFactory.createCache('openNewWindow', {
                deleteOnExpire: 'aggressive',
                maxAge: 30 * 60 * 1000, // 30 Mins
                recycleFreq: 60000,
                storageMode: 'sessionStorage'
            })
        }
    }

    function getOpenNewWindowFlag() {
        if (!CacheFactory.get('openNewWindow')) {
            openNewWindow = CacheFactory.createCache('openNewWindow', {
                deleteOnExpire: 'aggressive',
                maxAge: 30 * 60 * 1000, // 30 Mins
                recycleFreq: 60000,
                storageMode: 'sessionStorage'
            })
        }
        // var openNewWindow1 = openNewWindow.get('/page/open/'+hotelFactory.getHotelInfo().hotelCode);

        if (!openNewWindow1) {
            return null;

        } else {
            return openNewWindow1;
        }
    }

    function init() {
        //$rootScope.continueModifyReservation = false;
        var chainInfo = areaFactory.getChainInfo();
        var occupancyInfo = chainInfo.occupancyInfo;

        if (!CacheFactory.get('pageCache')) {
            pageCache = CacheFactory.createCache('pageCache', {
                deleteOnExpire: 'aggressive',
                maxAge: 30 * 60 * 1000, // 30 Mins
                recycleFreq: 60000,
                storageMode: 'sessionStorage'
            })
        }

        filterSelection = pageCache.get('/page/filter/' + areaFactory.getChainCode());

        filterAbbr = pageCache.get('/page/filterAbbr/' + areaFactory.getChainCode());

        var fromCache = pageCache.get('/page/reservation/' + areaFactory.getChainCode());
        if (fromCache) {
            if (fromCache.MainReservation)
                MainReservation = fromCache.MainReservation;

            MainReservation.moreDataEchoToken = 0;

            if (fromCache.guestData)
                guestData = fromCache.guestData;

            if (fromCache.dates)
                dates = fromCache.dates;

            if (fromCache.searchDestination)
                searchDestination = fromCache.searchDestination;

            if (fromCache.availSearchStatus)
                availSearchStatus = fromCache.availSearchStatus;

            //var groupInfoFromManageUrl = $window.groupInfo;
            if (fromCache.groupInfo != undefined) {
                groupInfo = fromCache.groupInfo;
            }
            else {
                //    groupInfo = groupInfoFromManageUrl;
            }

            if (fromCache.checkPromo) {
                checkPromo = fromCache.checkPromo;
            }

            if(fromCache.currentCurrency)
            {
                currentCurrency = fromCache.currentCurrency;
            }

            if(fromCache.currentLanguage)
            {
                currentLanguage = fromCache.currentLanguage;
            }

        }
        else {
            guestData = {};
            guestData.adult = occupancyInfo.defaultAdult;
            guestData.children = 0;
            guestData.infant = 0;
            if(occupancyInfo.allowChildren)
                guestData.children = occupancyInfo.defaultChild;
            if(occupancyInfo.allowInfants)
                guestData.infant = occupancyInfo.defaultInfants;
            guestData.rooms = occupancyInfo.defaultRooms;

         //   setGuestData(guestData);

            dates = {startDate: null, endDate: null};

            setCurrency(areaFactory.getCurrentCurrency());
            setLanguage(areaFactory.getCurrentLanguages());

        }

    }

    function getMainReservation() {
        return MainReservation;
    }

    function setGuestData(data) {
        guestData = data;
        // console.log("MainReservation.searchCriteria:: "+MainReservation.searchCriteria);
        angular.forEach(MainReservation.searchCriteria.guestCounts, function (guest, index) {
            if (guest.ageQualifyingCode == "10") {
                MainReservation.searchCriteria.guestCounts[index].count = guestData.adult;
            }
            if (guest.ageQualifyingCode == "8") {
                MainReservation.searchCriteria.guestCounts[index].count = guestData.children;
            }
            if (guest.ageQualifyingCode == "7") {
                MainReservation.searchCriteria.guestCounts[index].count = guestData.infant;
            }
        });
        MainReservation.searchCriteria.numberOfUnits = guestData.rooms;

        //pageCache.put('/page/guestData/'+areaFactory.getChainCode(),guestData);

    }

    function getGuestData(data) {
        return guestData;
    }

    function setCalendarData(data) {
        dates = data;

        MainReservation.searchCriteria.timeSpan.start = moment(dates.startDate).format('YYYY-MM-DD')
        MainReservation.searchCriteria.timeSpan.end = moment(dates.endDate).format('YYYY-MM-DD')

        // pageCache.put('/page/datesofstay/'+areaFactory.getChainCode(),dates);
    }

    function deleteCalendarData() {
        MainReservation.searchCriteria.timeSpan.start = null;
        MainReservation.searchCriteria.timeSpan.end = null;

        // pageCache.put('/page/datesofstay/'+areaFactory.getChainCode(),dates);
    }

    function getCalendarData(data) {
        return dates;
    }

    function setDestinationData(data) {
        searchDestination = data;
        if (searchDestination.destinationSearch) {
            MainReservation.searchCriteria.destinationSearch.countryCode = searchDestination.destinationSearch.countryCode;
            MainReservation.searchCriteria.destinationSearch.region = searchDestination.destinationSearch.region;
            MainReservation.searchCriteria.destinationSearch.stateCode = searchDestination.destinationSearch.state;
            MainReservation.searchCriteria.destinationSearch.cityName = searchDestination.destinationSearch.city;
            MainReservation.searchCriteria.destinationSearch.neighbourhood = searchDestination.destinationSearch.neighborhood;

            /*if (searchDestination.destinationSearch.hotelId) {
             MainReservation.searchCriteria.hotelIds = searchDestination.destinationSearch.hotelId;
             }*/
        }
        else if (searchDestination.geoPosition) {
            MainReservation.searchCriteria.position = searchDestination.geoPosition;
        }
        else {
            MainReservation.searchCriteria.destinationSearch = {};
            //MainReservation.searchCriteria.hotelIds = [];
            MainReservation.searchCriteria.position = {};
        }

        if(searchDestination.radius)
        {
            MainReservation.searchCriteria.radius = {
                "distance": searchDestination.radius.toString(),
                "unitOfMeasureCode": 1
            }
        }

        // pageCache.put('/page/destination/'+areaFactory.getChainCode(),searchDestination);
    }

    function getDestinationData(data) {
        return searchDestination;
    }

    function setLanguage(lang) {
        //MainReservation.languageCode = langcode;
        //pageCache.put('/page/language/'+areaFactory.getChainCode(),currentLanguage);
        currentLanguage = lang;
        MainReservation.languageCode = lang.languageCode;
    }

    function getLanguage() {
        if (currentLanguage)
            return currentLanguage;
        else
            return areaFactory.getCurrentLanguages()
    }

    function setCurrency(currency) {
        currentCurrency = currency;
        MainReservation.currencyCode = currency.currencyCode;
        //   pageCache.put('/page/currency/'+areaFactory.getChainCode(),currentCurrency);
    }

    function getCurrency() {
        if (currentCurrency != undefined)
            return currentCurrency;
        else
            return areaFactory.getCurrentCurrency()
    }

    function setAvailSearchStatus(status) {
        availSearchStatus = status;
        //  pageCache.put('/page/availSearchStatus/'+areaFactory.getChainCode(),availSearchStatus);
    }

    function getAvailSearchStatus() {
        return availSearchStatus;
    }

    function setFilter(data) {
        filterSelection = angular.copy(data);
        pageCache.put('/page/filter/' + areaFactory.getChainCode(), filterSelection);
    }

    function getFilter() {
        return filterSelection;
    }

    function setFilterAbbr(data) {
        filterAbbr = angular.copy(data);
        pageCache.put('/page/filterAbbr/' + areaFactory.getChainCode(), filterAbbr);
    }

    function getFilterAbbr() {
        return filterAbbr;
    }

    function setGroup(groupInfoParam) {
        changeGroupInfo(groupInfoParam);
    }

    function getGroup() {
        return groupInfo;
    }

    function changeGroupInfo(value) {
        groupInfo = value;
        //pageCache.put('/page/group/'+areaFactory.getChainCode(),groupInfo);
    }

    function addToAllCodes(key, value) {
        if (MainReservation.allCodes == undefined) {
            MainReservation.allCodes = {};
        }
        MainReservation.allCodes[key] = value;
        MainReservation.posSource.requestorIds = [];
        $rootScope.$broadcast(EVENT.RES_SELECTION_CHANGE);
        if (MainReservation["codeType"] != undefined) {
            var codeTypesArray = MainReservation["codeType"];
            //Pass codes to 'posSource' object if user enters code in code widget
            for (var i = 0; i < codeTypesArray.length; i++) {
               // if (!params.groupid) {
                    var tempCodeType = "";
                    if (codeTypesArray[i] == "Discount")
                        tempCodeType = "DiscountAccessCode";
                    else
                        tempCodeType = codeTypesArray[i].toLowerCase();

                    var tempSpecialCode = {};
                    tempSpecialCode["codeType"] = tempCodeType;
                    tempSpecialCode["id"] = getCodeValue(codeTypesArray[i]);
                    MainReservation.posSource.requestorIds.push(tempSpecialCode);
                    //}
                    //else if (codeTypesArray[i] == "Discount") {
                    //    MainReservation.roomStays[0].discountCode = getCodeValue(codeTypesArray[i]);
                    // }
               /* }else{
                    var tempCodeType = "";
                    if (codeTypesArray[i] == "Discount"){
                        tempCodeType = "DiscountAccessCode";
                        var tempSpecialCode = {};
                        tempSpecialCode["codeType"] = tempCodeType;
                        tempSpecialCode["id"] = MainReservation.allCodes[key];
                        MainReservation.posSource.requestorIds.push(tempSpecialCode);
                    }

                }*/
            }
        }

    }

    function setGroupAttendeeCode(code){
        MainReservation.groupAttendeeCode = code;
    }

    function setCodeType(key) {
        if (!MainReservation["codeType"]) {
            MainReservation["codeType"] = [];
            MainReservation["codeType"].push(key);
        } else {
            MainReservation["codeType"].push(key);
        }
    }

    function getAllCode() {
        return MainReservation.allCodes;
    }

    function getCodeValue(key) {
        return MainReservation.allCodes[key];
    }

    function getCodeTypes() {
        if (MainReservation["codeType"] != undefined) {
            return MainReservation["codeType"];
        } else {
            return [];
        }
    }

    function deleteCodeTypeByIndex(index) {
        //if(!isModifyReservation) {
        MainReservation.codeType.splice(index, 1);
        $rootScope.$broadcast(EVENT.RES_SELECTION_CHANGE);
        //}
    }

    function deleteAllCodeByKey(key) {
        if (MainReservation.allCodes) {
            delete MainReservation.allCodes[key];
            if (key === "Group") {
                setGroup(undefined);
                if (MainReservation.searchCriteria.groupId) {
                    delete MainReservation.searchCriteria.groupId;
                }
                if(MainReservation.groupAttendeeCode)
                {
                    delete MainReservation.groupAttendeeCode;
                }
            }
        }
        var requestorIds = MainReservation.posSource.requestorIds;
        if (requestorIds.length > 0) {
            for (var i = 0; i < requestorIds.length; i++) {
                if (requestorIds[i].codeType == key) {
                    requestorIds.splice(i, 1);
                    MainReservation.posSource.requestorIds = requestorIds;
                }
            }
        }

    }


    function addGroupCode(code){
        MainReservation.searchCriteria.groupId = code;
    }

    function getGroupId(){
        return MainReservation.searchCriteria.groupId;
    }

    function deleteGroupId(){
        if (MainReservation.searchCriteria.groupId) {
            delete MainReservation.searchCriteria.groupId;
        }
    }

    /*function deleteGroupCode() {
        var key = "Group";
        if (MainReservation.allCodes) {
            if (MainReservation.allCodes[key]) {
                delete MainReservation.allCodes[key];
                angular.forEach(MainReservation.codeType, function (codeType, index) {
                    if (codeType == key) {
                        MainReservation.codeType.splice(index, 1);
                    }
                });
            }
        }
        if (MainReservation.posSource) {
            if (MainReservation.posSource.requestorIds) {
                var requestorIds = MainReservation.posSource.requestorIds;
                if (requestorIds.length > 0) {
                    for (var i = 0; i < requestorIds.length; i++) {
                        if (requestorIds[i].codeType == key.toLowerCase()) {
                            requestorIds.splice(i, 1);
                            MainReservation.posSource.requestorIds = requestorIds;
                        }
                    }
                }
            }


        }
    }*/

    function removeDiscountCode() {
        //delete MainReservation.roomStays[0]["discountCode"];
        for (var i = 0; i < MainReservation.posSource.requestorIds.length; i++) {
            if (MainReservation.posSource.requestorIds[i].codeType == "DiscountAccessCode") {
                MainReservation.posSource.requestorIds.splice(i, 1);
                break;
            }
        }

    }

    function removeOtherCode(codeType) {
        for (var i = 0; i < MainReservation.posSource.requestorIds.length; i++) {
            if (MainReservation.posSource.requestorIds[i].codeType.toLowerCase() == codeType) {
                MainReservation.posSource.requestorIds.splice(i, 1);
                break;
            }
        }
        if(codeType.toLowerCase() == "group"){
            if(MainReservation.searchCriteria.groupId){
                delete MainReservation.searchCriteria.groupId;
            }

            if(MainReservation.groupAttendeeCode){
                delete MainReservation.groupAttendeeCode;
            }
        }
    }

    function setPromoCache() {

        var checkPromo = true;
    }

    function getPromoCache() {
        return checkPromo;
    }

    function setReservation(newReservation) {
        MainReservation = newReservation;
    }


    function getMaxAvailResponseLimit() {
        return maxAvailResponseLimit;
    }

    function setMoreDataEchoToken(tokenNo) {
        MainReservation.moreDataEchoToken = parseInt(tokenNo);
    }

    function setAvailFilters(filterAvailObj) {
        MainReservation.searchCriteria.searchResultSortOrder = filterAvailObj.searchResultSortOrder;
        MainReservation.searchCriteria.starRatings = filterAvailObj.starRatings;
        MainReservation.searchCriteria.hotelIds = filterAvailObj.hotelIds;
        MainReservation.searchCriteria.amenityIds = filterAvailObj.amenityIds;
        MainReservation.searchCriteria.ratePlanCategory = filterAvailObj.ratePlanCategory;
        MainReservation.searchCriteria.ratePlanCodes = filterAvailObj.ratePlanCode;

        MainReservation.searchCriteria.priceRange = {};
        MainReservation.searchCriteria.priceRange.maxRate = filterAvailObj.priceRange.maxRate;
        MainReservation.searchCriteria.priceRange.minRate = filterAvailObj.priceRange.minRate;
    }

    function getAvailFilters() {
        return MainReservation.searchCriteria;
    }

    function removeAvailFilters() {
        MainReservation.searchCriteria.searchResultSortOrder = 0;
        MainReservation.searchCriteria.starRatings = [];
        MainReservation.searchCriteria.hotelIds = [];
        MainReservation.searchCriteria.amenityIds = [];
        MainReservation.searchCriteria.ratePlanCategory = [];
        MainReservation.searchCriteria.ratePlanCode = [];
        if (MainReservation.searchCriteria.priceRange)
            delete MainReservation.searchCriteria.priceRange;
    }

    function setGtmDataLayerPropertyVariables(value) {
        gtmDataLayerPropertyVariables = angular.copy(value);
    }

    function setNoResults(value) {
        googleNoResults = value;
    }

    function getNoResults() {
        return googleNoResults;
    }

    function setZoomLevel(level) {
        zoomLevel = level;
    }

    function getZoomLevel() {
        return zoomLevel;
    }

    function setHotelDataReady(flag)
    {
        hotelDataReady = flag;
    }

    function isHotelDataReady()
    {
        return hotelDataReady;
    }

    function setIsNewCode(value) {
        isNewCode = value;
    }

    function getIsNewCode() {
        return isNewCode;
    }

    function setAllPropertySelection(value) {
        allPropertySelection = value;
    }

    function getAllPropertySelection() {
        return allPropertySelection;
    }

    function setResetPropertyFilterSelection(value) {
        resetPropertyFilterSelection = value;
    }

    function getResetPropertyFilterSelection() {
        return resetPropertyFilterSelection;
    }

    function setRatePlanId(id){
        MainReservation.searchCriteria.ratePlanId = id;
    }

    function removeRatePlanId(){
        if(MainReservation.searchCriteria.ratePlanId){
            delete MainReservation.searchCriteria.ratePlanId ;
        }
    }

    function setHoverHotelId(id) {
        hoverHotelId = angular.copy(id);
    }

    function getHoverHotelId() {
        return hoverHotelId;
    }

    function getIsLoadMoreAvail() {
        return isLoadMoreAvail;
    }

    function setIsLoadMoreAvail(value) {
        isLoadMoreAvail = angular.copy(value);
    }

    function setPreviousPostAvailCriteria(value) {
        previousPostAvailCriteria = angular.copy(value);
    }

    function getPreviousPostAvailCriteria() {
        return previousPostAvailCriteria;
    }

    function setIsHotelInfoDone() {
        isHotelInfoDone = true;
    }

    function getIsHotelInfoDone() {
        return isHotelInfoDone;
    }

    function setIsAvailCallDone() {
        isAvailCallDone = true;
    }

    function getIsAvailCallDone() {
        return isAvailCallDone;
    }

    return {
        setIsHotelInfoDone: setIsHotelInfoDone,
        getIsHotelInfoDone: getIsHotelInfoDone,
        setIsAvailCallDone: setIsAvailCallDone,
        getIsAvailCallDone: getIsAvailCallDone,
        setResetPropertyFilterSelection: setResetPropertyFilterSelection,
        getResetPropertyFilterSelection: getResetPropertyFilterSelection,
        setAllPropertySelection: setAllPropertySelection,
        getAllPropertySelection: getAllPropertySelection,
        getIsNewCode: getIsNewCode,
        setIsNewCode: setIsNewCode,
        setZoomLevel: setZoomLevel,
        getZoomLevel: getZoomLevel,
        setNoResults: setNoResults,
        getNoResults: getNoResults,
        setOpenNewWindowFlag: setOpenNewWindowFlag,
        setConfig: setConfig,
        getConfig: getConfig,
        deleteConfig: deleteConfig,
        setGuestData: setGuestData,
        getGuestData: getGuestData,
        setLanguage: setLanguage,
        getLanguage: getLanguage,
        setCurrency: setCurrency,
        getCurrency: getCurrency,
        setCalendarData: setCalendarData,
        getCalendarData: getCalendarData,
        setDestinationData: setDestinationData,
        getDestinationData: getDestinationData,
        setCodeType: setCodeType,
        getCodeTypes: getCodeTypes,
        getCodeValue: getCodeValue,
        getGroup: getGroup,
        setGroup: setGroup,
        deleteCodeTypeByIndex: deleteCodeTypeByIndex,
        deleteAllCodeByKey: deleteAllCodeByKey,
        removeOtherCode: removeOtherCode,
        removeDiscountCode: removeDiscountCode,
        getAllCode: getAllCode,
        addToAllCodes: addToAllCodes,
        setAvailSearchStatus: setAvailSearchStatus,
        getAvailSearchStatus: getAvailSearchStatus,
        getPromoCache: getPromoCache,
        setPromoCache: setPromoCache,
        setReservation: setReservation,
        getMainReservation: getMainReservation,
        setFilter: setFilter,
        getFilter: getFilter,
        setFilterAbbr:setFilterAbbr,
        getFilterAbbr:getFilterAbbr,
        setAvailFilters: setAvailFilters,
        getMaxAvailResponseLimit: getMaxAvailResponseLimit,
        setMoreDataEchoToken: setMoreDataEchoToken,
        deleteCalendarData: deleteCalendarData,
        addGroupCode: addGroupCode,
        setGtmDataLayerPropertyVariables: setGtmDataLayerPropertyVariables,
        setGroupAttendeeCode: setGroupAttendeeCode,
        deleteGroupId:deleteGroupId,
        getGroupId:getGroupId,
        isHotelDataReady:isHotelDataReady,
        setHotelDataReady:setHotelDataReady,
        getAvailFilters: getAvailFilters,
        setRatePlanId: setRatePlanId,
        removeRatePlanId: removeRatePlanId,
        setHoverHotelId: setHoverHotelId,
        getHoverHotelId: getHoverHotelId,
        getIsLoadMoreAvail: getIsLoadMoreAvail,
        setIsLoadMoreAvail: setIsLoadMoreAvail,
        getPreviousPostAvailCriteria: getPreviousPostAvailCriteria,
        setPreviousPostAvailCriteria: setPreviousPostAvailCriteria
    }
}
