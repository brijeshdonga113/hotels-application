'use strict'

angular.module('TravelClApp')
    .factory('apiFactory', ['$rootScope', '$window', '$http', '$q', '$log', apiFunction]);
function apiFunction($rootScope, $window, $http, $q, $log) {
    //The API URL
    var apiUrl = $window.apiUrl;
    var i;
    var getUrl = function (url) {
        var deferred = $q.defer();
        $http.get(url)
            .success(function (data) {
                $log.debug(data + "the data in apifactory");
                deferred.resolve(data);
            })
            .error(function (error) {
                $log.error("getAPI-error");
                deferred.reject(error.errorsAndWarnings);
            });
        $log.debug(deferred.promise + "this is deferred.promise");
        return deferred.promise;
    };
    var getUrlWithCache = function (url) {
        var deferred = $q.defer();
        $http.get(url, {
            cache: true
        })
            .success(function (data) {

                deferred.resolve(data);
            })
            .error(function (error) {

                deferred.reject(error.errorsAndWarnings);
            });

        return deferred.promise;
    };

    return {
        getHotels: function (chainCode, lang) {
          //  var url =  "http://ibeapil01-t4.ilcb.tcprod.local:8080/ibe/v1" + '/chain/' + chainCode + '/hotels';
          //  var url =  apiUrl + '/chain/' + chainCode + '/hotels?lang=' + lang;
            var url =  './hotels.json';
            return getUrl(url);
        },

        getAvails: function (chainCode, reqData) {

            var availReqData = angular.copy(reqData);
          
            var req = {
                method: 'POST',
                //url: "http://ibeapil01-t4.ilcb.tcprod.local:8090/ibe/v1" + '/chain/' + chainCode + '/avail?lang='+lang,
                url: apiUrl + '/chain/' + chainCode + '/avail',

                data: availReqData

            };

            return $http(req);
        }

    }
}
