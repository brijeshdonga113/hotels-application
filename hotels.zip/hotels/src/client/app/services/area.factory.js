angular.module('TravelClApp')
    .factory('areaFactory', ['$rootScope', '$window', 'apiFactory', '$q', 'EVENT', areaFunction]);

function areaFunction($rootScope, $window, apiFactory, $q, EVENT) {
    var chainInfo = $window.chainInfo;
    var hotelList = [];
    //Deep copy the original chainInfo JSON.
    var chainInfoCopy = angular.copy(chainInfo);
    var currentLanguageCode = chainInfo.currentLanguage.languageCode;
    var langTranslations = {};
    langTranslations[currentLanguageCode] = chainInfo.translations;

    var currencyMapAry = [];
    var allCurrency = chainInfo.currencies;
    for (var i = 0; i < allCurrency.length; i++) {
        currencyMapAry[allCurrency[i].currencyCode] = {
            exchangeRate: allCurrency[i].exchangeRate,
            chainCurrecnyExchangeRate:allCurrency[i].chainCurrecnyExchangeRate,
            currencyDisplayFormat:allCurrency[i].currencyDisplayFormat,
            currencySymbol:allCurrency[i].currencySymbol,
            isDefaultCurrency:allCurrency[i].isDefaultCurrency,
        }
    }

    return {

        /*   getTimeZone : function(){
         return chainInfo.timeZone;
         },

         */
        getDefaultOrder: function () {
            return chainInfo.uxConfiguration.defaultSortOrder;
        },
        getChainCode: function () {
            return $window.chainCode;
        },
        getChainInfo: function () {
            return chainInfo;
        },
        getLanguages: function () {
            return chainInfo.languages;
        },
        getCurrentCurrency: function () {
            return chainInfo.currentCurrency;
        },
        getDefaultCurrency: function () {
            var continueLoop = true;
            var defaultCurrency = {};
            //checking isDefaultCurrency flag to get default currency
            angular.forEach(chainInfo.currencies, function (currency, key) {
                if (continueLoop) {
                    if (currency.isDefaultCurrency === true) {
                        continueLoop = false;
                        defaultCurrency = currency;
                    }
                }
            });
            return defaultCurrency;
        },
        getDefaultLanguage: function () {
            var continueLoop = true;
            var defaultLanguage = {};
            //checking isDefaultLanguage flag to get default language
            angular.forEach(chainInfo.languages, function (language, key) {
                if (continueLoop) {
                    if (language.isDefaultLanguage === true) {
                        continueLoop = false;
                        defaultLanguage = language;
                    }
                }
            });
            return defaultLanguage;
        },
        getCurrentLanguages: function () {
            return chainInfo.currentLanguage;
        },
        getCurrencies: function () {
            return chainInfo.currencies;
        },
        getCurrencyMapAry:function()
        {
            return currencyMapAry;
        },

        getOccupancyInfo: function () {
            return chainInfo.occupancyInfo;
        },
        getTranslation: function () {
            return chainInfo.translations;
        },
        getTranslations: function (chainCode, lang) {
            var deferred = $q.defer();
            if (langTranslations[lang]) {
                $rootScope.translate = langTranslations[lang];
                deferred.resolve($rootScope.translate);
            }
            else {
                apiFactory.getTranslations(chainCode, lang).then(function (response) {
                    langTranslations[lang] = response.translations;
                    $rootScope.translate = response["translations"];
                    deferred.resolve($rootScope.translate);
                }, function(error){
                    deferred.reject(error);
                });
            }
            return deferred.promise;
        },
        getCalConfigInfo: function () {
            return chainInfo.uxConfiguration.calendarConfig;
        },
        getUxConfiguration: function () {
            return chainInfo.uxConfiguration;
        },
        /*
         getCountries : function(){
         return chainInfo.countries;
         },*/
        getBrandInfo: function () {
            return chainInfo.brandInfo;
        },

        getChainLogo: function () {
            return chainInfo.chainLogo;
        },
        getDestination: function () {
            return chainInfo.destinationInfo;
        },

        setDisplayHotelList: function (list) {
            hotelList = list;

        },

        getDisplayHotelList: function () {
            return hotelList;
        },

        getCodeDisplay: function () {
            //  return hotelDescOriginal.uxConfiguration.specialCodesConfigList;
            var dummySpecialCodesConfigList = [

                {
                    "code": "Corporate",
                    "name": "global_promocorporate_ASpromocorporateLbl"
                },
                {
                    "code": "Discount",
                    "name": "global_discount_ASdiscountLbl"
                },
                {
                    "code": "Group",
                    "name": "global_groupattendee_ASgroupattendeeLbl"
                }
            ];
            return dummySpecialCodesConfigList;
        }

    }
}
