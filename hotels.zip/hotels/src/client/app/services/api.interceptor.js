'use strict';

/**
 * @ngdoc function
 * @name
 * @description
 * # APIInterceptor
 * Service Factory that will be an interceptor in order to show/hide the
 * spinner when making API calls
 */
angular.module('TravelClApp')
    .service('APIInterceptor', ['EVENT','$q', '$rootScope', '$log', '$location', '$window', '$timeout', function(EVENT, $q, $rootScope, $log, $location, $window, $timeout) {
        var service = this;
        var apiCount = 0;
        //This variable is used for show/hide Global Navigation Bar display.

        service.request = function(config) {
            $log.debug("service.request:Show Spinner");

            if (config.url.indexOf('.html') < 0) {
                // for hide spinner in background service calls
                apiCount++;
                ($rootScope.bgHideSpinner) ? ($rootScope.showSpinner = true) : ($rootScope.bgHideSpinner = true);
            }

            var token = $window.authToken;
            // If in any case token is empty than API call is not going from UI side
            $log.debug('setting bearer token in service.request');
            config.headers.Authorization = token;

            return config;
        };

        service.requestError = function(config) {
            $log.debug("service.requestError:Show Spinner");
            $rootScope.showSpinner = true;

            return config;
        };

        service.response = function(response) {
            $log.debug("service.response:Hide Spinner");
            if (response.config.url.indexOf('.html') < 0) {
                apiCount--;
                if($rootScope.ALTERNATE_HOTEL_SPLASH != true && apiCount == 0){
                    $rootScope.showSpinner = false;
                }
            }


            return response;
        };

        service.responseError = function(response) {
            if(response.status == 401){
                $rootScope.$broadcast(EVENT.AUTH_ERROR);
            }
            apiCount--;
            $log.debug("service.responseError:Hide Spinner");
            if(apiCount == 0)
                $rootScope.showSpinner = false;

            return $q.reject(response); /* without this reject the error goes into success handler */

        }}]);
