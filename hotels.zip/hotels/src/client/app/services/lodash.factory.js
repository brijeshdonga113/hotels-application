angular.module('TravelClApp')
    .factory('lodash', ['$window', lodashFactoryMethod]);


function lodashFactoryMethod($window) {
  if(!$window._){
      var script = document.createElement('script');
      script.src = 'scripts/lodash.min.js';
      document.body.appendChild(script);
  }
  return $window._;
}

lodashFactoryMethod.$inject = ['$window'];
