/**
 * Created by sramani on 6/8/2017.
 */
'use strict'

angular.module('TravelClApp')
    .factory('googleLocationService', ['$rootScope', '$window', '$http', '$q', '$log', googleLocationService]);
function googleLocationService($rootScope, $window, $http, $q, $log) {
    //The API URL

    var geocoder = new google.maps.Geocoder;
    //var autocomplete = new google.maps.places.Autocomplete(document.getElementById(scope.elemId), {placeIdOnly: true, types:["geocode"]});
    var service = new google.maps.places.AutocompleteService();

    var getLocationByPrediction = function (prediction) {
        ($rootScope.bgHideSpinner) ? ($rootScope.showSpinner = true) : ($rootScope.bgHideSpinner = true);
        var deferred = $q.defer();
        service.getPlacePredictions({
            input: prediction,
            types:["geocode"]
        }, function(predictions, status) {
            if (status == google.maps.places.PlacesServiceStatus.OK) {
                if(predictions.length > 0){
                    var prediction = predictions[0];
                    //locationPre = prediction.description;
                    getLocationByPlace(prediction).then(function(data){
                        $rootScope.showSpinner = false;
                        deferred.resolve(data);
                    },function(error){
                        $rootScope.showSpinner = false;
                        deferred.reject(error);
                    });

                }
                else
                {
                    $rootScope.showSpinner = false
                    deferred.reject("No Place Exist");
                }
            }
            else
            {
                $rootScope.showSpinner = false;
                deferred.reject("No Place Exist");
            }
        });
        return deferred.promise;
    };
    var getLocationByPlace = function (place) {
        ($rootScope.bgHideSpinner) ? ($rootScope.showSpinner = true) : ($rootScope.bgHideSpinner = true);
        //console.log("place.name :: "+place.name);
        var deferred = $q.defer();
        if (!place.place_id) {
            $rootScope.showSpinner = false;
            deferred.reject("No Place Exist");
        }
        else {
        }
        geocoder.geocode({'placeId': place.place_id}, function (results, status) {
            $rootScope.showSpinner = false;
            if (status !== 'OK') {
                return;
            }
            //console.log("results[0] :: "+JSON.stringify(results[0]));
            var radius = 50;
            if(results[0].geometry.bounds)
            {
         //       console.log("results[0].geometry :: "+ results[0].geometry.bounds.getNorthEast().lat() + " : " + results[0].geometry.bounds.getNorthEast().lng())
          //      console.log("results[0].geometry :: "+ results[0].geometry.bounds.getSouthWest().lat() + " : " + results[0].geometry.bounds.getSouthWest().lng())
                var neRadius = getDistanceFromLatLonInKm(results[0].geometry.bounds.getNorthEast().lat(), results[0].geometry.bounds.getNorthEast().lng(), results[0].geometry.location.lat(), results[0].geometry.location.lng() );
                var swRadius = getDistanceFromLatLonInKm(results[0].geometry.bounds.getSouthWest().lat(), results[0].geometry.bounds.getSouthWest().lng(), results[0].geometry.location.lat(), results[0].geometry.location.lng() );
                if(neRadius > swRadius)
                    radius = neRadius;
                else
                    radius = swRadius;
            }
            else if(results[0].geometry.viewport)
            {
           //     console.log("results[0].geometry :: "+ results[0].geometry.viewport.getNorthEast().lat() + " : " + results[0].geometry.viewport.getNorthEast().lng())
            //    console.log("results[0].geometry :: "+ results[0].geometry.viewport.getSouthWest().lat() + " : " + results[0].geometry.viewport.getSouthWest().lng())
                neRadius = getDistanceFromLatLonInKm(results[0].geometry.viewport.getNorthEast().lat(), results[0].geometry.viewport.getNorthEast().lng(), results[0].geometry.location.lat(), results[0].geometry.location.lng() );
                swRadius = getDistanceFromLatLonInKm(results[0].geometry.viewport.getSouthWest().lat(), results[0].geometry.viewport.getSouthWest().lng(), results[0].geometry.location.lat(), results[0].geometry.location.lng() );
                if(neRadius > swRadius)
                    radius = neRadius;
                else
                    radius = swRadius;
            }

    //        console.log("neRadius :: "+neRadius);
    //        console.log("swRadius :: "+swRadius);


            if(radius <50)
                radius = 50;

            deferred.resolve({
                geoPosition: {
                    "latitude": results[0].geometry.location.lat(),
                    "longitude": results[0].geometry.location.lng()
                },
                geoName: place.name?place.name : place.description,
                radius : radius
            });

        });
        return deferred.promise;
    };

    function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
        var R = 6371; // Radius of the earth in km
        var dLat = deg2rad(lat2-lat1);  // deg2rad below
        var dLon = deg2rad(lon2-lon1);
        var a =
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
                Math.sin(dLon/2) * Math.sin(dLon/2)
            ;
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        var d = R * c; // Distance in km
        return d/1.609344;
    }

    function deg2rad(deg) {
        return deg * (Math.PI/180)
    }

    return {
        getLocationByPlace: getLocationByPlace,
        getLocationByPrediction : getLocationByPrediction
    }
}

