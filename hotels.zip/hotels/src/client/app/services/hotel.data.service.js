/**
 * Created by sramani on 4/11/2017.
 */
angular.module('TravelClApp')
    .factory('hotelDataService', ['$rootScope', '$window', 'apiFactory', 'EVENT', 'areaService', 'areaFactory', 'toaster' , '$document', hotelDataFunction]);

function hotelDataFunction($rootScope, $window, apiFactory, EVENT, areaService, areaFactory, toaster, $document) {
    var isAvailCall = false;
    var hotelIndex = 0;
    var hotelList = [];
    var searchCriteria = {};
    var intHotelList = [];
    var postAvailSearchCriteria = [];

    var chainInfo = areaFactory.getChainInfo();
    var occupancyInfo = chainInfo.occupancyInfo;

    //var lang = chainInfo.currentLanguage.languageCode;

    var loadMoreRequest;
    var moreDataEchoToken = 0;
    var isSearchCriteriaReady = false;
    var isAvailDataEventReady = false;
    var isAvailDataErrorEventReady = false;

    function loadAllHotelData() {
        var currentLanguageObj = areaService.getLanguage();
        var lang = currentLanguageObj.languageCode;

        apiFactory.getHotels(chainCode, lang).then(function (data) {
            if (data) {
                var tempDestData = areaService.getDestinationData();
                var tempCalendarData = areaService.getCalendarData();


                if (data.hasOwnProperty("searchCriteria")) {

                    searchCriteria = data.searchCriteria;
                    isSearchCriteriaReady = true;
                    $rootScope.$broadcast(EVENT.SEARCH_CRITERIA_DATA_READY);
                    if(isAvailDataEventReady)
                    {
                        $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_READY, "avail");
                    }
                    else if(isAvailDataErrorEventReady)
                    {
                        $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_NOT_EXIST);
                    }
                }

                /*if(areaService.getAvailSearchStatus() && (tempCalendarData.startDate != null && tempCalendarData.endDate != null))
                 {
                 loadAvailHotels();
                 }
                 else */
                if (data.hasOwnProperty("hotelList") && !isAvailCall) {
                    hotelList = data.hotelList;
                    intHotelList = data.hotelList;
                    $rootScope.$broadcast(EVENT.HOTELS_DATA_READY);
                }
                areaService.setHotelDataReady(true);
                areaService.setIsHotelInfoDone();
                if(areaService.getIsAvailCallDone() === true) {
                    $rootScope.$broadcast(EVENT.CHANGE_SEARCH_CRITERIA_POST_AVAIL);
                }
            }
        });
    }

    function loadAvailHotels(isLoadMore) {
        $rootScope.isAvailCallRequire = true;
        if ($rootScope.isGoogleLocationProgress && $rootScope.isGoogleLocationProgress == true) {
            return;
        }
        $rootScope.isAvailCallRequire = false;

        var dates = areaService.getCalendarData();
        var currentLanguageObj = areaService.getLanguage();
        if (isLoadMore && isLoadMore == true) {
            var searchData = loadMoreRequest;
        }
        else {
            searchData = areaService.getMainReservation();
        }
        searchData = angular.copy(searchData);
        var manageUrlGroupFlag = false;
        var guestData = areaService.getGuestData();
        searchData.languageCode = currentLanguageObj.languageCode;
        //START-Set children and Infant values to ZERO if Group is in `text
        if (searchData.searchCriteria.groupId != undefined) {
            manageUrlGroupFlag = true;
            for (var i = 0; i < searchData.searchCriteria.guestCounts.length; i++) {
                if (searchData.searchCriteria.guestCounts[i].ageQualifyingCode == "8") {
                    searchData.searchCriteria.guestCounts[i].count = 0;
                }
                if (searchData.searchCriteria.guestCounts[i].ageQualifyingCode == "7") {
                    searchData.searchCriteria.guestCounts[i].count = 0;
                }
            }
            var key = "Group";
            if (searchData.allCodes) {
                if (searchData.allCodes[key]) {
                    delete searchData.allCodes[key];
                    angular.forEach(searchData.codeType, function (codeType, index) {
                        if (codeType == key) {
                            searchData.codeType.splice(index, 1);
                        }
                    });
                }
            }
            if (searchData.posSource) {
                if (searchData.posSource.requestorIds) {
                    var requestorIds = searchData.posSource.requestorIds;
                    if (requestorIds.length > 0) {
                        for (var i = 0; i < requestorIds.length; i++) {
                            if (requestorIds[i].codeType == key.toLowerCase()) {
                                requestorIds.splice(i, 1);
                                searchData.posSource.requestorIds = requestorIds;
                            }
                        }
                    }
                }

            }

        }
        if (searchData.posSource.requestorIds.length > 0 && !manageUrlGroupFlag) {
            for (var i = 0; i < searchData.posSource.requestorIds.length; i++) {
                if (searchData.posSource.requestorIds[i].codeType.toLowerCase() == 'group') {
                    for (var j = 0; j < searchData.searchCriteria.guestCounts.length; j++) {
                        if (searchData.searchCriteria.guestCounts[j].ageQualifyingCode == "8") {
                            searchData.searchCriteria.guestCounts[j].count = 0;
                        }
                        if (searchData.searchCriteria.guestCounts[j].ageQualifyingCode == "7") {
                            searchData.searchCriteria.guestCounts[j].count = 0;
                        }
                    }
                }
            }
        }


        //END-Set children and Infant values to ZERO if Group is in context
        if (dates.startDate && dates.endDate && (guestData.adult >= guestData.rooms)) {
            isAvailCall = true;
            areaService.setAvailSearchStatus(true);
            if(!isLoadMore)
                $document.scrollTopAnimated(0,0);

            apiFactory.getAvails(chainInfo.chainCode, searchData).success(function (data) {
                if (data) {
                    moreDataEchoToken = data.moreDataEchoToken;
                    areaService.setMoreDataEchoToken(data.moreDataEchoToken);
                    loadMoreRequest = angular.copy(areaService.getMainReservation());
                    if (data.hasOwnProperty("hotelList")) {
                        hotelList = data.hotelList;
                        toaster.clear();
                        if (hotelList.length == 0) {
                            toaster.pop({
                                type: "error",
                                title: "",
                                body: $rootScope.translate.page_nonepropavl_ASnonepropavlLbl
                            });

                            if(isSearchCriteriaReady)
                                $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_NOT_EXIST);
                            else
                                isAvailDataErrorEventReady = true;
                        }
                        else {
                            var currencyMapAry = areaFactory.getCurrencyMapAry();
                            hotelList.forEach(function (obj) {
                                obj.hotelToChainRate = (obj.rate) * currencyMapAry[obj.currentCurrency.currencySymbol].chainCurrecnyExchangeRate;
                            });
                            if(isSearchCriteriaReady)
                                $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_READY, "avail");
                            else
                                isAvailDataEventReady = true;
                        }
                    }

                    if (data.hasOwnProperty("groupAttendeeCode") && manageUrlGroupFlag) {
                        areaService.setGroupAttendeeCode(data.groupAttendeeCode);
                        //areaService.deleteGroupId();
                        $rootScope.$broadcast(EVENT.SET_GROUP_CODE, data.groupAttendeeCode);
                    }
                    areaService.setHotelDataReady(true);
                    areaService.setIsAvailCallDone();
                    if(data.hasOwnProperty('searchCriteria')) {
                        postAvailSearchCriteria = angular.copy(data.searchCriteria);
                        if(data.groupAttendeeCode != undefined) {
                            postAvailSearchCriteria.groupAttendeeCode = angular.copy(data.groupAttendeeCode);
                        }
                        if(areaService.getIsHotelInfoDone() === true) {
                            $rootScope.$broadcast(EVENT.CHANGE_SEARCH_CRITERIA_POST_AVAIL);
                        }
                    }

                }
            }).error(function (errData) {
                if (errData.errors) {
                    if(isSearchCriteriaReady)
                        $rootScope.$broadcast(EVENT.AVAIL_HOTELS_DATA_NOT_EXIST);
                    else
                        isAvailDataErrorEventReady = true;
                    if (errData.errors.length > 0) {
                        if (errData.errors[0].errorCode == "ERROR_NOT_FOUND" && !isLoadMore) {
                            toaster.pop({
                                type: "error",
                                title: "",
                                body: $rootScope.translate.page_nonepropavl_ASnonepropavlLbl
                            });
                        }
                        if (errData.errors[0].errorCode == "DATE_RANGE_TOO_HIGH") {
                            toaster.pop({
                                type: "error",
                                title: "",
                                body: "Selected date range is too high. Select dates upto 30 nights"
                            });
                            $rootScope.$broadcast(EVENT.CLEAR_CALENDAR_DATA);
                        }
                        return false;
                    }
                    areaService.setHotelDataReady(true);
                }
            });
        }
    }

    function checkApiCountAndAvailCall() {
        if ($rootScope.apiCountValue == 0) {
            loadAvailHotels();
        }
    }

    function getHotelList() {
        return hotelList;
    }

    function getIntHotelList() {
        //var maxRespose = areaService.getMaxAvailResponseLimit();
        //var nextList = intHotelList.slice(hotelIndex, hotelIndex + maxRespose);
        //hotelIndex += maxRespose;
        return intHotelList;
    }

    /*function isMoreIntHotelExist()
     {
     if(hotelIndex >= intHotelList.length)
     return false;
     return true;
     }*/

    function getSearchCriteria() {
        return searchCriteria;
    }

    function getMoreDataEchoToken() {
        return moreDataEchoToken;
    }

    function getPostAvailSearchCriteria() {
        return postAvailSearchCriteria;
    }

    //loadAllHotelData();
    function getLoadMoreRequestData() {
        return loadMoreRequest;
    }

    return {

        getHotelList: getHotelList,
        loadAllHotelData: loadAllHotelData,
        loadAvailHotels: loadAvailHotels,
        getSearchCriteria: getSearchCriteria,
        getIntHotelList: getIntHotelList,
        checkApiCountAndAvailCall: checkApiCountAndAvailCall,
        getMoreDataEchoToken: getMoreDataEchoToken,
        getPostAvailSearchCriteria: getPostAvailSearchCriteria,
        getLoadMoreRequestData: getLoadMoreRequestData

        // isMoreIntHotelExist:isMoreIntHotelExist
    }
}

