angular.module('TravelClApp')
    .factory('svgCacheService', svgCacheService);

function svgCacheService() {

    var svgCache = [];
    var svgCacheCallBack = [];
    var Request;

    if (window.XMLHttpRequest) {
        Request = new XMLHttpRequest();
        if (Request.withCredentials !== undefined) {
            Request = XMLHttpRequest;
        } else {
            Request = XDomainRequest || undefined;
        }
    }

    function getSvgFile(url,callback) {

        if(svgCacheCallBack[url] == undefined || svgCache[url] == null)
        {
            svgCacheCallBack[url] = [];
        }

        if(svgCache[url] == undefined || svgCache[url] == null ) // If SVG is called first time
        {
            svgCacheCallBack[url].push(callback); // ADD SVG callback into Array
            svgCache[url] = "";
            new loadSVGFile(url,function (url, data) {
                svgCache[url] = data;
                if(svgCacheCallBack[url].length > 0)
                {
                    for(var i = 0;i<svgCacheCallBack[url].length;i++)
                    {
                        svgCacheCallBack[url][i](data);
                    }
                    svgCacheCallBack[url] = [];
                }
            });
        }
        else
        {
            if(svgCache[url] != "") // If SVG is loaded then just return it from Cache
                callback(svgCache[url])
            else
                svgCacheCallBack[url].push(callback); // ADD SVG callback into Array
        }
    }

    function loadSVGFile(url, callback) {
        var xhr = new Request();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == "200") {
                // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
                callback(url,xhr.responseText);
            }
        };
        //xhr.onload = callback(xhr.responseText);
        xhr.open('GET', url);
        xhr.send();
    }

    return {
        getSvgFile: getSvgFile
    }
}