/**
 * Created by sramani on 1/31/2017.
 */
angular.module("TravelClApp").directive("guestAndRooms",guestAndRooms)

function guestAndRooms() {
    return {
        restrict: 'E',
        templateUrl: './guestandrooms/guestandrooms.html',
        controller: GuestAndRoomsController
    }
}