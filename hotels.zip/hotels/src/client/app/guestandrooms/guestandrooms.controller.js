angular.module('TravelClApp')
    .controller('GuestAndRoomsController', ['$rootScope', '$log', '$scope', 'EVENT', 'navDataFactory','areaFactory', 'areaService', 'toaster', '$window' , GuestAndRoomsController]);

function GuestAndRoomsController($rootScope, $log, $scope,EVENT, navDataFactory, areaFactory,areaService, toaster, $window) {
    var cacheData = areaService.getGuestData();
    var originData;
    $scope.chainInfo = areaFactory.getChainInfo();
    $scope.occupancyInfo = $scope.chainInfo.occupancyInfo;
    $scope.maxRoomsPerBooking = $scope.chainInfo.maxRoomsPerBooking;
    $scope.parseInt = parseInt;
    var params = $window.params;

    $scope.toggleGuest = function () {
        $rootScope.toggle.guestMenu = !$rootScope.toggle.guestMenu;
    };

    $scope.$on(EVENT.GUEST_ROOM_DROPDOWN_OPEN,function(){
        $scope.guestData = angular.copy(originData);
    });

    if($scope.guestData.adult < $scope.guestData.rooms)
    {
        $scope.guestError = true;
        toaster.error({
            title: "",
            body: $rootScope.translate.global_specifiedrooms_ASspecifiedroomsLbl + $scope.guestData.rooms + " " + $rootScope.translate.global_specifiedadults_ASspecifiedadultsLbl + $scope.guestData.adult
        });
    }

    if ($scope.guestData.adult > $scope.occupancyInfo.maxAdultOccupancy * $scope.guestData.rooms) {
        $scope.guestData.adult = $scope.occupancyInfo.maxAdultOccupancy * $scope.guestData.rooms;
        areaService.setGuestData($scope.guestData);
        $rootScope.$broadcast(EVENT.UPDATE_GUEST_AND_ROOMS);
    }

    if ($scope.occupancyInfo.allowChildren && ($scope.guestData.children > $scope.occupancyInfo.maxChildOccupancy * $scope.guestData.rooms)) {
        $scope.guestData.children = $scope.occupancyInfo.maxChildOccupancy * $scope.guestData.rooms;
        areaService.setGuestData($scope.guestData);
        $rootScope.$broadcast(EVENT.UPDATE_GUEST_AND_ROOMS);
    }

    if ($scope.occupancyInfo.allowInfants && ($scope.guestData.infant > $scope.occupancyInfo.maxChildOccupancy * $scope.guestData.rooms)) {
        $scope.guestData.infant = $scope.occupancyInfo.maxChildOccupancy * $scope.guestData.rooms;
        areaService.setGuestData($scope.guestData);
        $rootScope.$broadcast(EVENT.UPDATE_GUEST_AND_ROOMS);
    }

    $scope.updateGuest= function () {
        var guestCount = parseInt($scope.guestData.adult) + parseInt($scope.guestData.children) + parseInt($scope.guestData.infant);

        toaster.clear();
        if($scope.guestData.adult < $scope.guestData.rooms)
        {
            $scope.guestError = true;
            toaster.error({
                title: "",
                body: $rootScope.translate.global_specifiedrooms_ASspecifiedroomsLbl + $scope.guestData.rooms + " " + $rootScope.translate.global_specifiedadults_ASspecifiedadultsLbl + $scope.guestData.adult
            });
            return;
        }

        if ($scope.guestData.adult > $scope.occupancyInfo.maxAdultOccupancy * $scope.guestData.rooms) {
            $scope.guestError = true;
            toaster.error({title: "", body: $rootScope.translate.global_pleaseaddrooms_ASpleaseaddroomsLbl});
            //toaster.error({title: "", body: "Please add more rooms"});

            return false;
        }

        if ($scope.occupancyInfo.allowChildren && ($scope.guestData.children > $scope.occupancyInfo.maxChildOccupancy * $scope.guestData.rooms)) {
            $scope.guestError = true;
            toaster.error({title: "", body: $rootScope.translate.global_pleaseaddrooms_ASpleaseaddroomsLbl});
           // toaster.error({title: "", body: "Please add more rooms"});
            return false;
        }

        if ($scope.occupancyInfo.maxOcc > 0 &&(guestCount > $scope.occupancyInfo.maxOcc * $scope.guestData.rooms)) {
            $scope.guestError = true;
            toaster.error({title: "", body: $rootScope.translate.global_pleaseaddrooms_ASpleaseaddroomsLbl});
           // toaster.error({title: "", body: "Please add more rooms"});
            return false;
        }


        $scope.guestError = false;
        $rootScope.isError = false;
        areaService.setGuestData($scope.guestData);
        $scope.toggleGuest();
        $rootScope.toggle.guestMenu = false;
        $rootScope.$broadcast(EVENT.UPDATE_GUEST_AND_ROOMS);
        originData = angular.copy($scope.guestData);

    }
    if(cacheData)
    {
        $scope.guestData = cacheData;
        //$scope.updateGuest();
        $rootScope.$broadcast(EVENT.UPDATE_GUEST_AND_ROOMS);
    }
    else {
        $scope.guestData = {};
        $scope.guestData.adult = $scope.occupancyInfo.defaultAdult;
        if($scope.occupancyInfo.allowChildren)
            $scope.guestData.children = $scope.occupancyInfo.defaultChild;
        if($scope.occupancyInfo.allowInfants)
            $scope.guestData.infant = $scope.occupancyInfo.defaultInfants;
        $scope.guestData.rooms = $scope.occupancyInfo.defaultRooms;
    }

    originData = angular.copy($scope.guestData);

}

GuestAndRoomsController.$inject =['$rootScope', '$log', '$scope','EVENT', 'navDataFactory', 'areaFactory','areaService', 'toaster', '$window'];
