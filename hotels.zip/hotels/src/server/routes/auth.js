/**
 * Created by sshetty on 10/03/2016.
 */
'use strict';

var express = require('express');
var router = express.Router();
// Configuration
var logger = require('log4js').getLogger();
var appConfig = require('../config/config.js');
var httpClient = require('request-promise');
router.use(function(req, res, next){
    logger.debug(req.url)
    logger.debug(req.url.match(/^((?!\.jpg|\.css|\.png|\.map|\.jpeg).)*$/g))
    //if(req.url.substr(req.url.length - 4) != ".map" && req.url.substr(req.url.length - 4) != ".css" && req.url.substr(req.url.length - 4) != ".jpg" && req.url.substr(req.url.length - 4) != ".png" && req.url.substr(req.url.length - 3) != ".js" && req.url.substr(req.url.length - 5) != ".jpeg") {
    if(req.url.match(/^((?!\.jpg|\.css|\.png|\.map|\.jpeg).)*$/g)){
        logger.debug('Auth calling....');
        var options = {
            jwtApiUrl: appConfig.jwtApiUrl
        };


        var authToken = req.headers['authorization'];
        if (authToken) {
            logger.debug('req.headers.Authorization:' + authToken);
            logger.debug('CONTINUING TO INDEX');
            next();
        }
        else {
            var httpOptions = {
                uri: options.jwtApiUrl,
                method: 'GET',
                //headers: {},
                //body: {},
                //json: true,
                resolveWithFullResponse: true
            };
            logger.debug('REF TOKEN PROCESSING:' + JSON.stringify(httpOptions));

            httpClient.get(httpOptions)
                .then(function (response) {
                    //logger.debug(response.headers);
                    var authHeader = response.headers['authorization'];
                    res.authToken = authHeader;
                    //res.set('authorization',response.headers['authorization']);
                    //req.headers.Authorization = authHeader;
                    logger.debug('Auth header response:' + res.authToken);
                    next();

                }).catch(function (error) {
                logger.debug('INVALID REF TOKEN REDIRECTING TO ADMIN');
                next();//res.redirect(redirectUrl);
            });

        }
    }else{
        next();
    }
    return true;
});

module.exports = router;