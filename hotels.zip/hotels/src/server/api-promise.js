/*
 * The API Module acts as an adapter for all the IBE microservices.  It
 * handles the creation of the URL and it will always return a promise.
 */
"use strict";

// Required modules
var httpClient = require('request-promise');
var logger = require('log4js').getLogger();
var appConfig = require('./config/config.js');


logger.info('IBE API URL is [',appConfig.ibeApiUrl,']');

// Create the exports variable that we'll use when assigning
// functions we want to export
var exports = module.exports = {};


/**
 * Gets the hotel descriptive Content from the API
 * @param {string} Chain Code
 * @return {Promise} Promise
 */
exports.getChainInfo = function(chainCode, themeId){
    var queryString = {
        options : 'ux,translations,languages,currencies'
    };

    if (themeId !== undefined){
        queryString.themeId =themeId;
    }
/*
    if(languageCode !== undefined){
        queryString.lang = languageCode;
    }
*/

    var options = {
        uri: appConfig.ibeApiUrl + '/chain/' + chainCode + '/info',
        qs: queryString,
        headers: {},
        body: {},
        json: true
    }
   // options.headers.Authorization = authToken;
    logger.debug("Calling [", options.uri + "] with query string [=", options.qs);

    return httpClient(options);
}

