/*
 * This module is used to load the application configuraiton
 */
"use strict";

//Load required modules
var log4js = require('log4js');
var logger = log4js.getLogger();

var env = (process.env.NODE_ENV === undefined) ? 'local' : process.env.NODE_ENV;

//Load the configuration JSON
var json = require('./config.json');
var indexJson = require('./../../../build/js-manifest.json');
var indexCSSJson = require('./../../../build/css-manifest.json');

/**
 * The properties object which holds the final set of properties to be exported
 */
var appConfig = {
    env : env
};

//Call the functions to load the required data
processGlobalProperties();
processProfileProperties();
configureLog4js();

//Provide the facility to override the default port set in the config.js
if(process.env.PORT !== undefined){
    logger.info('Default port was overridden with [',process.env.PORT,']');
    appConfig.port = process.env.PORT;
}

/**
 * Export what is needed
 * @type {{}}
 */
module.exports = appConfig;


/*----------------   PRIVATE FUNCTIONS ----------------*/

/**
 * Process the global properties
 */
function processGlobalProperties(){
    for(var attr in json){
        if ( attr !== 'profiles') {
            appConfig[attr] = json[attr];
        }
    }
    for (var attrJs in indexJson) {
        appConfig[attrJs] = indexJson[attrJs];
    }
    for (var attrCss in indexCSSJson) {
        appConfig[attrCss] = indexCSSJson[attrCss];
    }
}

/**
 * Process the profiles in order
 */
function processProfileProperties(){
    //If there are no profiles then just exit
    if(json.profiles == undefined)
        return;

    for(var i=0; i < json.profiles.length; i++){
        var currentProfile = json.profiles[i];
        if(currentProfile.profile === env){
            for(var attr in currentProfile.properties){
                //before we assign check that its not an inherited property
                if(currentProfile.properties.hasOwnProperty(attr))
                    appConfig[attr] = currentProfile.properties[attr];
            }
        }
    }


}

/**
 * Configure log4js
 */
function configureLog4js(){
    if(appConfig.log4jsConfiguration !== undefined){
        log4js.configure({
            appenders: [ appConfig.log4jsConfiguration ]
        });
        logger.setLevel(appConfig.log4jsConfiguration.level);
    }
}


